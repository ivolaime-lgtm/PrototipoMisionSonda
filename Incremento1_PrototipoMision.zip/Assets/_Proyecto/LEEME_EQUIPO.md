# Prototipo de misión — guía rápida del equipo

Nombre del proyecto provisional: `PrototipoMisionSonda`.
Motor: Unity 6.3 LTS (6000.3.28f1) · URP · Windows · Input System (New).

## Incremento 1: qué hay

- Sonda en primera persona con movimiento submarino.
- Estación que recarga la batería.
- Energía que baja con el tiempo y más al moverse.
- Interfaz mínima provisional (energía, consumo, estado, distancia a la estación).

## Cómo generar la escena

1. Menú **Prototipo → 1. Crear escena de exploración**.
2. Se abre `Assets/_Proyecto/Scenes/Exploracion.unity`.
3. Pulsa **Play**.

Si vuelves a usar el menú, te preguntará antes de sustituir la escena.
Los prefabs y materiales que ya existan **no** se sobrescriben.

## Tareas sin programar

| Quiero… | Dónde |
|---|---|
| Cambiar la batería o los consumos | `Prefabs/Sonda` → componente **Sistema Energia** |
| Cambiar velocidad o sensibilidad del ratón | `Prefabs/Sonda` → componente **Controlador Sonda** |
| Mover la estación | Selecciónala en la escena y muévela (herramienta Move, tecla W) |
| Cambiar el aspecto de la estación | Doble clic en `Prefabs/Estacion` |
| Cambiar textos de la interfaz | Objeto **Interfaz** → componente **Hud Minimo** |
| Cambiar colores | Carpeta `Materials` → campo **Base Map** |
| Mover rocas o plantas | Objetos **Rocas** y **PlantasLuminosas** de la escena |

Pasa el ratón sobre cada campo del Inspector para ver su explicación y sus unidades.

## Unidades

- **W (vatio):** cuánta energía se gasta en cada instante.
- **Wh (vatio-hora):** cuánta energía hay guardada. 1 Wh = 1 W durante 1 hora.
- **Escala de tiempo:** 1 segundo real = 1 minuto de misión (editable).

Todos los valores son de **DEMOSTRACIÓN**. No proceden de ninguna misión real.

## Licencias (pendiente de decidir y verificar)

| Tipo | Elemento | Estado |
|---|---|---|
| Código propio | `Scripts/` y `Editor/` | Licencia OSI por elegir (p. ej. MIT o Apache-2.0) |
| Dependencias del motor | Unity Editor, URP, Input System | Términos de Unity; confirmar cada paquete en el Package Manager |
| Recursos de terceros | Ninguno en este incremento | — |
| Datos científicos | Ninguno en este incremento | — |
| Valores de demostración | Batería, consumos, recarga, escala de tiempo | Marcados como DEMOSTRACIÓN |

Pendiente de verificar con la organización: si depender de un motor no OSI
(Unity) es aceptable según las reglas de entrega de NASA Space Apps 2026.
