using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

namespace PrototipoMision
{
    /// <summary>
    /// Va en la escena Exploracion. Al empezar, aplica la configuración elegida:
    /// - Batería: fija la capacidad de SistemaEnergia (APLICADO).
    /// - Masa de la sonda: cambia la aceleración en ControladorSonda (APLICADO).
    /// - Instrumento y órbita: se guardan en Resumen para el escáner y la
    ///   transmisión (PENDIENTE: incremento 3).
    /// Tecla M: volver a la pantalla de configuración.
    /// </summary>
    public class AplicadorConfiguracion : MonoBehaviour
    {
        [SerializeField] CatalogoMision catalogo;
        [SerializeField] SistemaEnergia energia;
        [SerializeField] ControladorSonda controlador;
        [SerializeField] string escenaConfiguracion = "Configuracion";
        [SerializeField] bool mostrarPanel = true;

        /// <summary>Configuración aplicada. La usarán el escáner y la transmisión.</summary>
        public ResumenMision Resumen { get; private set; }

        GUIStyle estilo;

        void Start()
        {
            if (catalogo == null)
            {
                Debug.LogError("[Prototipo] AplicadorConfiguracion: falta asignar el CatalogoMision.", this);
                return;
            }

            if (energia == null) energia = FindAnyObjectByType<SistemaEnergia>();
            if (controlador == null) controlador = FindAnyObjectByType<ControladorSonda>();

            if (!MisionActual.Configurada)
                Debug.Log("[Prototipo] Se inició Exploracion sin pasar por Configuracion: se usan las primeras opciones del catálogo.", this);

            Resumen = catalogo.Calcular(MisionActual.Eleccion);

            if (!Resumen.PuedeIniciar)
                Debug.LogWarning("[Prototipo] La configuración supera algún límite: " + string.Join(" | ", Resumen.problemas), this);

            if (Resumen.bateria != null && energia != null)
                energia.ConfigurarBateria(Resumen.energiaWh);

            if (controlador != null)
                controlador.EstablecerMasa(Resumen.masaSondaKg);
        }

        void Update()
        {
            Keyboard teclado = Keyboard.current;
            if (teclado != null && teclado.mKey.wasPressedThisFrame)
            {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                SceneManager.LoadScene(escenaConfiguracion);
            }
        }

        void OnGUI()
        {
            if (!mostrarPanel || Resumen == null || Resumen.instrumento == null) return;

            if (estilo == null)
            {
                estilo = new GUIStyle(GUI.skin.label) { fontSize = 17, wordWrap = true, richText = true };
                estilo.normal.textColor = new Color(0.85f, 0.93f, 0.97f);
            }

            float escala = Screen.height / 1080f;
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(escala, escala, 1f));
            float anchoVirtual = Screen.width / escala;

            Rect panel = new Rect(anchoVirtual - 520f, 30f, 490f, 250f);
            Color previo = GUI.color;
            GUI.color = new Color(0f, 0.05f, 0.08f, 0.6f);
            GUI.DrawTexture(panel, Texture2D.whiteTexture);
            GUI.color = previo;

            string factor = controlador != null ? $" → aceleración ×{controlador.FactorMasa:0.00}" : "";
            string texto =
                "<b>CONFIGURACIÓN DE LA MISIÓN</b>\n" +
                $"Objetivo: {Resumen.objetivo.nombre}\n" +
                $"Instrumento: {Resumen.instrumento.nombre} <color=#FFC857>(escáner PENDIENTE)</color>\n" +
                $"Batería: {Resumen.bateria.nombre} · {Resumen.energiaWh:0} Wh\n" +
                $"Lanzador: {Resumen.lanzador.nombre}\n" +
                $"Relevo: {Resumen.orbita.nombre} <color=#FFC857>(transmisión PENDIENTE)</color>\n" +
                $"Masa de la sonda: {Resumen.masaSondaKg:0} kg{factor}\n" +
                "<size=15>M: volver a la configuración</size>";

            GUI.Label(new Rect(panel.x + 16f, panel.y + 10f, panel.width - 32f, panel.height - 20f), texto, estilo);
            GUI.matrix = Matrix4x4.identity;
        }
    }
}
