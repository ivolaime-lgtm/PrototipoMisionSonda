using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace PrototipoMision
{
    /// <summary>
    /// Pantalla de configuración de la misión (interfaz provisional IMGUI).
    /// Lee las opciones del CatalogoMision, muestra coste, masa, energía y datos,
    /// explica qué cambia cada elección y bloquea el inicio si se superan los límites.
    /// Las opciones y los textos se editan en el asset CatalogoMision, no aquí.
    /// </summary>
    public class PantallaConfiguracion : MonoBehaviour
    {
        [SerializeField] CatalogoMision catalogo;
        [SerializeField] string escenaExploracion = "Exploracion";

        [Header("Textos editables")]
        [SerializeField] string titulo = "CONFIGURACIÓN DE LA MISIÓN";
        [SerializeField] string textoUnidades =
            "Unidades: M USD = millones de dólares · kg = kilogramos · Wh = energía guardada · " +
            "W = consumo · MB = megabytes de datos · MB/s = velocidad de transmisión. Todos los valores son DEMOSTRACIÓN.";

        const string Aplicado = "<color=#7CFC9A><b>APLICADO</b></color>";
        const string Pendiente = "<color=#FFC857><b>PENDIENTE</b></color>";

        ConfiguracionElegida eleccion;
        ResumenMision resumen;
        Vector2 desplazamiento;

        GUIStyle sTitulo, sSeccion, sTexto, sPequeno, sBoton, sBotonGrande, sProblema, sAviso;

        void Start()
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;

            if (MisionActual.Configurada)
                eleccion = MisionActual.Eleccion;

            Recalcular();
        }

        void Recalcular()
        {
            resumen = catalogo != null ? catalogo.Calcular(eleccion) : null;
        }

        void OnGUI()
        {
            if (catalogo == null || resumen == null)
            {
                GUI.Label(new Rect(20, 20, 900, 40),
                    "Falta asignar el asset CatalogoMision en el componente PantallaConfiguracion.");
                return;
            }

            PrepararEstilos();

            // Catálogo incompleto (alguna lista vacía): solo se muestran los problemas.
            if (resumen.objetivo == null || resumen.instrumento == null || resumen.bateria == null ||
                resumen.lanzador == null || resumen.orbita == null)
            {
                GUILayout.BeginArea(new Rect(20, 20, Screen.width - 40, Screen.height - 40));
                GUILayout.Label("El catálogo de misión está incompleto:", sTexto);
                foreach (string p in resumen.problemas) GUILayout.Label("[X] " + p, sProblema);
                GUILayout.EndArea();
                return;
            }

            float escala = Mathf.Min(Screen.width / 1920f, Screen.height / 1080f);
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(escala, escala, 1f));
            Rellenar(new Rect(0, 0, Screen.width / escala, Screen.height / escala), new Color(0.02f, 0.08f, 0.11f));

            // Los cambios se guardan aquí y se aplican al final del evento,
            // para no alterar la interfaz a mitad de un dibujado.
            ConfiguracionElegida nueva = eleccion;
            bool iniciar = false;

            // ---------------- Columna izquierda: opciones
            GUILayout.BeginArea(new Rect(40, 25, 1120, 1035));
            GUILayout.Label(titulo, sTitulo);
            GUILayout.Label(catalogo.escenario, sPequeno);
            desplazamiento = GUILayout.BeginScrollView(desplazamiento);

            nueva.objetivo = Seccion("1. OBJETIVO CIENTÍFICO", Nombres(catalogo.objetivos, o => o.nombre), eleccion.objetivo);
            Texto(resumen.objetivo.descripcion);
            Datos($"Escaneos requeridos: {resumen.objetivo.escaneosRequeridos} {Pendiente} · " +
                  $"Instrumento recomendado: {resumen.objetivo.instrumentoRecomendado}");

            nueva.instrumento = Seccion("2. INSTRUMENTO CIENTÍFICO", Nombres(catalogo.instrumentos, i => i.nombre), eleccion.instrumento);
            OpcionInstrumento ins = resumen.instrumento;
            Texto(ins.queCambia);
            Datos($"Coste {ins.costeMUSD:0.#} M USD · Masa {ins.masaKg:0.#} kg {Aplicado}\n" +
                  $"Consumo al escanear {ins.consumoEscaneoW:0} W · {ins.datosPorEscaneoMB:0} MB por escaneo · " +
                  $"{ins.segundosEscaneo:0.#} s por escaneo · valor {ins.valorCientifico} {Pendiente}");

            nueva.bateria = Seccion("3. BATERÍA", Nombres(catalogo.baterias, b => b.nombre), eleccion.bateria);
            OpcionBateria bat = resumen.bateria;
            Texto(bat.queCambia);
            Datos($"Coste {bat.costeMUSD:0.#} M USD · Masa {bat.masaKg:0.#} kg · Capacidad {bat.capacidadWh:0} Wh {Aplicado}");

            nueva.lanzador = Seccion("4. LANZADOR", Nombres(catalogo.lanzadores, l => l.nombre), eleccion.lanzador);
            OpcionLanzador lan = resumen.lanzador;
            Texto(lan.queCambia);
            Datos($"Coste {lan.costeMUSD:0.#} M USD · Capacidad de carga {lan.capacidadCargaKg:0} kg {Aplicado} (bloquea el inicio si se supera)");

            nueva.orbita = Seccion("5. ÓRBITA DEL SATÉLITE DE RELEVO", Nombres(catalogo.orbitas, o => o.nombre), eleccion.orbita);
            OpcionOrbita orb = resumen.orbita;
            Texto(orb.queCambia);
            Datos($"Coste {orb.costeMUSD:0.#} M USD · Masa del relevo {orb.masaReleKg:0} kg {Aplicado} (cuenta para el lanzador)\n" +
                  $"Enlace {orb.velocidadEnlaceMBs:0} MB/s con contacto {orb.fraccionContacto * 100f:0} % del tiempo " +
                  $"→ efectivo {resumen.enlaceEfectivoMBs:0.#} MB/s {Pendiente}");

            GUILayout.Space(10);
            GUILayout.Label("Modelo simplificado: el lanzador y la órbita no se simulan físicamente; " +
                            "solo cambian coste, masa y velocidad de transmisión.", sPequeno);

            GUILayout.EndScrollView();
            GUILayout.EndArea();

            // ---------------- Columna derecha: resumen
            GUILayout.BeginArea(new Rect(1190, 25, 690, 1035));
            GUILayout.Label("RESUMEN", sTitulo);

            Barra("Coste total", resumen.costeTotalMUSD, resumen.presupuestoMUSD, "M USD");
            Barra("Carga en el lanzador", resumen.masaLanzamientoKg, resumen.capacidadLanzadorKg, "kg");

            GUILayout.Space(6);
            Texto($"Masa de la sonda: {resumen.masaSondaKg:0} kg {Aplicado}\n<size=15>Más masa = la sonda acelera menos.</size>");
            Texto($"Energía de la batería: {resumen.energiaWh:0} Wh {Aplicado}");
            Texto($"Energía estimada para escanear: {resumen.energiaEscaneosWh:0.#} Wh {Pendiente}");
            Texto($"Datos previstos: {resumen.datosMisionMB:0} MB de {resumen.memoriaMB:0} MB de memoria {Pendiente}");
            string tx = float.IsInfinity(resumen.segundosTransmision) ? "sin enlace" : $"≈ {resumen.segundosTransmision:0} s";
            Texto($"Transmitir todos los datos: {tx} {Pendiente}");

            GUILayout.Space(8);
            foreach (string p in resumen.problemas) GUILayout.Label("[X] " + p, sProblema);
            foreach (string a in resumen.avisos) GUILayout.Label("[!] " + a, sAviso);
            if (resumen.problemas.Count == 0 && resumen.avisos.Count == 0)
                GUILayout.Label("[OK] La configuración cumple todos los límites.", sTexto);

            GUILayout.FlexibleSpace();

            bool habilitado = GUI.enabled;
            GUI.enabled = resumen.PuedeIniciar;
            string textoBoton = resumen.PuedeIniciar ? "INICIAR MISIÓN" : "NO SE PUEDE INICIAR · revisa los límites";
            if (GUILayout.Button(textoBoton, sBotonGrande, GUILayout.Height(64)))
                iniciar = true;
            GUI.enabled = habilitado;

            GUILayout.Space(8);
            GUILayout.Label(textoUnidades, sPequeno);
            GUILayout.Space(10);
            GUILayout.EndArea();

            GUI.matrix = Matrix4x4.identity;

            // ---------------- Aplicar cambios al final del evento
            if (!nueva.Equals(eleccion))
            {
                eleccion = nueva;
                Recalcular();
            }

            if (iniciar && resumen.PuedeIniciar)
            {
                MisionActual.Guardar(eleccion);
                SceneManager.LoadScene(escenaExploracion);
            }
        }

        // ---------------------------------------------------------------- Bloques

        int Seccion(string encabezado, string[] nombres, int actual)
        {
            GUILayout.Space(14);
            GUILayout.Label(encabezado, sSeccion);
            GUILayout.BeginHorizontal();
            int resultado = actual;
            for (int i = 0; i < nombres.Length; i++)
            {
                bool elegido = i == actual;
                Color previo = GUI.backgroundColor;
                GUI.backgroundColor = elegido ? new Color(0.3f, 0.9f, 1f) : new Color(0.55f, 0.6f, 0.65f);
                if (GUILayout.Button((elegido ? "• " : "") + nombres[i], sBoton, GUILayout.Height(44)))
                    resultado = i;
                GUI.backgroundColor = previo;
            }
            GUILayout.EndHorizontal();
            return resultado;
        }

        void Texto(string t) => GUILayout.Label(t, sTexto);
        void Datos(string t) => GUILayout.Label(t, sPequeno);

        void Barra(string etiqueta, float valor, float limite, string unidad)
        {
            bool excedido = valor > limite;
            GUILayout.Label($"{etiqueta}: {valor:0} / {limite:0} {unidad}" + (excedido ? "  <color=#FF6B5B><b>EXCEDIDO</b></color>" : ""), sTexto);
            Rect r = GUILayoutUtility.GetRect(600, 22, GUILayout.ExpandWidth(true));
            Rellenar(r, new Color(1f, 1f, 1f, 0.12f));
            float f = limite > 0f ? Mathf.Clamp01(valor / limite) : 1f;
            Rellenar(new Rect(r.x, r.y, r.width * f, r.height),
                     excedido ? new Color(1f, 0.35f, 0.3f) : f > 0.85f ? new Color(1f, 0.8f, 0.2f) : new Color(0.3f, 0.9f, 1f));
            GUILayout.Space(6);
        }

        static string[] Nombres<T>(List<T> lista, Func<T, string> nombre)
        {
            if (lista == null) return new string[0];
            string[] r = new string[lista.Count];
            for (int i = 0; i < lista.Count; i++) r[i] = nombre(lista[i]);
            return r;
        }

        static void Rellenar(Rect r, Color c)
        {
            Color previo = GUI.color;
            GUI.color = c;
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = previo;
        }

        void PrepararEstilos()
        {
            if (sTitulo != null) return;

            sTitulo = new GUIStyle(GUI.skin.label) { fontSize = 34, fontStyle = FontStyle.Bold, richText = true };
            sTitulo.normal.textColor = new Color(0.75f, 0.95f, 1f);

            sSeccion = new GUIStyle(GUI.skin.label) { fontSize = 22, fontStyle = FontStyle.Bold };
            sSeccion.normal.textColor = new Color(0.55f, 0.85f, 0.95f);

            sTexto = new GUIStyle(GUI.skin.label) { fontSize = 19, wordWrap = true, richText = true };
            sTexto.normal.textColor = Color.white;

            sPequeno = new GUIStyle(GUI.skin.label) { fontSize = 16, wordWrap = true, richText = true };
            sPequeno.normal.textColor = new Color(0.78f, 0.88f, 0.93f);

            sBoton = new GUIStyle(GUI.skin.button) { fontSize = 19, wordWrap = true };

            sBotonGrande = new GUIStyle(GUI.skin.button) { fontSize = 24, fontStyle = FontStyle.Bold };

            sProblema = new GUIStyle(sTexto);
            sProblema.normal.textColor = new Color(1f, 0.45f, 0.4f);

            sAviso = new GUIStyle(sTexto);
            sAviso.normal.textColor = new Color(1f, 0.82f, 0.35f);
        }
    }
}
