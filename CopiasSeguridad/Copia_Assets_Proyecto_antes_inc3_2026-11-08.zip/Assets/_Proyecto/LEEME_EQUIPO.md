# Prototipo de misión — guía rápida del equipo

Nombre del proyecto provisional: `PrototipoMisionSonda`.
Motor: Unity 6.3 LTS (6000.3.28f1) · URP · Windows · Input System (New).

## Qué hay hasta ahora

- **Incremento 1:** sonda en primera persona, estación que recarga, energía, interfaz mínima.
- **Incremento 2:** pantalla de configuración (objetivo, instrumento, batería, lanzador,
  órbita de relevo) con límites de presupuesto y de masa. La batería y la masa elegidas
  se aplican en la exploración.
- **Pendiente (incremento 3):** escáner, puntos científicos, datos y transmisión.

## Menús de creación (Prototipo)

| Menú | Qué hace |
|---|---|
| 1. Crear escena de exploración | Crea `Scenes/Exploracion` (pregunta antes de sustituir) |
| 2. Crear escena de configuración | Crea `Data/CatalogoMision` (si no existe) y `Scenes/Configuracion` |
| 3. Conectar configuración a Exploracion | **Añade** el objeto AplicadorConfiguracion a Exploracion |

Para jugar el recorrido completo: abre `Scenes/Configuracion` y pulsa **Play**.
Si pulsas Play directamente en Exploracion, se usan las primeras opciones del catálogo.

## Tareas sin programar

| Quiero… | Dónde |
|---|---|
| Cambiar presupuesto, costes, masas, baterías, instrumentos… | `Data/CatalogoMision` |
| Añadir una opción (p. ej. un tercer instrumento) | `Data/CatalogoMision` → botón **+** de la lista |
| Cambiar o añadir objetivos científicos | `Data/CatalogoMision` → lista **Objetivos** |
| Cambiar los consumos de la sonda o la recarga | `Prefabs/Sonda` → **Sistema Energia** |
| Cambiar velocidad, masa de referencia o ratón | `Prefabs/Sonda` → **Controlador Sonda** |
| Mover la estación | Selecciónala en la escena y muévela (herramienta Move, tecla W) |
| Cambiar el aspecto de la estación | Doble clic en `Prefabs/Estacion` |
| Cambiar textos de la interfaz | **Interfaz → Hud Minimo** y **PantallaConfiguracion** |
| Cambiar colores | Carpeta `Materials` → campo **Base Map** |
| Mover rocas o plantas | Objetos **Rocas** y **PlantasLuminosas** de la escena |

**Atención:** la capacidad de la batería ahora la decide el catálogo. El campo
*Capacidad Wh* de Sistema Energia solo se usa si falta el AplicadorConfiguracion.

Pasa el ratón sobre cada campo del Inspector para ver su explicación y sus unidades.

## Qué decisión afecta a qué

| Decisión | Efecto | Estado |
|---|---|---|
| Batería | Capacidad de energía (Wh) | APLICADO |
| Instrumento + batería | Masa de la sonda → aceleración | APLICADO |
| Todo | Coste total frente al presupuesto | APLICADO (bloquea) |
| Instrumento + batería + órbita | Carga frente a la capacidad del lanzador | APLICADO (bloquea) |
| Instrumento | Consumo y datos al escanear | PENDIENTE (incremento 3) |
| Órbita | Velocidad de transmisión | PENDIENTE (incremento 3) |
| Objetivo | Escaneos requeridos y valor científico | PENDIENTE (incremento 3) |

El lanzador y la órbita **no** se simulan físicamente: solo cambian coste, masa y
velocidad de transmisión.

## Unidades

- **M USD:** millones de dólares.
- **kg:** masa.
- **W (vatio):** cuánta energía se gasta en cada instante.
- **Wh (vatio-hora):** cuánta energía hay guardada. 1 Wh = 1 W durante 1 hora.
- **MB / MB/s:** cantidad de datos y velocidad de transmisión.
- **Escala de tiempo:** 1 segundo real = 1 minuto de misión (editable).

Todos los valores son de **DEMOSTRACIÓN**. No proceden de ninguna misión real.

## Licencias (pendiente de decidir y verificar)

| Tipo | Elemento | Estado |
|---|---|---|
| Código propio | `Scripts/` y `Editor/` | Licencia OSI por elegir (p. ej. MIT o Apache-2.0) |
| Dependencias del motor | Unity Editor, URP, Input System | Términos de Unity; confirmar cada paquete en el Package Manager |
| Recursos de terceros | Ninguno hasta ahora | — |
| Datos científicos | Ninguno hasta ahora | — |
| Valores de demostración | Catálogo de misión, consumos, recarga, escala de tiempo | Marcados como DEMOSTRACIÓN |

Pendiente de verificar con la organización: si depender de un motor no OSI
(Unity) es aceptable según las reglas de entrega de NASA Space Apps 2026.
