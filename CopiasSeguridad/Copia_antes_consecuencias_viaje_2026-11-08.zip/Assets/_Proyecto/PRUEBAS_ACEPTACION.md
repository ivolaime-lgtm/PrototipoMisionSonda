# Pruebas de aceptación del recorrido completo

Recorrido: **CentroOperaciones → Configuracion → Exploracion → Resultados → Repetir**.

Preparación: vista Game con resolución fija 16:9 (por ejemplo 1920×1080) y *Scale* en 1x.
Abre `Scenes/CentroOperaciones` y pulsa Play. Ten abierta la Console.

Configuración de referencia: **Cartografiar · Cámara · Batería ligera · Lanzador pequeño ·
Relevo en órbita baja**. Todos los valores son de DEMOSTRACIÓN.

## A. Recorrido principal

| # | Pasos | Resultado esperado |
|---|---|---|
| A1 | Arranca en CentroOperaciones | Se ven la estación, la luna y el satélite orbitando. Sin errores en la Console |
| A2 | **Configurar misión** | Pantalla de configuración. Con la referencia: coste **72/100 M USD**, carga **190/230 kg**, "[OK]" |
| A3 | Mira "Transmitir todos los datos" | Indica "s reales (media, contando las ventanas sin contacto)" |
| A4 | **Iniciar misión** y completa la nave (sección F) | Exploracion. Panel derecho: 80 Wh, aceleración ×1,00. Abajo, la lista completa de teclas (E, F, T, M, F9…) |
| A5 | Dentro de la estación | Panel de energía: "Autonomía: recargando en la estación". Abajo: "T: terminar la misión…" |
| A6 | Sal, escanea 1 punto (E) y vuelve | En la estación, mientras quedan datos: "…aún hay N MB sin transmitir, se perderían" |
| A7 | Escanea y transmite los 3 puntos | Banner verde y, 4 s después, Resultados **MISIÓN CUMPLIDA** |
| A8 | Lee el informe | Duración "m:ss reales (≈ N min de misión)". Puntuación 12 + 10 + 14 = **36** |
| A9 | **Repetir con la misma configuración** | La nave de nuevo (preparación) y, tras el viaje, Exploracion con batería llena, 0 escaneos, puntos sin escanear, misma configuración |
| A10 | Pulsa **M** | Configuracion con la misma elección marcada |

## B. Finales alternativos

| # | Pasos | Resultado esperado |
|---|---|---|
| B1 | Transmite 1 escaneo y pulsa T en la estación | **PARCIALMENTE CUMPLIDA**. Sin bonos; explica que el sobrante no suma |
| B2 | Pulsa T fuera de la estación | "Solo puedes terminar la misión dentro de la estación". No termina |
| B3 | Catálogo: *Capacidad Wh* de la batería ligera = 15. Sal de la estación y aléjate sin volver (si llegas a un punto, escanéalo) | "ENERGÍA AGOTADA · Generando el informe…" → **MISIÓN FALLIDA** con la distancia a la estación, los MB perdidos si escaneaste y la sugerencia de batería mayor |
| B4 | Desde Resultados, **Volver a configurar** | Configuracion con la última elección |

## C. Reglas de la configuración

| # | Elección, o cambio en el catálogo (fuera de Play) | Resultado esperado |
|---|---|---|
| C1 | Cámara · **Batería alta** · Pequeño · **Órbita alta** | Carga 238/230 EXCEDIDO. Botón bloqueado |
| C2 | Espectrómetro · Ligera · **Mediano** · Baja | Coste 106/100 EXCEDIDO. Botón bloqueado |
| C3 | *Memoria MB* = 100 | Con la Cámara (120 MB por escaneo): bloqueado por memoria. Con el Espectrómetro (60 MB): permitido |
| C4 | *Fracción Contacto* de la órbita baja = 0 | Con esa órbita: bloqueado por "no tiene enlace" |
| C5 | *Escaneos Requeridos* del objetivo = 4 | Permite iniciar. En Exploracion, aviso rojo en el panel de datos y en la Console: solo hay 3 puntos |
| C6 | *Minutos Mision Por Segundo* del catálogo = 2 | Al entrar en Exploracion, aviso amarillo en la Console por escalas de tiempo distintas |

Deshaz los cambios del catálogo al terminar (o restaura desde `CopiasSeguridad`).

## D. Ejecutable y rendimiento

| # | Pasos | Resultado esperado |
|---|---|---|
| D1 | File → Build Profiles: orden de escenas | CentroOperaciones, Configuracion, Exploracion, Resultados (SampleScene, si aparece, se puede desmarcar) |
| D2 | Build en una carpeta **fuera** del proyecto y ejecútalo | Luna con textura, satélite visible, estación con materiales (nada rosa) |
| D3 | F9 en cada escena (editor y ejecutable) | Anota FPS y "peor ms". Referencia del editor en CentroOperaciones: 312 FPS (dato medido por el equipo) |
| D4 | Recorrido A completo en el ejecutable | Igual que en el editor |

## E. Modo equipo

| # | Pasos | Resultado esperado |
|---|---|---|
| E1 | En Configuracion, Jugadores **1** | Sin filas de roles ni aprobaciones. Todas las secciones activas. INICIAR funciona como antes (A2–A4) |
| E2 | Jugadores **2** | Roles: Ciencia J1, Ingeniería J2, Lanzamiento J2, Comunicaciones J1. Turno J1. Batería y Lanzador en gris (no se pueden pulsar) |
| E3 | Turno **J2** | Objetivo, Instrumento y Órbita en gris; Batería y Lanzador activos |
| E4 | Con la referencia, mira las líneas de prioridad | Ciencia SE CUMPLE; Ingeniería NO (margen < 100 Wh); Lanzamiento SE CUMPLE (reserva 28); Comunicaciones SE CUMPLE |
| E5 | Pulsa solo **J1: aprobar** | Botón grande: "FALTAN APROBACIONES: J2", desactivado |
| E6 | Pulsa **J2: aprobar** | "INICIAR MISIÓN" activo |
| E7 | Con ambos aprobados, cambia la batería (turno J2) | Las dos aprobaciones vuelven a "aprobar" |
| E8 | Reasigna Lanzamiento a J1 | Aprobaciones anuladas; en turno J1 el Lanzador queda activo |
| E9 | Jugadores **4** | Un rol por jugador; cuatro botones de aprobación |
| E10 | Inicia y mira el panel de Exploracion | Línea "Equipo: N jugadores", el panel no tapa otros textos |
| E11 | Termina la misión | Resultados: sección "PRIORIDADES DE CADA ROL (N/4)" con [OK]/[X], jugador, plan y resultado real; en POR QUÉ, "El equipo (…) cumplió N de 4 prioridades" |
| E12 | **Volver a configurar** | Mismo número de jugadores y reparto; aprobaciones vacías |
| E13 | Para Play y vuelve a pulsar Play | Jugadores vuelve a 1 |

## F. Nave (activa *Modo Prueba* en ControlNave para acortar los tiempos)

Con la configuración de referencia (lanzador pequeño): combustible 300 + 40 = **340 kg**, masa **6530 kg**.

| # | Pasos | Resultado esperado |
|---|---|---|
| F1 | Configuracion → **Iniciar misión** | Escena Nave en primera persona, cielo azul y plataforma por la ventana. Panel: "Preparación", "[MODO DE PRUEBA]" si está activado |
| F2 | Camina y mira cada consola | Abajo: "E: usar …". Luces ámbar en Comunicaciones, Ingeniería y Ciencia |
| F3 | Pilotaje antes de comprobar nada, Espacio | Aviso "Faltan comprobaciones: …". No despega |
| F4 | Ingeniería (E) | Datos de la NAVE: masa seca 6000 kg, carga 190 kg, combustible 300 + 40 = 340 kg, masa 6530 kg, aceleración 3,98 m/s², energía 1000 Wh. Espacio: luz verde |
| F5 | Ciencia (E) | Datos de la SONDA: batería 80 Wh, masa 170 kg. Espacio: luz verde |
| F6 | Comunicaciones (E) | Mensaje "Plan de vuelo". Espacio: confirmado, luz verde |
| F7 | Pilotaje, Espacio | Cuenta atrás grande; Q no saca del asiento. Al terminar: vibración, el suelo cae, el cielo se oscurece, aparecen estrellas en movimiento |
| F8 | Tras el ascenso, Q | Puedes caminar por la cabina |
| F9 | Espera la avería (30 % del viaje) | Luces rojas, luz roja en Ingeniería, la energía de la nave baja |
| F10 | Ingeniería: pulsa un número que NO es el circuito en sobrecarga | "Paso equivocado": −40 Wh, vibración. Sigue en el paso 1 |
| F11 | Número correcto → R → Espacio | Palanca roja → ámbar → azul → verde; "Avería reparada"; luces normales |
| F12 | Espera la alerta de escombros | Luces ámbar, luz roja en Pilotaje, aviso con cuenta atrás |
| F13 | Quédate fuera de Pilotaje mientras llegan | Rocas visibles por la ventana; impactos: destello rojo, vibración, casco −25 % |
| F14 | Repite (Repetir) y esquiva desde Pilotaje con WASD | Las rocas se desplazan en la ventana; el combustible baja al empujar y al soltar (estabilizador); cuenta de esquivados |
| F15 | Llegada | La luna crece por la ventana; mensaje en Comunicaciones; Pilotaje pide esperarlo |
| F16 | Confirma el mensaje y vuelve a Pilotaje | Barra con zona verde y marcador. Espacio: "En órbita", combustible restado |
| F17 | Comunicaciones (autorización de despliegue) → Ciencia, Espacio | Cápsula que se aleja por la ventana; a los pocos segundos, Exploracion |
| F18 | Termina la exploración | Resultados con sección "VIAJE EN LA NAVE" y explicaciones de impactos, avería, combustible y frenada |
| F19 | Recibe 4 impactos (no esquives) | "MISIÓN ABORTADA" → Resultados **MISIÓN FALLIDA**, "La sonda no llegó a desplegarse" |
| F20 | No repares la avería | Energía de la nave a 0 → misión abortada |
| F21 | Gasta combustible empujando mucho antes de llegar y frena tarde | Si no alcanza: abortada por falta de combustible |
| F22 | Referencia con **Lanzador mediano** (coste 90/100) | Ingeniería: 260 kg extra, combustible 560 kg, masa 6750 kg, aceleración 3,85 m/s² (frente a 3,98 con el pequeño) |
| F23 | En el objeto PantallaConfiguracion de Configuracion, desmarca *Pasar Por Nave* | Iniciar misión va directamente a Exploracion, como antes; Resultados sin sección de viaje |

