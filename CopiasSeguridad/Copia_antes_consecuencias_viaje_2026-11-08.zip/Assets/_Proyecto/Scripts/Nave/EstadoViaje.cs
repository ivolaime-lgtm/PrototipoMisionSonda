using UnityEngine;

namespace PrototipoMision
{
    /// <summary>
    /// Resultado del viaje en la nave. Lo rellena ControlNave y lo copia el informe final.
    /// Se reinicia al pulsar Play, al iniciar una misión y al entrar en la escena Nave.
    /// Si se juega Exploracion sin pasar por la nave, Realizado es false.
    /// </summary>
    public static class EstadoViaje
    {
        public static bool Realizado;
        public static bool Abortado;
        public static string MotivoAborto;

        public static float MasaInicialKg;
        public static float CombustibleInicialKg, CombustibleExtraKg, CombustibleFinalKg;
        public static float CombustibleManiobrasKg, CombustibleInsercionKg;
        public static float IntegridadFinal;
        public static int Impactos, EscombrosEsquivados;
        public static float EnergiaInicialWh, EnergiaFinalWh;
        public static float SegundosAveria;
        public static int ErroresAveria;
        public static float ErrorInsercion;        // 0 = perfecto, 0,5 = peor; -1 si no hubo inserción
        public static float SegundosViaje;
        public static float ZonaVerdeInsercion = 0.08f;

        /// <summary>
        /// Escena con la que empieza una misión: la Nave si está activada y en la lista de compilación;
        /// si no, Exploracion directamente (así el juego sigue funcionando sin la escena Nave).
        /// </summary>
        public static string EscenaDeInicio(bool pasarPorNave, string escenaNave, string escenaExploracion)
        {
            if (pasarPorNave)
            {
                if (Application.CanStreamedLevelBeLoaded(escenaNave)) return escenaNave;
                Debug.LogWarning($"[Prototipo] La escena {escenaNave} no está en la lista de compilación " +
                                 "(menú Prototipo/8). Se va directamente a " + escenaExploracion + ".");
            }
            return escenaExploracion;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        public static void Reiniciar()
        {
            Realizado = false;
            Abortado = false;
            MotivoAborto = "";
            MasaInicialKg = 0f;
            CombustibleInicialKg = CombustibleExtraKg = CombustibleFinalKg = 0f;
            CombustibleManiobrasKg = CombustibleInsercionKg = 0f;
            IntegridadFinal = 0f;
            Impactos = EscombrosEsquivados = 0;
            EnergiaInicialWh = EnergiaFinalWh = 0f;
            SegundosAveria = 0f;
            ErroresAveria = 0;
            ErrorInsercion = -1f;
            SegundosViaje = 0f;
            ZonaVerdeInsercion = 0.08f;
        }
    }
}
