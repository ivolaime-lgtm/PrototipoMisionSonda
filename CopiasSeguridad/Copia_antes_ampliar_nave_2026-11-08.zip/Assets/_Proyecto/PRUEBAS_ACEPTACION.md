# Pruebas de aceptación del recorrido completo

Recorrido: **CentroOperaciones → Configuracion → Exploracion → Resultados → Repetir**.

Preparación: vista Game con resolución fija 16:9 (por ejemplo 1920×1080) y *Scale* en 1x.
Abre `Scenes/CentroOperaciones` y pulsa Play. Ten abierta la Console.

Configuración de referencia: **Cartografiar · Cámara · Batería ligera · Lanzador pequeño ·
Relevo en órbita baja**. Todos los valores son de DEMOSTRACIÓN.

## A. Recorrido principal

| # | Pasos | Resultado esperado |
|---|---|---|
| A1 | Arranca en CentroOperaciones | Se ven la estación, la luna y el satélite orbitando. Sin errores en la Console |
| A2 | **Configurar misión** | Pantalla de configuración. Con la referencia: coste **72/100 M USD**, carga **190/230 kg**, "[OK]" |
| A3 | Mira "Transmitir todos los datos" | Indica "s reales (media, contando las ventanas sin contacto)" |
| A4 | **Iniciar misión** y completa la nave (sección F) | Exploracion. Panel derecho: 80 Wh, aceleración ×1,00. Abajo, la lista completa de teclas (E, F, T, M, F9…) |
| A5 | Dentro de la estación | Panel de energía: "Autonomía: recargando en la estación". Abajo: "T: terminar la misión…" |
| A6 | Sal, escanea 1 punto (E) y vuelve | En la estación, mientras quedan datos: "…aún hay N MB sin transmitir, se perderían" |
| A7 | Escanea y transmite los 3 puntos | Banner verde y, 4 s después, Resultados **MISIÓN CUMPLIDA** |
| A8 | Lee el informe | Duración "m:ss reales (≈ N min de misión)". Puntuación 12 + 10 + 14 = **36** |
| A9 | **Repetir con la misma configuración** | La nave de nuevo (preparación) y, tras el viaje, Exploracion con batería llena, 0 escaneos, puntos sin escanear, misma configuración |
| A10 | Pulsa **M** | Configuracion con la misma elección marcada |

## B. Finales alternativos

| # | Pasos | Resultado esperado |
|---|---|---|
| B1 | Transmite 1 escaneo y pulsa T en la estación | **PARCIALMENTE CUMPLIDA**. Sin bonos; explica que el sobrante no suma |
| B2 | Pulsa T fuera de la estación | "Solo puedes terminar la misión dentro de la estación". No termina |
| B3 | Catálogo: *Capacidad Wh* de la batería ligera = 15. Sal de la estación y aléjate sin volver (si llegas a un punto, escanéalo) | "ENERGÍA AGOTADA · Generando el informe…" → **MISIÓN FALLIDA** con la distancia a la estación, los MB perdidos si escaneaste y la sugerencia de batería mayor |
| B4 | Desde Resultados, **Volver a configurar** | Configuracion con la última elección |

## C. Reglas de la configuración

| # | Elección, o cambio en el catálogo (fuera de Play) | Resultado esperado |
|---|---|---|
| C1 | Cámara · **Batería alta** · Pequeño · **Órbita alta** | Carga 238/230 EXCEDIDO. Botón bloqueado |
| C2 | Espectrómetro · Ligera · **Mediano** · Baja | Coste 106/100 EXCEDIDO. Botón bloqueado |
| C3 | *Memoria MB* = 100 | Con la Cámara (120 MB por escaneo): bloqueado por memoria. Con el Espectrómetro (60 MB): permitido |
| C4 | *Fracción Contacto* de la órbita baja = 0 | Con esa órbita: bloqueado por "no tiene enlace" |
| C5 | *Escaneos Requeridos* del objetivo = 4 | Permite iniciar. En Exploracion, aviso rojo en el panel de datos y en la Console: solo hay 3 puntos |
| C6 | *Minutos Mision Por Segundo* del catálogo = 2 | Al entrar en Exploracion, aviso amarillo en la Console por escalas de tiempo distintas |

Deshaz los cambios del catálogo al terminar (o restaura desde `CopiasSeguridad`).

## D. Ejecutable y rendimiento

| # | Pasos | Resultado esperado |
|---|---|---|
| D1 | File → Build Profiles: orden de escenas | CentroOperaciones, Configuracion, Exploracion, Resultados (SampleScene, si aparece, se puede desmarcar) |
| D2 | Build en una carpeta **fuera** del proyecto y ejecútalo | Luna con textura, satélite visible, estación con materiales (nada rosa) |
| D3 | F9 en cada escena (editor y ejecutable) | Anota FPS y "peor ms". Referencia del editor en CentroOperaciones: 312 FPS (dato medido por el equipo) |
| D4 | Recorrido A completo en el ejecutable | Igual que en el editor |

## E. Modo equipo

| # | Pasos | Resultado esperado |
|---|---|---|
| E1 | En Configuracion, Jugadores **1** | Sin filas de roles ni aprobaciones. Todas las secciones activas. INICIAR funciona como antes (A2–A4) |
| E2 | Jugadores **2** | Roles: Ciencia J1, Ingeniería J2, Lanzamiento J2, Comunicaciones J1. Turno J1. Batería y Lanzador en gris (no se pueden pulsar) |
| E3 | Turno **J2** | Objetivo, Instrumento y Órbita en gris; Batería y Lanzador activos |
| E4 | Con la referencia, mira las líneas de prioridad | Ciencia SE CUMPLE; Ingeniería NO (margen < 100 Wh); Lanzamiento SE CUMPLE (reserva 28); Comunicaciones SE CUMPLE |
| E5 | Pulsa solo **J1: aprobar** | Botón grande: "FALTAN APROBACIONES: J2", desactivado |
| E6 | Pulsa **J2: aprobar** | "INICIAR MISIÓN" activo |
| E7 | Con ambos aprobados, cambia la batería (turno J2) | Las dos aprobaciones vuelven a "aprobar" |
| E8 | Reasigna Lanzamiento a J1 | Aprobaciones anuladas; en turno J1 el Lanzador queda activo |
| E9 | Jugadores **4** | Un rol por jugador; cuatro botones de aprobación |
| E10 | Inicia y mira el panel de Exploracion | Línea "Equipo: N jugadores", el panel no tapa otros textos |
| E11 | Termina la misión | Resultados: sección "PRIORIDADES DE CADA ROL (N/4)" con [OK]/[X], jugador, plan y resultado real; en POR QUÉ, "El equipo (…) cumplió N de 4 prioridades" |
| E12 | **Volver a configurar** | Mismo número de jugadores y reparto; aprobaciones vacías |
| E13 | Para Play y vuelve a pulsar Play | Jugadores vuelve a 1 |

## F. Nave (activa *Modo Prueba* en ControlNave para acortar los tiempos)

Con la configuración de referencia (lanzador pequeño): combustible 300 + 40 = **340 kg**, masa **6530 kg**.

| # | Pasos | Resultado esperado |
|---|---|---|
| F1 | Configuracion → **Iniciar misión** | Escena Nave en primera persona, cielo azul y plataforma por la ventana. Panel: "Preparación", "[MODO DE PRUEBA]" si está activado |
| F2 | Camina y mira cada consola | Abajo: "E: usar …". Luces ámbar en Comunicaciones, Ingeniería y Ciencia |
| F3 | Pilotaje antes de comprobar nada, Espacio | Aviso "Faltan comprobaciones: …". No despega |
| F4 | Ingeniería (E) | Motor estándar 26 kN, 2,5 kg/s. Masa seca 6000 kg (casco y sistemas 5600 + motor 400), carga científica 190 kg, combustible 340 kg (300 + 40), masa total inicial 6530 kg, aceleración 3,98 m/s², energía 1000 Wh. Espacio: luz verde |
| F5 | Ciencia (E) | Datos de la SONDA: batería 80 Wh, masa 170 kg. Espacio: luz verde |
| F6 | Comunicaciones (E) | Mensaje "Plan de vuelo". Espacio: confirmado, luz verde |
| F7 | Pilotaje, Espacio | Cuenta atrás grande; Q no saca del asiento. Al terminar: vibración, el suelo cae, el cielo se oscurece, aparecen estrellas en movimiento (separación de etapa: sección H) |
| F8 | Tras el ascenso, Q | Puedes caminar por la cabina |
| F9 | Espera la avería (30 % del viaje) | Luces rojas, luz roja en Ingeniería, la energía de la nave baja |
| F10 | Ingeniería: pulsa un número que NO es el circuito en sobrecarga | "Paso equivocado": −40 Wh, vibración. Sigue en el paso 1 |
| F11 | Número correcto → R → Espacio | Palanca roja → ámbar → azul → verde; "Avería reparada"; luces normales |
| F12 | Espera la alerta de escombros | Luces ámbar, luz roja en Pilotaje, aviso con cuenta atrás |
| F13 | Quédate fuera de Pilotaje mientras llegan | Rocas visibles por la ventana; impactos: destello rojo, vibración, casco −25 % |
| F14 | Repite (Repetir) y esquiva desde Pilotaje con WASD | Las rocas se desplazan en la ventana; el combustible baja al empujar y al soltar (estabilizador); cuenta de esquivados |
| F15 | Llegada | La luna crece por la ventana; mensaje en Comunicaciones; Pilotaje pide esperarlo |
| F16 | Confirma el mensaje y vuelve a Pilotaje | Barra con zona verde y marcador. Espacio: "En órbita", combustible restado |
| F17 | Comunicaciones (autorización de despliegue) → Ciencia, Espacio | Cápsula que se aleja por la ventana; después, la transición (sección I) y Exploracion |
| F18 | Termina la exploración | Resultados con sección "VIAJE EN LA NAVE" y explicaciones de impactos, avería, combustible y frenada |
| F19 | Recibe 4 impactos (no esquives) | "MISIÓN ABORTADA" → Resultados **MISIÓN FALLIDA**, "La sonda no llegó a desplegarse" |
| F20 | No repares la avería | Energía de la nave a 0 → misión abortada |
| F21 | Gasta combustible empujando mucho (más de ~35 s a pleno empuje) antes de llegar y frena en el peor momento | Si no alcanza: abortada por falta de combustible. Una sola mala frenada, sin maniobras excesivas, ya no aborta |
| F22 | Referencia con **Lanzador mediano** (coste 90/100) | Ingeniería: combustible **350 kg** (el tope del tanque estándar; 210 kg "no caben en el tanque"), masa total 6540 kg, aceleración 3,98 m/s². *Cambió con el paso del tanque: antes 560 kg* |
| F23 | En el objeto PantallaConfiguracion de Configuracion, desmarca *Pasar Por Nave* | Iniciar misión va directamente a Exploracion, como antes; Resultados sin sección de viaje |

## G. Consecuencias del viaje (Modo Prueba activado; configuración de referencia: batería 80 Wh, coste 72 M USD)

| # | Pasos | Resultado esperado |
|---|---|---|
| G1 | Partida BUENA: separa la etapa en la zona verde, repara la avería rápido y sin errores, esquiva todos los escombros, frena en la zona verde | En órbita: mensaje "Evaluación del viaje" en Comunicaciones: separación +5, reparación +5, escombros +6, puntos de viaje 16; carga de la sonda 80/80 Wh |
| G2 | Antes de desplegar, mira el puesto de Ciencia | Muestra la carga inicial prevista de la sonda |
| G3 | Despliega y mira el panel derecho de Exploracion al empezar | Sin línea "Carga inicial" (no hubo reducción); batería 80/80 |
| G4 | Termina con el objetivo cumplido | PUNTUACIÓN: Ciencia 12 · Objetivo 10 · Presupuesto 14 · Viaje 16 · **TOTAL 52** |
| G5 | Partida CON ERRORES (Repetir): no separes la etapa, tarda en reparar o equivócate dos veces, recibe 2 impactos, frena muy lejos de la zona verde | Evaluación: separación 0, reparación +2 o 0, escombros +0; carga de la sonda menor que 80 y nunca menor que 72 Wh |
| G6 | Mira Ciencia antes de desplegar | "Carga inicial … (−N Wh, N %)" con la explicación de la regla simplificada |
| G7 | Exploracion al empezar | Panel derecho: "Carga inicial: N/80 Wh (descenso prolongado)". El panel de energía empieza en N, la capacidad sigue siendo 80 |
| G8 | Quédate unos 2 s en la estación | La batería sube hasta 80/80 (la recarga funciona igual) |
| G9 | Termina la misión | PUNTUACIÓN con Viaje 0–2; el total no tiene una segunda resta por la carga; VIAJE y POR QUÉ explican la carga inicial aparte |
| G10 | En Exploracion pulsa M → Configuracion → Iniciar y repite el viaje con frenada en la zona verde | Sin reducción: la penalización anterior no se arrastra |
| G11 | Resultados → Repetir con frenada imprecisa y vuelve a mirar el panel de Exploracion | La reducción corresponde solo a la última frenada (no se suma a la anterior) |
| G12 | Pulsa Play directamente en Exploracion | Batería 80/80, sin línea "Carga inicial"; Resultados: "Viaje: 0 (no se pasó por la nave)" |
| G13 | En Configuracion compara antes y después de jugar | Coste 72/100 M USD y carga 190/230 kg iguales; Ingeniería de la nave: combustible 340 kg (sin cambios) |
| G14 | Llegada con frenada en el peor momento y pocas maniobras | Entra en órbita (cuesta unos 250 kg); no aborta |

## H. Separación de etapa (Modo Prueba)

| # | Pasos | Resultado esperado |
|---|---|---|
| H1 | Pilotaje con todo comprobado (antes de la cuenta atrás) | El panel explica el procedimiento: zona verde, Espacio, al menos 2,5 s, "procedimiento simplificado" |
| H2 | Durante la cuenta atrás | El panel muestra el lanzador elegido (p. ej. "Lanzador pequeño"), "Margen de carga configurable: 190 / 230 kg usados (el vehículo tripulado base va incluido)", combustible extra 40 kg, motor y masa total de la nave |
| H3 | Ascenso: espera a la zona verde y pulsa Espacio | Aviso "Separación a tiempo … (+5)", sacudida breve; el ascenso continúa |
| H4 | Repetir: pulsa Espacio antes de la zona verde | "Separación temprana … (0)"; el ascenso continúa |
| H5 | Repetir: no pulses nada | Al cerrarse la ventana: "Sin orden a tiempo: el ordenador separó la etapa tarde … (0)"; el ascenso continúa (se detiene un momento mientras espera) |
| H6 | Llega a la órbita y lee la evaluación | La separación aparece con +5 o +0 según H3–H5 |
| H7 | Resultados | VIAJE: "Despegue: <lanzador> · separación de etapa a tiempo / fuera de la ventana"; POR QUÉ explica el resultado; la línea Viaje la incluye |
| H8 | Configuracion | Coste, masa y presupuesto sin cambios |

## I. Transición de llegada

| # | Pasos | Resultado esperado |
|---|---|---|
| I1 | Despliega la sonda y espera sin pulsar nada | Tres tarjetas: llegada (se ve la luna detrás), sistema de acceso (el módulo baja y se abre el paso en el hielo), descenso (la sonda baja al océano). Después, Exploracion |
| I2 | Repetir y pulsa Espacio en cada tarjeta | Avanza tarjeta a tarjeta |
| I3 | Repetir y pulsa Intro en la primera tarjeta | Pasa directamente a Exploracion |
| I4 | Lee el aviso inferior | Indica que el paso a través del hielo está simplificado y que la luna y la misión son ficticias |
| I5 | Exploracion tras la transición | Igual que antes: carga inicial según la frenada (sección G), sin otros cambios |

## J. Demostración tripulada (ControlNave: *Terminar Al Llegar* activado, valor por defecto)

| # | Pasos | Resultado esperado |
|---|---|---|
| J1 | Recorrido desde CentroOperaciones → Configuracion → Nave | Panel de la nave: "Destino: Luna helada (ficticia)" y "Viaje N % · faltan N M km (simulado: progreso guionizado)" |
| J2 | Llega, frena y confirma "Evaluación del viaje" en Comunicaciones | Llega un mensaje "Objetivo alcanzado" (no la autorización de despliegue) |
| J3 | Confírmalo | Cartel verde "OBJETIVO ALCANZADO"; a los 4 s, Resultados. No se pasa por Exploracion |
| J4 | Resultados (partida buena) | "OBJETIVO ALCANZADO". Evaluación: Llegada 10 · Presupuesto 14 · Viaje 16 · Ciencia "no realizada" · **TOTAL 40**. Secciones NAVE Y RECURSOS y DESEMPEÑO EN EL VIAJE |
| J5 | Puesto de Ciencia en órbita | "La sonda queda a bordo: la exploración es una fase posterior" y Espacio no hace nada |
| J6 | Partida que aborta (4 impactos) | "MISIÓN FALLIDA", todos los puntos a 0, explicación del motivo; sin botón de exploración |
| J7 | Resultados → "EXPLORAR CON LA SONDA (FASE POSTERIOR, OPCIONAL)" | Exploracion con la carga de la sonda según la frenada; al terminar, informe de exploración como antes |
| J8 | Resultados → "REPETIR LA MISIÓN" | Vuelve a la nave en preparación, todo reiniciado |
| J9 | ControlNave: desactiva *Terminar Al Llegar* | Recorrido anterior: despliegue, transición y Exploracion |

## K. Selección de misión (A2) y motor de la nave (B, primera parte)

Configuración estándar de referencia: Cartografiar · Cámara · Batería ligera · Lanzador pequeño · Relevo en órbita baja · **Motor estándar**.

| # | Pasos | Resultado esperado |
|---|---|---|
| K1 | Play en CentroOperaciones → Configurar misión (primera vez) | "SELECCIÓN DE MISIÓN": tarjeta "TRAVESÍA AL HIELO" con destino, objetivo, presupuesto 100 M USD y dificultad Media con 4 condiciones. Dos tarjetas grises "PRÓXIMAMENTE" sin botón |
| K2 | ELEGIR ESTA MISIÓN | Pantalla de configuración; arriba "Misión: Travesía al hielo…" y botón VER MISIÓN |
| K3 | Mira la columna derecha | Vista exterior girando: lanzador a la izquierda ("se separa"), nave a la derecha ("continúa"), motor en el hueco |
| K4 | Referencia (motor estándar) | Coste 72/100; "Margen de carga configurable del lanzador" 190/230 kg; "Nave: masa total inicial 6530 kg (seca 6000 + carga científica 190 + combustible 340)" |
| K5 | Sección 6: **Motor de alto empuje** | La tobera de la vista se hace mayor, con 4 toberas auxiliares y otro color. Coste 80/100; margen 220/230 kg (+30); masa total 6530 kg (seca 6030 + 190 + combustible 310); aceleración 5,51 m/s² |
| K6 | Alto empuje + **Lanzador mediano** | Coste 98/100; margen 220/450 kg; combustible **350 kg** (tope del tanque estándar; 180 kg no caben); masa total 6570 kg; aceleración 5,48 m/s². El lanzador de la vista se alarga. *Cambió con el paso del tanque* |
| K7 | Inicia con alto empuje (lanzador pequeño) y abre Ingeniería | "Motor: Motor de alto empuje · 36 kN · 3,4 kg/s"; masa seca 6030 (casco 5450 + motor 430 + tanque 150); combustible 310; aceleración 5,51 |
| K8 | Escombros: esquiva desde Pilotaje | Responde más rápido que con el estándar; el combustible baja más deprisa al empujar |
| K9 | Resultados | Configuración: "Motor de la nave: Motor de alto empuje · 36 kN · 3,4 kg/s · 8 M USD" y el margen de carga; NAVE: "Masa total inicial … = seca + carga científica + combustible" |
| K10 | Repetir la misión | El motor elegido se conserva |
| K11 | Volver a configurar | Va directo a las piezas (no a la selección); VER MISIÓN vuelve a la tarjeta |

Con el motor y el tanque estándar y el lanzador pequeño, los valores de las pruebas F y G no cambian.

## L. Tanque de la nave (B, segunda parte)

Combustible = mínimo(capacidad del tanque, 300 kg base + margen de carga sobrante). Nunca supera el tanque.

| # | Pasos | Resultado esperado |
|---|---|---|
| L1 | Referencia (lanzador pequeño, motor y tanque estándar) | Igual que antes: coste 72; margen 190/230; combustible 340 de 350; masa total 6530; aceleración 3,98 |
| L2 | Sección 7: **Tanque ampliado** con lanzador pequeño | El tanque de la vista se alarga y ensancha (más bandas naranjas). Margen 240/230 kg: **bloquea INICIAR** ("Margen de carga configurable superado") |
| L3 | Tanque ampliado + **Lanzador mediano** | Coste 96/100; margen 240/450; combustible 510 de 600 kg; masa total 6750 (seca 6050 + 190 + 510); aceleración 3,85 |
| L4 | Tanque ampliado + mediano + **alto empuje** | Coste 104/100: **bloquea INICIAR** por presupuesto |
| L5 | Tanque estándar + mediano | Combustible 350 de 350; texto "el margen daría 210 kg más, pero no caben" |
| L6 | Inicia con L3 y abre Ingeniería | "Tanque: Tanque ampliado · capacidad 600 kg"; masa seca 6050 (casco 5450 + motor 400 + tanque 200); combustible 510 de 600 |
| L7 | Viaje con L3 | Más margen de combustible para maniobrar y frenar que con el estándar |
| L8 | Resultados | "Tanque de la nave: Tanque ampliado · capacidad 600 kg · piezas de la nave 6 M USD" |
| L9 | Repetir / volver a configurar | El tanque elegido se conserva |

## M. Sectores de la cabina (versión reducida; ControlNave → *Mostrar Sectores*)

| # | Pasos | Resultado esperado |
|---|---|---|
| M1 | Entra en la nave | Cuatro rótulos con el número y nombre del sector: 1 PILOTAJE (pared delantera, a la izquierda de la ventana), 2 INGENIERÍA (izquierda), 3 COMUNICACIONES Y NAVEGACIÓN (derecha), 4 CIENCIA / CONTROL DE MISIÓN (fondo) |
| M2 | Mira el suelo y las paredes | Borde luminoso de color en cada sector, tabiques bajos junto a las paredes y una luz del color del sector |
| M3 | Camina entre sectores | Abajo a la izquierda: "Sector N · nombre" o "Pasillo central" y "Nave con puestos para 4 tripulantes · controla 1 jugador" |
| M4 | Desde el asiento de pilotaje | El rótulo y los tabiques no tapan la ventana ni la barra de separación ni la mira |
| M5 | Usa los cuatro puestos (E/Q) | Igual que antes: mismas posiciones, vistas e interacciones |
| M6 | Avería y escombros | Las alertas siguen viéndose (las luces de la cabina se ponen rojas/ámbar; las de sector mantienen su color) |
| M7 | Desmarca *Mostrar Sectores* en ControlNave | La cabina vuelve a verse como antes |

Limitaciones: los tabiques no tienen colisionador (se pueden atravesar si se camina pegado a la pared).
La nave grande con una distribución más amplia queda pendiente.

