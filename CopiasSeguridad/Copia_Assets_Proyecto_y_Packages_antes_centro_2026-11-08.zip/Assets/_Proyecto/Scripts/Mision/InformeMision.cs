using System.Collections.Generic;
using UnityEngine;

namespace PrototipoMision
{
    public enum ResultadoMision { Exito, ExitoParcial, Fracaso }
    public enum MotivoFin { ObjetivoCumplido, BateriaAgotada, TerminadaPorJugador }

    /// <summary>
    /// Foto de la partida al terminar: configuración, energía, datos,
    /// puntuación y explicaciones. La crea ControlMision y la muestra
    /// PantallaResultados. Todas las cifras son de DEMOSTRACIÓN.
    /// </summary>
    public class InformeMision
    {
        /// <summary>Último informe generado. Se borra al pulsar Play.</summary>
        public static InformeMision Ultimo { get; set; }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void Reiniciar() => Ultimo = null;

        public MotivoFin motivo;
        public ResultadoMision resultado;
        public ConfiguracionElegida eleccion;
        public float segundosMision;

        // Configuración
        public string objetivo, instrumento, bateria, lanzador, orbita;
        public bool instrumentoRecomendado;
        public string instrumentoSugerido;
        public float costeMUSD, presupuestoMUSD, masaSondaKg, masaLanzamientoKg, capacidadLanzadorKg;
        public float factorMasa = 1f;

        // Energía (Wh)
        public float capacidadWh, energiaFinalWh, energiaConsumidaWh, energiaRecargadaWh;
        public float energiaEscaneoWh, energiaTransmisionWh, energiaSistemasYMovimientoWh;
        public float bateriaMayorDisponibleWh;
        public float distanciaEstacionFinalM;

        // Datos
        public float memoriaMB, datosRecogidosMB, datosTransmitidosMB, datosPerdidosMB, datosPorEscaneoMB;
        public int escaneosRealizados, escaneosTransmitidos, escaneosRequeridos;
        public int vecesMemoriaLlena;
        public float segundosSinContacto, fraccionContacto;

        // Puntuación
        public int valorPorEscaneo, valorConRecomendado;
        public int puntosCiencia, bonoObjetivo, bonoPresupuesto, puntuacionTotal;
        public int bonoObjetivoConfigurado;
        public float puntosPorMUSDSobrante;

        public readonly List<string> explicaciones = new List<string>();

        public bool ObjetivoCumplido => escaneosTransmitidos >= escaneosRequeridos;
        public bool SondaOperativa => energiaFinalWh > 0f;

        /// <summary>Decide el resultado, calcula la puntuación y redacta las explicaciones.</summary>
        public void Completar()
        {
            if (ObjetivoCumplido) resultado = ResultadoMision.Exito;
            else if (escaneosTransmitidos > 0) resultado = ResultadoMision.ExitoParcial;
            else resultado = ResultadoMision.Fracaso;

            // Balance: final = capacidad − consumida + recargada.
            energiaRecargadaWh = Mathf.Max(0f, energiaFinalWh - capacidadWh + energiaConsumidaWh);
            energiaSistemasYMovimientoWh = Mathf.Max(0f, energiaConsumidaWh - energiaEscaneoWh - energiaTransmisionWh);

            puntosCiencia = Mathf.Max(0, puntosCiencia);
            bonoObjetivo = ObjetivoCumplido ? bonoObjetivoConfigurado : 0;
            bonoPresupuesto = ObjetivoCumplido
                ? Mathf.RoundToInt(Mathf.Max(0f, presupuestoMUSD - costeMUSD) * puntosPorMUSDSobrante)
                : 0;
            puntuacionTotal = puntosCiencia + bonoObjetivo + bonoPresupuesto;

            Explicar();
        }

        void Explicar()
        {
            explicaciones.Clear();

            // 1. Qué pasó
            switch (motivo)
            {
                case MotivoFin.ObjetivoCumplido:
                    explicaciones.Add($"Transmitiste {escaneosTransmitidos} de {escaneosRequeridos} escaneos requeridos en " +
                                      $"{FormatoTiempo(segundosMision)}: el objetivo «{objetivo}» se cumplió.");
                    break;
                case MotivoFin.BateriaAgotada:
                    explicaciones.Add($"La batería se agotó a {distanciaEstacionFinalM:0} m de la estación. " +
                                      "Sin energía, la sonda no pudo moverse ni volver a transmitir.");
                    break;
                case MotivoFin.TerminadaPorJugador:
                    explicaciones.Add($"Terminaste la misión en la estación con {escaneosTransmitidos} de " +
                                      $"{escaneosRequeridos} escaneos transmitidos.");
                    break;
            }

            // 2. Datos que no llegaron
            if (datosPerdidosMB > 0.5f)
                explicaciones.Add($"Se perdieron {datosPerdidosMB:0} MB que seguían en la memoria: los datos solo cuentan " +
                                  "cuando llegan al satélite de relevo, no al recogerlos.");

            // 3. Batería
            if (motivo == MotivoFin.BateriaAgotada)
            {
                if (bateriaMayorDisponibleWh > capacidadWh)
                    explicaciones.Add($"Con la batería de {capacidadWh:0} Wh el margen era corto. Había una de " +
                                      $"{bateriaMayorDisponibleWh:0} Wh, a cambio de más masa y coste; también ayuda volver " +
                                      "a la estación antes de alejarse demasiado.");
                else
                    explicaciones.Add("Ya llevabas la batería de mayor capacidad: la clave era planificar los regresos a la estación.");
            }
            else if (energiaRecargadaWh > capacidadWh * 0.5f)
            {
                explicaciones.Add($"La estación aportó {energiaRecargadaWh:0} Wh, más de la mitad de la batería ({capacidadWh:0} Wh): " +
                                  "volver a recargar fue parte esencial de la misión.");
            }

            // 4. En qué se gastó la energía
            if (energiaConsumidaWh > 0.1f)
            {
                float t = energiaConsumidaWh;
                explicaciones.Add($"Energía usada: {Pct(energiaSistemasYMovimientoWh, t)} en sistemas y movimiento, " +
                                  $"{Pct(energiaEscaneoWh, t)} en escanear y {Pct(energiaTransmisionWh, t)} en transmitir.");
            }

            // 5. Masa
            if (factorMasa < 0.9f)
                explicaciones.Add($"La sonda pesaba {masaSondaKg:0} kg: aceleraba al {factorMasa * 100f:0} % de la de referencia, " +
                                  "lo que alarga cada desplazamiento.");

            // 6. Comunicaciones
            if (segundosSinContacto > 3f)
                explicaciones.Add($"Esperaste {segundosSinContacto:0} s en la estación sin contacto con el relevo " +
                                  $"({orbita}, contacto {fraccionContacto * 100f:0} % del tiempo). Un relevo con contacto " +
                                  "continuo evita esas esperas, pero pesa más en el lanzador.");

            // 7. Memoria
            if (vecesMemoriaLlena > 0)
                explicaciones.Add($"La memoria ({memoriaMB:0} MB) se llenó {vecesMemoriaLlena} " +
                                  (vecesMemoriaLlena == 1 ? "vez" : "veces") +
                                  $": con {instrumento} cada escaneo ocupa {datosPorEscaneoMB:0} MB.");

            // 8. Instrumento
            if (!instrumentoRecomendado)
                explicaciones.Add($"{instrumento} no era el instrumento recomendado para este objetivo ({instrumentoSugerido}): " +
                                  $"cada escaneo valió {valorPorEscaneo} puntos; con el recomendado habría valido más.");

            // 9. Presupuesto
            float sobrante = presupuestoMUSD - costeMUSD;
            if (ObjetivoCumplido && sobrante > 0f)
                explicaciones.Add($"Gastaste {costeMUSD:0} de {presupuestoMUSD:0} M USD: los {sobrante:0} M USD sobrantes " +
                                  $"suman {bonoPresupuesto} puntos.");
            else if (!ObjetivoCumplido && sobrante > 0f)
                explicaciones.Add("El presupuesto sobrante no suma puntos porque el objetivo no se cumplió.");
        }

        static string Pct(float parte, float total) => total > 0f ? $"{parte / total * 100f:0} %" : "0 %";

        public static string FormatoTiempo(float segundos)
        {
            int s = Mathf.Max(0, Mathf.RoundToInt(segundos));
            return $"{s / 60}:{s % 60:00}";
        }
    }
}
