# Prototipo de misión — guía rápida del equipo

Nombre del proyecto provisional: `PrototipoMisionSonda`.
Motor: Unity 6.3 LTS (6000.3.28f1) · URP · Windows · Input System (New).

## Qué hay hasta ahora

- **Incremento 1:** sonda en primera persona, estación que recarga, energía, interfaz mínima.
- **Incremento 2:** pantalla de configuración (objetivo, instrumento, batería, lanzador,
  órbita de relevo) con límites de presupuesto y de masa. La batería y la masa elegidas
  se aplican en la exploración.
- **Incremento 3:** escáner (tecla E), 3 puntos científicos con fichas, memoria de datos y
  transmisión desde la estación según la órbita elegida.
- **Centro de operaciones:** escena inicial con la estación orbital propia, una luna de fondo
  y el satélite de relevo. Solo visual: no cambia las mecánicas.
- **Incremento 4:** informe de resultados (éxito, parcial o fracaso) con explicaciones,
  puntuación de demostración y botones para reconfigurar o repetir.

## Menús de creación (Prototipo)

| Menú | Qué hace |
|---|---|
| 1. Crear escena de exploración | Crea `Scenes/Exploracion` (pregunta antes de sustituir) |
| 2. Crear escena de configuración | Crea `Data/CatalogoMision` (si no existe) y `Scenes/Configuracion` |
| 3. Conectar configuración a Exploracion | **Añade** el objeto AplicadorConfiguracion a Exploracion |
| 4. Añadir ciencia a Exploracion | Crea fichas y el prefab PuntoCientifico; **añade** SistemaCiencia y 3 puntos |
| 5. Crear resultados y conectar Exploracion | Crea `Scenes/Resultados`; **añade** ControlMision a Exploracion |
| 6. Crear centro de operaciones | Crea `Scenes/CentroOperaciones` y la pone primera en la compilación |
| 7. Ajustar encuadre del centro de operaciones | Mueve estación, luna, satélite y Sol a la disposición calculada. **No guarda**: Ctrl+S para guardar, Ctrl+Z para deshacer |
| 8. Crear escena Nave | Crea `Data/CatalogoNave` (si no existe) y `Scenes/Nave`, y la pone en la compilación después de Configuracion |

Orden del juego: **CentroOperaciones → Configuracion → Nave → Exploracion → Resultados**.
Si la escena Nave no existe o no está en la compilación, Configuracion va directamente a Exploracion.

Recursos externos: solo los de `Externos/NASA`. Sus créditos y condiciones están en
`CREDITOS.md`. **Antes de añadir otro recurso externo, regístralo ahí.**

Para jugar el recorrido completo: abre `Scenes/Configuracion` y pulsa **Play**.
Si pulsas Play directamente en Exploracion, se usan las primeras opciones del catálogo.

## Tareas sin programar

| Quiero… | Dónde |
|---|---|
| Cambiar presupuesto, costes, masas, baterías, instrumentos… | `Data/CatalogoMision` |
| Añadir una opción (p. ej. un tercer instrumento) | `Data/CatalogoMision` → botón **+** de la lista |
| Cambiar o añadir objetivos científicos | `Data/CatalogoMision` → lista **Objetivos** |
| Cambiar el texto o la imagen de una ficha | `Data/Fichas` → selecciona la ficha |
| Crear una ficha nueva | Clic derecho en `Data/Fichas` → **Create → Prototipo → Ficha científica** |
| Añadir un punto escaneable | Arrastra `Prefabs/PuntoCientifico` a la escena y asígnale una ficha |
| Mover un punto científico | Objeto **PuntosCientificos** de la escena → selecciona el punto y muévelo |
| Cambiar alcance del escáner o ventanas de contacto | Objeto **SistemaCiencia** → **Escaner** y **Sistema Datos** |
| Cambiar bonos de la puntuación | `Data/CatalogoMision` → **Puntuación del informe** |
| Cambiar esperas antes del informe o textos de fin | Objeto **ControlMision** de Exploracion |
| Cambiar títulos del informe | Escena Resultados → **PantallaResultados** |
| Cambiar textos de la pantalla inicial | Escena CentroOperaciones → **CentroOperaciones** |
| Mover la luna, la estación o el satélite | Escena CentroOperaciones; la velocidad está en **Movimiento Visual** |
| Cambiar el aspecto de la estación orbital | Doble clic en `Prefabs/EstacionOrbital` |
| Cambiar los consumos de la sonda o la recarga | `Prefabs/Sonda` → **Sistema Energia** |
| Cambiar velocidad, masa de referencia o ratón | `Prefabs/Sonda` → **Controlador Sonda** |
| Mover la estación | Selecciónala en la escena y muévela (herramienta Move, tecla W) |
| Cambiar el aspecto de la estación | Doble clic en `Prefabs/Estacion` |
| Cambiar textos de la interfaz | **Interfaz → Hud Minimo** y **PantallaConfiguracion** |
| Cambiar colores | Carpeta `Materials` → campo **Base Map** |
| Mover rocas o plantas | Objetos **Rocas** y **PlantasLuminosas** de la escena |

**Atención:** la capacidad de la batería ahora la decide el catálogo. El campo
*Capacidad Wh* de Sistema Energia solo se usa si falta el AplicadorConfiguracion.

Pasa el ratón sobre cada campo del Inspector para ver su explicación y sus unidades.

## Qué decisión afecta a qué

| Decisión | Efecto | Estado |
|---|---|---|
| Batería | Capacidad de energía (Wh) | APLICADO |
| Instrumento + batería | Masa de la sonda → aceleración | APLICADO |
| Todo | Coste total frente al presupuesto | APLICADO (bloquea) |
| Instrumento + batería + órbita | Carga frente a la capacidad del lanzador | APLICADO (bloquea) |
| Instrumento | Consumo, duración y MB de cada escaneo | APLICADO |
| Sonda base | Memoria: si se llena, no se puede escanear | APLICADO |
| Órbita | Velocidad de transmisión y ventanas de contacto | APLICADO |
| Objetivo | Escaneos que hay que transmitir | APLICADO |
| Objetivo + instrumento | Valor científico (×2 con el instrumento recomendado) | APLICADO |
| Todo | Informe final con explicación y puntuación | APLICADO |

El lanzador y la órbita **no** se simulan físicamente: solo cambian coste, masa y
velocidad de transmisión.

### Qué bloquea el botón INICIAR MISIÓN

1. Coste total mayor que el presupuesto.
2. Carga (sonda + satélite de relevo) mayor que la capacidad del lanzador.
3. Memoria menor que los datos de un solo escaneo del instrumento elegido.
4. Órbita sin enlace (velocidad o fracción de contacto en 0).
5. Objetivo con menos de 1 escaneo requerido.

Las reglas 3 a 5 solo pueden aparecer si se editan los valores del catálogo.
Avisos que **no** bloquean: instrumento no recomendado, datos previstos mayores que la
memoria (habrá que volver a transmitir) y escanear más de la mitad de la batería.

### Masa: qué cuenta dónde

- **Carga en el lanzador** = sonda + satélite de relevo. Se compara con la capacidad del lanzador.
- **Masa de la sonda** = estructura + instrumento + batería. Es la que cambia la aceleración
  en la exploración (referencia: 170 kg en *Controlador Sonda*).

### Avisos al editar valores

- La escala de tiempo está en dos sitios: *Minutos Mision Por Segundo* del catálogo (solo para
  estimaciones) y de *Sistema Energia* en el prefab Sonda (la que usa el juego). Deben
  coincidir; si no, la Console lo avisa al empezar la exploración.
- Si el objetivo pide más escaneos que puntos científicos hay en la escena, la Console y el
  panel de datos lo avisan: el objetivo sería imposible.
- El catálogo guardado aún no incluye los campos añadidos después de crearlo (consumo de
  transmisión, multiplicador del instrumento recomendado y bonos de puntuación). Unity usa
  sus valores por defecto (25 W, ×2, +10 y 0,5). Se ven en el Inspector al seleccionar el
  catálogo y se escribirán en el archivo la próxima vez que se modifique y guarde.

## Escena Nave (primera persona)

Nave tripulada **ficticia** y viaje **comprimido**: DEMOSTRACIÓN. Los escombros son un peligro
ficticio localizado, no una descripción del cinturón de asteroides.

Recorrido: **preparación → despegue → viaje con eventos → llegada y entrada en órbita → despliegue de la sonda**.

| Puesto | Qué se hace | Rol del modo equipo (para el futuro) |
|---|---|---|
| Pilotaje (frente, ventana) | Despegar; esquivar escombros con WASD; frenar para entrar en órbita (Espacio en la zona verde) | Lanzamiento |
| Ingeniería (izquierda) | Revisar los datos de la nave; reparar la avería: aislar circuito (1/2/3) → reserva (R) → restablecer (Espacio) | Ingeniería |
| Comunicaciones (derecha) | Recibir y confirmar las instrucciones del centro (Espacio) | Comunicaciones |
| Ciencia (fondo) | Revisar la sonda; desplegarla en órbita | Ciencia |

Controles: **WASD** caminar · **ratón** mirar · **E** usar el puesto que miras · **Q** salir del puesto ·
**Espacio** acción principal del puesto · clic para recuperar el ratón.
La luz de cada puesto indica: ámbar = tarea pendiente, roja = alarma, verde = correcto.

Consecuencias visibles: impactos (destello rojo, vibración, casco −25 %), avería (luces rojas,
pérdida de energía), combustible gastado en maniobras y frenada. La misión **se aborta** si el casco
llega a 0 %, si la energía de la nave llega a 0 o si no queda combustible para frenar.

**Datos de la nave separados de la sonda** (asset `Data/CatalogoNave`). Reglas de demostración:
1. La carga científica (sonda + relevo) viaja a bordo.
2. La capacidad sobrante del lanzador se llena con combustible extra (1 kg por kg).
3. Masa de la nave = masa seca + combustible + carga científica.
4. Aceleración de maniobra = empuje / masa.
5. Combustible para frenar = base (180 kg) × masa actual / masa de referencia, más hasta un 40 % si se frena fuera de tiempo.
La batería de la sonda sigue siendo solo de la sonda; la nave tiene su propia energía.

**Consecuencias del viaje** (evaluación al entrar en órbita, antes de desplegar; DEMOSTRACIÓN):

| Acción | Resultado | Consecuencia |
|---|---|---|
| Reparar la avería | energía de la nave perdida ≤ 25 % / ≤ 50 % / más | +5 / +2 / 0 puntos de viaje |
| Escombros | 0 impactos / 1 / 2 o más | +6 / +3 / 0 puntos de viaje |
| Separar la etapa (Pilotaje, durante el ascenso) | dentro de la ventana verde / antes / sin pulsar | +5 / 0 (temprana) / 0 (el ordenador la separa tarde). Siempre se continúa. Procedimiento simplificado: solo cuenta en la evaluación |
| Frenar para entrar en órbita | zona verde / fuera | **sin puntos**: la sonda empieza con hasta un 10 % menos de carga (regla simplificada: descenso prolongado). La capacidad máxima no cambia y la estación recarga igual |

Los puntos de viaje solo cuentan si la sonda se despliega. El presupuesto no cambia: se valida solo en
Configuracion y su bono se mantiene igual. Resultados muestra por separado ciencia, objetivo,
presupuesto, viaje y total. Umbrales y puntos: asset `CatalogoNave` (sección *Puntos de viaje*).

La sonda empieza en (0, 2, 0), **dentro** de la zona de recarga de la estación (esfera de 6 m):
la carga perdida en el descenso se recupera en unos 2 s si la sonda se queda allí (300 W de recarga).

**Separación de etapa**: el panel de Pilotaje la explica antes de la cuenta atrás. Durante el ascenso
aparece una barra; pulsa Espacio cuando el marcador esté en la zona verde (al menos 2,5 s, también en
modo de prueba). El ascenso espera a que se resuelva. El panel muestra el lanzador elegido, la carga y
el combustible extra. Ajustes en ControlNave: *Inicio Ventana Etapa*, *Ventana Etapa Minima S*, *Puntos Separacion*.

**Transición de llegada**: tras desplegar la sonda, tres tarjetas (llegada, sistema de acceso, descenso
al océano) con un corte esquemático animado. Espacio: siguiente · Intro: omitir. Aclara que el paso por
el hielo está simplificado. Es solo visual (`TransicionDescenso.cs`, la crea ControlNave en tiempo de
ejecución; no hay objetos nuevos en la escena). Se desactiva con *Mostrar Transicion* en ControlNave.

**Modo de prueba**: en el objeto ControlNave (escena Nave), casilla *Modo Prueba*. Usa los
*Tiempos Prueba* (cuenta atrás 3 s, viaje 40 s) en lugar de los *Tiempos Normales* (10 s, 150 s).
Los momentos de la avería y de los escombros también se editan ahí.

## Modo equipo (1 a 4 jugadores en el mismo PC)

Estado: código conservado; su ampliación está en pausa mientras se construye la nave.

En la pantalla de configuración, bloque **EQUIPO**:

- **Jugadores**: 1 a 4. Con 1 jugador todo funciona como antes.
- **Roles**: cada rol tiene un responsable (J1…J4) y se puede reasignar.
  | Rol | Decide | Prioridad (umbral en el catálogo, DEMOSTRACIÓN) |
  |---|---|---|
  | Ciencia | Objetivo e instrumento | Usar el instrumento recomendado |
  | Ingeniería | Batería | Margen tras escanear ≥ *Margen Energia Minimo Wh* (100) |
  | Lanzamiento | Lanzador | Reserva de presupuesto ≥ *Reserva Presupuesto Minima MUSD* (20) |
  | Comunicaciones | Órbita del relevo | Transmitir todo en ≤ *Tiempo Transmision Maximo S* (20 s) |
- Reparto inicial: 2 jugadores → J1 Ciencia + Comunicaciones, J2 Ingeniería + Lanzamiento;
  3 → J2 lleva Ingeniería y Lanzamiento; 4 → un rol cada uno.
- **Turno**: el jugador que tiene el teclado. Solo puede cambiar las secciones de sus roles.
- **Aprobaciones**: para iniciar, todos deben pulsar su botón. Cualquier cambio de opción,
  de jugadores o de reparto anula las aprobaciones.
- Las prioridades **no bloquean** el inicio. Con los valores actuales ninguna configuración
  válida cumple las cuatro a la vez: el equipo tiene que negociar cuál ceder.
- El informe final muestra, por rol, si el plan cumplía su prioridad y qué pasó de verdad.

Por qué en el mismo PC: en clase o en el evento el equipo comparte una pantalla y discute en
voz alta. El juego reparte la responsabilidad y obliga a llegar a un acuerdo; no hay red.

Archivos: `Scripts/Equipo/ModoEquipo.cs` (roles y prioridades), cambios en
`PantallaConfiguracion`, `ControlMision`, `InformeMision`, `PantallaResultados`,
`AplicadorConfiguracion` y tres campos nuevos en `CatalogoMision`.

## Controles

| Tecla | Acción |
|---|---|
| WASD / Espacio / Ctrl o C / Shift | Mover, subir, bajar, turbo |
| Ratón | Mirar |
| E (mantener) | Escanear el punto apuntado |
| F | Cerrar la ficha |
| T (en la estación) | Terminar la misión y ver el informe |
| M | Volver a la configuración |
| F9 | Mostrar u ocultar el medidor de rendimiento (FPS), en cualquier escena y en el ejecutable |
| Esc / clic | Liberar / recuperar el cursor |

**Probar la interfaz:** usa la vista Game con resolución fija 16:9 (por ejemplo 1920×1080) y
*Scale* en 1x. La interfaz se escala según la altura de la ventana: en ventanas muy bajas
(unos 500 px) los textos pequeños dejan de ser legibles.

**Pruebas de aceptación:** ver `PRUEBAS_ACEPTACION.md`.

## Unidades

- **M USD:** millones de dólares.
- **kg:** masa.
- **W (vatio):** cuánta energía se gasta en cada instante.
- **Wh (vatio-hora):** cuánta energía hay guardada. 1 Wh = 1 W durante 1 hora.
- **MB / MB/s:** cantidad de datos y velocidad de transmisión.
- **Datos recogidos:** guardados en la memoria de la sonda. **Datos transmitidos:** enviados al
  satélite de relevo desde la estación. Solo los transmitidos cuentan para el objetivo.
- **Escala de tiempo:** 1 segundo real = 1 minuto de misión (editable).

Todos los valores son de **DEMOSTRACIÓN**. No proceden de ninguna misión real.

## Licencias (pendiente de decidir y verificar)

| Tipo | Elemento | Estado |
|---|---|---|
| Código propio | `Scripts/` y `Editor/` | Licencia OSI por elegir (p. ej. MIT o Apache-2.0) |
| Dependencias del motor | Unity Editor, URP, Input System | Términos de Unity; confirmar cada paquete en el Package Manager |
| Recursos de terceros | Textura de Europa y modelo TDRS (NASA 3D Resources) | Ver `CREDITOS.md` |
| Datos científicos | Ninguno hasta ahora; las fichas son textos ficticios marcados DEMOSTRACIÓN | Si se añaden datos reales, anotar la fuente en cada ficha |
| Valores de demostración | Catálogo de misión, consumos, recarga, escala de tiempo | Marcados como DEMOSTRACIÓN |

Pendiente de verificar con la organización: si depender de un motor no OSI
(Unity) es aceptable según las reglas de entrega de NASA Space Apps 2026.

## Muestra visual: sector delantero de la nave (en evaluación)

Estilo: exploración de ciencia ficción, azul y turquesa con acentos naranja cálido. Formas, texturas y
materiales generados por el propio proyecto (sin recursos de otros juegos). Las formas simples siguen
siendo provisionales fuera de este sector.

- Aplicar: escena **Nave** abierta, fuera de Play → *Prototipo → Muestra visual → 1. Aplicar: sector delantero de la nave*. Después, Ctrl+S.
- Quitar: *… → 1. Quitar: sector delantero de la nave*. Restaura lo ocultado, la luz ambiental y el posprocesado de la cámara. Después, Ctrl+S.
- Todo cuelga de `VISUAL_MUESTRA_NAVE`; ninguna pieza tiene colisionador. Se ocultan (no se borran) la consola y la pantalla de pilotaje (sus colisionadores siguen) y los listones antiguos de la ventana.
- Recursos en `Assets/_Proyecto/Visual/` (texturas, materiales `MV_…`, perfil `PerfilCabina`). Se crean solo si no existen: se pueden retocar en el Inspector sin que el menú los sobrescriba.
- Scripts visuales (`Scripts/Visual/`): `PantallaDatosNave` (las pantallas muestran datos de ControlNave, solo lectura), `LucesReactivasVisual` (las tiras de luz siguen el color de las luces de alerta), `CapaVisual` (registro para quitar la muestra).

## Demostración tripulada (recorrido principal)

Configuracion → Nave (preparación, despegue, viaje, llegada) → **Resultados**. Al entrar en órbita y
confirmar el mensaje "Objetivo alcanzado", la misión termina. La exploración con la sonda queda como
fase posterior opcional (botón en Resultados).

Evaluación de la misión tripulada (DEMOSTRACIÓN, separada de la de exploración): llegada al destino
(+10, *Puntos Llegada* en ControlNave) + presupuesto sobrante (0,5 por M USD, solo si se llega) +
puntos de viaje (separación, reparación, escombros). **No incluye ciencia**: no se dan por hechos los escaneos.

El panel de la nave muestra siempre el destino y la distancia restante. La distancia es simulada
(*Distancia Simulada Mkm*): el progreso del viaje es guionizado.

Para volver al recorrido con exploración: desactiva *Terminar Al Llegar* en ControlNave.

## Selección de misión y piezas de la nave

- La primera vez, Configuracion muestra la **selección de misión** (una misión completa y dos "Próximamente").
  Datos en `CatalogoMision` → *Misión seleccionable*.
- **Motor de la nave** (sección 6): datos en `CatalogoNave` → *Motores* (el primero es el estándar). Coste al
  presupuesto; la masa **de más** sobre el estándar cuenta en el **margen de carga configurable** del lanzador
  (el vehículo tripulado base se considera incluido: simplificación). El empuje y el consumo se usan en las maniobras.
- **Tanque de la nave** (sección 7): datos en `CatalogoNave` → *Tanques*. Coste al presupuesto; la masa en vacío
  de más sobre el estándar cuenta en el margen de carga. Pone el **tope** del combustible.
- Masas de la nave: seca (*Masa Casco Kg* 5450 + motor + tanque vacío) + carga científica (sonda + relevo) +
  combustible = masa total inicial. Combustible = mínimo(capacidad del tanque, 300 base + margen sobrante, 1 kg por kg):
  el tanque no añade combustible por otra vía. La aceleración usa la masa total actual.
- `CatalogoMision` enlaza `CatalogoNave` (campo *Catalogo Nave*). Si falta, no se muestran piezas de la nave.
- Vista exterior: `Scripts/Visual/VistaNaveConfiguracion.cs`, creada en tiempo de ejecución (no hay objetos en la escena).

## Sectores de la cabina (versión reducida para la demostración)

`Scripts/Nave/SectoresNave.cs`, creado por ControlNave al empezar (casilla *Mostrar Sectores*). Rótulos, bordes
luminosos en el suelo, tabiques bajos y una luz por sector. No mueve puestos, vistas ni colisionadores y no añade
colisionadores. Sectores: 1 Pilotaje · 2 Ingeniería · 3 Comunicaciones y navegación · 4 Ciencia / control de misión.
Un jugador controla la nave; hay puestos para cuatro tripulantes (sin multijugador). La nave grande queda pendiente.

## Nave ampliada (menú 9) y restauración (menú 10)

Plano (vista desde arriba, z hacia la ventana; interior de 10,4 × 19 m, 3 m de alto):

```
              z=+5   ┌──────── VENTANA ────────┐
                     │      1  PILOTAJE        │  x ±4
              z=+1,5 └────────┐     ┌──────────┘
 ┌──────────────┐             │     │             ┌──────────────┐
 │ 4  CIENCIA / ├── puerta ───┤  P  ├── puerta ───┤ 3 COMUNIC. Y │  salas 4 × 4 m
 │ CONTROL      │             │  A  │             │ NAVEGACIÓN   │  (z −3,5 … +0,5)
 └──────────────┘             │  S  │             └──────────────┘
                              │  I  │  pasillo 2,4 m
              z=−9   ┌────────┘  L  └──────────┐
                     │      2  INGENIERÍA      │  x ±3,5
                     │  ═══ barandilla ═══     │
                     │  (tanque)     (motor)   │
              z=−14  └─────────────────────────┘
```

- **Aplicar**: escena Nave abierta, fuera de Play → *Prototipo → 9. Ampliar nave (4 sectores y pasillo)* → Ctrl+S.
  Copia la escena en `CopiasSeguridad/` antes de cambiarla. Si ya está ampliada, pregunta y la rehace.
- Desactiva (no borra) las paredes laterales y trasera originales; añade paredes, suelos y techos CON colisionador;
  mueve Ingeniería, Comunicaciones y Ciencia (con su vista); añade 4 luces a las alertas de ControlNave; sube el
  aviso de escombros del modo de prueba de 4 a 8 s. Pilotaje y la ventana no cambian.
- **Volver**: *Prototipo → 10. Volver a la cabina original* → Ctrl+S. Restaura todo lo anterior y borra NAVE_AMPLIADA.
- Escombros: se evalúan una vez en la proa (z = 5,3) y desaparecen; no atraviesan las salas.
- **No uses** el menú 8 (regenera la escena) ni la muestra visual antigua (pensada para la cabina pequeña).

## Acabado de la cabina de pilotaje (menú 11)

Capa visual reversible sobre la nave ampliada: *Prototipo → 11. Acabado: cabina de pilotaje (aplicar / quitar)*,
fuera de Play y con la escena Nave abierta; después Ctrl+S. Todo cuelga de `ACABADO_CABINA_PILOTAJE`, sin
colisionadores. Reutiliza los generadores de texturas y materiales (`Assets/_Proyecto/Visual/`, se crean la primera
vez) y la consola de `MuestraVisual`. Oculta (no borra) la consola y pantalla antiguas de pilotaje, los listones de
la ventana y el rótulo flotante "PILOTAJE". No cambia la luz ambiental; activa un posprocesado moderado.
La muestra antigua (*Muestra visual → 1.*) ya no se aplica sobre la nave ampliada.


## Despegue visto desde fuera

`CinematicaDespegue` (la añade ControlNave al empezar si *Mostrar Despegue Exterior* está activado; no está en la
escena). En los últimos 3 s de la cuenta atrás cambia a una cámara exterior: plataforma, encendido, humo, ascenso con
el cielo oscureciéndose, separación del lanzador (la orden sigue siendo Espacio en Pilotaje, sin cambios de reglas),
alejamiento con el planeta debajo y fundido de vuelta a la cabina. Intro vuelve antes. El decorado se crea lejos de la
cabina (y = −20 000) y se destruye al terminar. La nave usa el motor y el tanque elegidos con las mismas formas que la
vista de Configuracion. Planeta, altitud y velocidad son ficticios e ilustrativos (DEMOSTRACIÓN). Sonido generado por
código (sin archivos ni licencias): rumor del motor y golpe de separación; se puede sustituir más adelante por sonidos
con licencia verificada. Mientras dura la toma, HudNave oculta sus paneles laterales.

## Observación de aproximación (bonus aparte)

Durante el crucero se abre una ventana (por defecto entre el 40 % y el 56 % del viaje). En **Ciencia**, mantener
Espacio captura datos (UD) y gasta energía de la **nave** (21 Wh por UD; 12 UD como máximo ≈ 252 Wh, una cuarta parte
de la energía inicial de la nave, `CatalogoNave → energiaNaveWh` = 1000 Wh; la batería de la sonda no se toca). En
**Comunicaciones**, mantener Espacio envía los datos; solo cuentan los enviados antes de llegar. Da un bonus aparte de
0 a 6 que **no suma** a la puntuación principal (sobre 40) ni cambia sus criterios. La energía gastada en observar no
cuenta como pérdida de la avería.

- Lógica: `Scripts/Nave/ObservacionAproximacion.cs` (sin dibujo). HUD, paneles e informe solo leen su estado
  (`ControlNave.Observacion`), así que las pantallas de los modelos nuevos pueden mostrar lo mismo sin tocar la lógica.
- Ajustes en ControlNave → *Observacion*: activa, inicio y duración de la ventana (fracciones del viaje), máximo de UD,
  captura y envío por segundo, coste en Wh por UD y puntos del bonus. Valores provisionales de prueba.
- Desactivado: sin ventana, avisos, consumos ni interacción; el juego queda como antes.
- Pruebas: sección Q de PRUEBAS_ACEPTACION.

## Corrección de trayectoria antes del frenado (opcional)

Al final del crucero, con la avería reparada y los escombros terminados (desde el 85 % del viaje), se abre una ventana
de duración fija (22 s; 18 s en Modo Prueba). Delante aparece un anillo: el corredor de entrada, a 5–9 m de la
posición de la nave. En Pilotaje, con WASD (los mismos propulsores y el mismo gasto que con los escombros), hay que
centrarlo y permanecer 2 s seguidos dentro de 1,5 m. Si se completa en la primera mitad de la ventana, el marcador de
la inserción orbital va más lento (periodo 3,3 s); en la segunda mitad, 2,75 s; sin corregir, 2,2 s como siempre. No da
puntos ni cambia la puntuación principal ni el bonus de observación. La llegada espera a que termine la ventana.

- Lógica: `Scripts/Nave/CorredorAproximacion.cs` (sin dibujo). Vista: `Scripts/Nave/VistaCorredor.cs` (anillo de
  balizas que se coloca como los escombros: corredor menos desplazamiento lateral). Sustituible por un modelo.
- Ajustes en ControlNave → *Correccion* (todos provisionales). Desactivado: sin anillo, avisos, consumos ni demora.
- El combustible gastado en maniobras durante la ventana se mide y se muestra; no hay consumo nuevo.
- Pruebas: sección R de PRUEBAS_ACEPTACION.
