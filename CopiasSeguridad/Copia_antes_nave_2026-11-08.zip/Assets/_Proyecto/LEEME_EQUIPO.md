# Prototipo de misión — guía rápida del equipo

Nombre del proyecto provisional: `PrototipoMisionSonda`.
Motor: Unity 6.3 LTS (6000.3.28f1) · URP · Windows · Input System (New).

## Qué hay hasta ahora

- **Incremento 1:** sonda en primera persona, estación que recarga, energía, interfaz mínima.
- **Incremento 2:** pantalla de configuración (objetivo, instrumento, batería, lanzador,
  órbita de relevo) con límites de presupuesto y de masa. La batería y la masa elegidas
  se aplican en la exploración.
- **Incremento 3:** escáner (tecla E), 3 puntos científicos con fichas, memoria de datos y
  transmisión desde la estación según la órbita elegida.
- **Centro de operaciones:** escena inicial con la estación orbital propia, una luna de fondo
  y el satélite de relevo. Solo visual: no cambia las mecánicas.
- **Incremento 4:** informe de resultados (éxito, parcial o fracaso) con explicaciones,
  puntuación de demostración y botones para reconfigurar o repetir.

## Menús de creación (Prototipo)

| Menú | Qué hace |
|---|---|
| 1. Crear escena de exploración | Crea `Scenes/Exploracion` (pregunta antes de sustituir) |
| 2. Crear escena de configuración | Crea `Data/CatalogoMision` (si no existe) y `Scenes/Configuracion` |
| 3. Conectar configuración a Exploracion | **Añade** el objeto AplicadorConfiguracion a Exploracion |
| 4. Añadir ciencia a Exploracion | Crea fichas y el prefab PuntoCientifico; **añade** SistemaCiencia y 3 puntos |
| 5. Crear resultados y conectar Exploracion | Crea `Scenes/Resultados`; **añade** ControlMision a Exploracion |
| 6. Crear centro de operaciones | Crea `Scenes/CentroOperaciones` y la pone primera en la compilación |
| 7. Ajustar encuadre del centro de operaciones | Mueve estación, luna, satélite y Sol a la disposición calculada. **No guarda**: Ctrl+S para guardar, Ctrl+Z para deshacer |

Orden del juego: **CentroOperaciones → Configuracion → Exploracion → Resultados**.

Recursos externos: solo los de `Externos/NASA`. Sus créditos y condiciones están en
`CREDITOS.md`. **Antes de añadir otro recurso externo, regístralo ahí.**

Para jugar el recorrido completo: abre `Scenes/Configuracion` y pulsa **Play**.
Si pulsas Play directamente en Exploracion, se usan las primeras opciones del catálogo.

## Tareas sin programar

| Quiero… | Dónde |
|---|---|
| Cambiar presupuesto, costes, masas, baterías, instrumentos… | `Data/CatalogoMision` |
| Añadir una opción (p. ej. un tercer instrumento) | `Data/CatalogoMision` → botón **+** de la lista |
| Cambiar o añadir objetivos científicos | `Data/CatalogoMision` → lista **Objetivos** |
| Cambiar el texto o la imagen de una ficha | `Data/Fichas` → selecciona la ficha |
| Crear una ficha nueva | Clic derecho en `Data/Fichas` → **Create → Prototipo → Ficha científica** |
| Añadir un punto escaneable | Arrastra `Prefabs/PuntoCientifico` a la escena y asígnale una ficha |
| Mover un punto científico | Objeto **PuntosCientificos** de la escena → selecciona el punto y muévelo |
| Cambiar alcance del escáner o ventanas de contacto | Objeto **SistemaCiencia** → **Escaner** y **Sistema Datos** |
| Cambiar bonos de la puntuación | `Data/CatalogoMision` → **Puntuación del informe** |
| Cambiar esperas antes del informe o textos de fin | Objeto **ControlMision** de Exploracion |
| Cambiar títulos del informe | Escena Resultados → **PantallaResultados** |
| Cambiar textos de la pantalla inicial | Escena CentroOperaciones → **CentroOperaciones** |
| Mover la luna, la estación o el satélite | Escena CentroOperaciones; la velocidad está en **Movimiento Visual** |
| Cambiar el aspecto de la estación orbital | Doble clic en `Prefabs/EstacionOrbital` |
| Cambiar los consumos de la sonda o la recarga | `Prefabs/Sonda` → **Sistema Energia** |
| Cambiar velocidad, masa de referencia o ratón | `Prefabs/Sonda` → **Controlador Sonda** |
| Mover la estación | Selecciónala en la escena y muévela (herramienta Move, tecla W) |
| Cambiar el aspecto de la estación | Doble clic en `Prefabs/Estacion` |
| Cambiar textos de la interfaz | **Interfaz → Hud Minimo** y **PantallaConfiguracion** |
| Cambiar colores | Carpeta `Materials` → campo **Base Map** |
| Mover rocas o plantas | Objetos **Rocas** y **PlantasLuminosas** de la escena |

**Atención:** la capacidad de la batería ahora la decide el catálogo. El campo
*Capacidad Wh* de Sistema Energia solo se usa si falta el AplicadorConfiguracion.

Pasa el ratón sobre cada campo del Inspector para ver su explicación y sus unidades.

## Qué decisión afecta a qué

| Decisión | Efecto | Estado |
|---|---|---|
| Batería | Capacidad de energía (Wh) | APLICADO |
| Instrumento + batería | Masa de la sonda → aceleración | APLICADO |
| Todo | Coste total frente al presupuesto | APLICADO (bloquea) |
| Instrumento + batería + órbita | Carga frente a la capacidad del lanzador | APLICADO (bloquea) |
| Instrumento | Consumo, duración y MB de cada escaneo | APLICADO |
| Sonda base | Memoria: si se llena, no se puede escanear | APLICADO |
| Órbita | Velocidad de transmisión y ventanas de contacto | APLICADO |
| Objetivo | Escaneos que hay que transmitir | APLICADO |
| Objetivo + instrumento | Valor científico (×2 con el instrumento recomendado) | APLICADO |
| Todo | Informe final con explicación y puntuación | APLICADO |

El lanzador y la órbita **no** se simulan físicamente: solo cambian coste, masa y
velocidad de transmisión.

### Qué bloquea el botón INICIAR MISIÓN

1. Coste total mayor que el presupuesto.
2. Carga (sonda + satélite de relevo) mayor que la capacidad del lanzador.
3. Memoria menor que los datos de un solo escaneo del instrumento elegido.
4. Órbita sin enlace (velocidad o fracción de contacto en 0).
5. Objetivo con menos de 1 escaneo requerido.

Las reglas 3 a 5 solo pueden aparecer si se editan los valores del catálogo.
Avisos que **no** bloquean: instrumento no recomendado, datos previstos mayores que la
memoria (habrá que volver a transmitir) y escanear más de la mitad de la batería.

### Masa: qué cuenta dónde

- **Carga en el lanzador** = sonda + satélite de relevo. Se compara con la capacidad del lanzador.
- **Masa de la sonda** = estructura + instrumento + batería. Es la que cambia la aceleración
  en la exploración (referencia: 170 kg en *Controlador Sonda*).

### Avisos al editar valores

- La escala de tiempo está en dos sitios: *Minutos Mision Por Segundo* del catálogo (solo para
  estimaciones) y de *Sistema Energia* en el prefab Sonda (la que usa el juego). Deben
  coincidir; si no, la Console lo avisa al empezar la exploración.
- Si el objetivo pide más escaneos que puntos científicos hay en la escena, la Console y el
  panel de datos lo avisan: el objetivo sería imposible.
- El catálogo guardado aún no incluye los campos añadidos después de crearlo (consumo de
  transmisión, multiplicador del instrumento recomendado y bonos de puntuación). Unity usa
  sus valores por defecto (25 W, ×2, +10 y 0,5). Se ven en el Inspector al seleccionar el
  catálogo y se escribirán en el archivo la próxima vez que se modifique y guarde.

## Modo equipo (1 a 4 jugadores en el mismo PC)

En la pantalla de configuración, bloque **EQUIPO**:

- **Jugadores**: 1 a 4. Con 1 jugador todo funciona como antes.
- **Roles**: cada rol tiene un responsable (J1…J4) y se puede reasignar.
  | Rol | Decide | Prioridad (umbral en el catálogo, DEMOSTRACIÓN) |
  |---|---|---|
  | Ciencia | Objetivo e instrumento | Usar el instrumento recomendado |
  | Ingeniería | Batería | Margen tras escanear ≥ *Margen Energia Minimo Wh* (100) |
  | Lanzamiento | Lanzador | Reserva de presupuesto ≥ *Reserva Presupuesto Minima MUSD* (20) |
  | Comunicaciones | Órbita del relevo | Transmitir todo en ≤ *Tiempo Transmision Maximo S* (20 s) |
- Reparto inicial: 2 jugadores → J1 Ciencia + Comunicaciones, J2 Ingeniería + Lanzamiento;
  3 → J2 lleva Ingeniería y Lanzamiento; 4 → un rol cada uno.
- **Turno**: el jugador que tiene el teclado. Solo puede cambiar las secciones de sus roles.
- **Aprobaciones**: para iniciar, todos deben pulsar su botón. Cualquier cambio de opción,
  de jugadores o de reparto anula las aprobaciones.
- Las prioridades **no bloquean** el inicio. Con los valores actuales ninguna configuración
  válida cumple las cuatro a la vez: el equipo tiene que negociar cuál ceder.
- El informe final muestra, por rol, si el plan cumplía su prioridad y qué pasó de verdad.

Por qué en el mismo PC: en clase o en el evento el equipo comparte una pantalla y discute en
voz alta. El juego reparte la responsabilidad y obliga a llegar a un acuerdo; no hay red.

Archivos: `Scripts/Equipo/ModoEquipo.cs` (roles y prioridades), cambios en
`PantallaConfiguracion`, `ControlMision`, `InformeMision`, `PantallaResultados`,
`AplicadorConfiguracion` y tres campos nuevos en `CatalogoMision`.

## Controles

| Tecla | Acción |
|---|---|
| WASD / Espacio / Ctrl o C / Shift | Mover, subir, bajar, turbo |
| Ratón | Mirar |
| E (mantener) | Escanear el punto apuntado |
| F | Cerrar la ficha |
| T (en la estación) | Terminar la misión y ver el informe |
| M | Volver a la configuración |
| F9 | Mostrar u ocultar el medidor de rendimiento (FPS), en cualquier escena y en el ejecutable |
| Esc / clic | Liberar / recuperar el cursor |

**Probar la interfaz:** usa la vista Game con resolución fija 16:9 (por ejemplo 1920×1080) y
*Scale* en 1x. La interfaz se escala según la altura de la ventana: en ventanas muy bajas
(unos 500 px) los textos pequeños dejan de ser legibles.

**Pruebas de aceptación:** ver `PRUEBAS_ACEPTACION.md`.

## Unidades

- **M USD:** millones de dólares.
- **kg:** masa.
- **W (vatio):** cuánta energía se gasta en cada instante.
- **Wh (vatio-hora):** cuánta energía hay guardada. 1 Wh = 1 W durante 1 hora.
- **MB / MB/s:** cantidad de datos y velocidad de transmisión.
- **Datos recogidos:** guardados en la memoria de la sonda. **Datos transmitidos:** enviados al
  satélite de relevo desde la estación. Solo los transmitidos cuentan para el objetivo.
- **Escala de tiempo:** 1 segundo real = 1 minuto de misión (editable).

Todos los valores son de **DEMOSTRACIÓN**. No proceden de ninguna misión real.

## Licencias (pendiente de decidir y verificar)

| Tipo | Elemento | Estado |
|---|---|---|
| Código propio | `Scripts/` y `Editor/` | Licencia OSI por elegir (p. ej. MIT o Apache-2.0) |
| Dependencias del motor | Unity Editor, URP, Input System | Términos de Unity; confirmar cada paquete en el Package Manager |
| Recursos de terceros | Textura de Europa y modelo TDRS (NASA 3D Resources) | Ver `CREDITOS.md` |
| Datos científicos | Ninguno hasta ahora; las fichas son textos ficticios marcados DEMOSTRACIÓN | Si se añaden datos reales, anotar la fuente en cada ficha |
| Valores de demostración | Catálogo de misión, consumos, recarga, escala de tiempo | Marcados como DEMOSTRACIÓN |

Pendiente de verificar con la organización: si depender de un motor no OSI
(Unity) es aceptable según las reglas de entrega de NASA Space Apps 2026.
