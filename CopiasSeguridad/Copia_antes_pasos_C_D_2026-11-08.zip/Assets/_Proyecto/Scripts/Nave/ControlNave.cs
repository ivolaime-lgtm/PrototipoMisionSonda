using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

namespace PrototipoMision
{
    public enum FaseNave { Preparacion, CuentaAtras, Ascenso, Crucero, Llegada, Orbita, Despliegue, Abortada }

    /// <summary>
    /// Controla el recorrido dentro de la nave: preparación → despegue → viaje con eventos →
    /// entrada en órbita → despliegue de la sonda → Exploracion.
    ///
    /// Puestos (diferenciados para repartirlos en equipo más adelante):
    /// - Pilotaje: despegue, maniobras para esquivar escombros, frenada para entrar en órbita.
    /// - Ingeniería: comprobar la nave y reparar la avería eléctrica (procedimiento de 3 pasos).
    /// - Comunicaciones: recibir y confirmar instrucciones del centro de operaciones.
    /// - Ciencia: comprobar la sonda y desplegarla.
    ///
    /// Todo es DEMOSTRACIÓN: nave tripulada ficticia, viaje comprimido, escombros ficticios.
    /// Los tiempos se editan aquí; los valores de la nave, en el asset CatalogoNave.
    /// </summary>
    public class ControlNave : MonoBehaviour
    {
        [Serializable]
        public struct Tiempos
        {
            [Tooltip("Segundos de la cuenta atrás.")] public float cuentaAtrasS;
            [Tooltip("Segundos del ascenso tras el despegue.")] public float ascensoS;
            [Tooltip("Segundos reales del viaje (sin contar esperas por eventos sin resolver).")] public float cruceroS;
            [Tooltip("Segundos de aviso antes de que lleguen los escombros.")] public float avisoEscombrosS;
            [Tooltip("Segundos durante los que llegan escombros.")] public float duracionEscombrosS;
            [Tooltip("Segundos entre el despliegue de la sonda y el cambio a Exploracion.")] public float despliegueS;
        }

        [SerializeField] CatalogoMision catalogoMision;
        [SerializeField] CatalogoNave catalogoNave;
        [SerializeField] JugadorNave jugador;
        [SerializeField] ExteriorNave exterior;
        [SerializeField] PuestoNave[] puestos;
        [SerializeField] Light[] lucesCabina;
        [Tooltip("Las tres palancas del panel de ingeniería (circuitos 1, 2 y 3).")]
        [SerializeField] Renderer[] palancasIngenieria;
        [SerializeField] string escenaExploracion = "Exploracion";
        [SerializeField] string escenaResultados = "Resultados";

        [Header("Modo de prueba")]
        [Tooltip("Activado: usa los tiempos de prueba (cuenta atrás y viaje cortos).")]
        [SerializeField] bool modoPrueba = false;
        [SerializeField] Tiempos tiemposNormales = new Tiempos
        {
            cuentaAtrasS = 10f, ascensoS = 8f, cruceroS = 150f,
            avisoEscombrosS = 8f, duracionEscombrosS = 22f, despliegueS = 4f
        };
        [SerializeField] Tiempos tiemposPrueba = new Tiempos
        {
            cuentaAtrasS = 3f, ascensoS = 3f, cruceroS = 40f,
            avisoEscombrosS = 4f, duracionEscombrosS = 10f, despliegueS = 1.5f
        };

        [Header("Eventos del viaje")]
        [Tooltip("Progreso del viaje (0 a 1) en el que se produce la avería.")]
        [Range(0f, 1f)] [SerializeField] float momentoAveria = 0.3f;
        [Tooltip("Progreso del viaje (0 a 1) en el que llega la alerta de escombros (tras resolver la avería).")]
        [Range(0f, 1f)] [SerializeField] float momentoEscombros = 0.6f;
        [Tooltip("Velocidad visual de las estrellas durante el viaje.")]
        [SerializeField] float velocidadEstrellas = 70f;

        // ------------------------------------------------------------------ Estado público (lo lee HudNave)

        public FaseNave Fase { get; private set; }
        public ResumenMision Mision { get; private set; }
        public ResumenNave Nave { get; private set; }
        public CatalogoNave Catalogo => catalogoNave;
        public bool ModoPrueba => modoPrueba;

        public float Progreso { get; private set; }
        public float Combustible { get; private set; }
        public float Integridad { get; private set; }
        public float EnergiaNave { get; private set; }
        public float TiempoFase { get; private set; }
        public float FlashImpacto { get; private set; }
        public string MotivoAborto { get; private set; } = "";
        public string Aviso { get; private set; } = "";
        public float TiempoAviso { get; private set; }
        public Vector2 DesplazamientoLateral => desplazamiento;
        public Vector2 VelocidadLateral => velocidadLateral;
        public float MarcadorInsercion { get; private set; }
        public bool InsercionDisponible => Fase == FaseNave.Llegada && MensajePendiente == null;

        /// <summary>Regla de demostración: masa seca + combustible actual + carga científica a bordo.</summary>
        public float MasaActualKg
        {
            get
            {
                if (Nave == null) return catalogoNave.masaSecaKg;
                float carga = Nave.cargaCientificaKg - (sondaABordo || Mision == null ? 0f : Mision.masaSondaKg);
                return catalogoNave.masaSecaKg + Combustible + carga;
            }
        }

        public float AceleracionMS2 => MasaActualKg > 0f ? catalogoNave.empujeManiobraN / MasaActualKg : 0f;

        public float CuentaAtrasRestante => Fase == FaseNave.CuentaAtras ? Mathf.Max(0f, T.cuentaAtrasS - TiempoFase) : 0f;

        public enum EstadoAveria { Ninguna, Activa, Resuelta }
        public enum EstadoEscombros { Pendiente, Aviso, Activo, Despejando, Terminado }

        public EstadoAveria Averia { get; private set; }
        public EstadoEscombros Escombros { get; private set; }
        public float TiempoEscombros { get; private set; }
        public int CircuitoAveriado { get; private set; }
        public int PasoAveria { get; private set; }

        public Tiempos T => modoPrueba ? tiemposPrueba : tiemposNormales;

        // ------------------------------------------------------------------ Mensajes de comunicaciones

        public class Mensaje
        {
            public string titulo, texto;
            public bool confirmado;
        }

        readonly List<Mensaje> mensajes = new List<Mensaje>();
        public IReadOnlyList<Mensaje> Mensajes => mensajes;

        public Mensaje MensajePendiente
        {
            get
            {
                foreach (Mensaje m in mensajes) if (!m.confirmado) return m;
                return null;
            }
        }

        // ------------------------------------------------------------------ Estado interno

        bool chkComunicaciones, chkIngenieria, chkCiencia;
        bool sondaABordo = true;
        Vector2 desplazamiento, velocidadLateral;
        float siguienteEscombro;
        float sacudidaImpacto;
        float tiempoInsercion;
        float inicioAveria;
        bool terminado;
        Material[] materialesPalancas;
        Color[] coloresLuces;

        const string TituloPlan = "Plan de vuelo";
        const string TituloInsercion = "Autorización de inserción orbital";
        const string TituloDespliegue = "Autorización de despliegue";
        const string TituloEvaluacion = "Evaluación del viaje";

        // ------------------------------------------------------------------ Inicio

        void Start()
        {
            if (catalogoMision == null || catalogoNave == null || jugador == null || exterior == null)
            {
                Debug.LogError("[Prototipo] ControlNave: faltan referencias (catálogos, jugador o exterior). " +
                               "Vuelve a crear la escena con el menú Prototipo/8.", this);
                enabled = false;
                return;
            }

            if (!MisionActual.Configurada)
                Debug.Log("[Prototipo] Se inició Nave sin pasar por Configuracion: se usan las primeras opciones del catálogo.", this);

            Mision = catalogoMision.Calcular(MisionActual.Eleccion);
            Nave = catalogoNave.Calcular(Mision);

            Combustible = Nave.combustibleInicialKg;
            Integridad = catalogoNave.integridadInicial;
            EnergiaNave = Nave.energiaWh;

            EstadoViaje.Reiniciar();
            EstadoViaje.MasaInicialKg = Nave.masaInicialKg;
            EstadoViaje.CombustibleInicialKg = Nave.combustibleInicialKg;
            EstadoViaje.CombustibleExtraKg = Nave.combustibleExtraKg;
            EstadoViaje.EnergiaInicialWh = Nave.energiaWh;
            EstadoViaje.ZonaVerdeInsercion = catalogoNave.zonaVerdeInsercion;

            exterior.Configurar(catalogoNave.radioNaveM, catalogoNave.velocidadEscombrosMS);
            exterior.AlPasarEscombro = RegistrarEscombro;
            exterior.Preparar();

            if (palancasIngenieria != null)
            {
                materialesPalancas = new Material[palancasIngenieria.Length];
                for (int i = 0; i < palancasIngenieria.Length; i++)
                    if (palancasIngenieria[i] != null) materialesPalancas[i] = palancasIngenieria[i].material;
            }
            if (lucesCabina != null)
            {
                coloresLuces = new Color[lucesCabina.Length];
                for (int i = 0; i < lucesCabina.Length; i++)
                    if (lucesCabina[i] != null) coloresLuces[i] = lucesCabina[i].color;
            }

            Enviar(TituloPlan,
                "Destino: la luna helada ficticia. Viaje comprimido para la demostración.\n" +
                "Antes de despegar, comprobad la nave en Ingeniería y la sonda en Ciencia, " +
                "y despegad desde Pilotaje.");

            if (modoPrueba)
                Debug.Log("[Prototipo] Nave en MODO DE PRUEBA: tiempos reducidos.", this);

            CambiarFase(FaseNave.Preparacion);
        }

        void CambiarFase(FaseNave nueva)
        {
            Fase = nueva;
            TiempoFase = 0f;
        }

        void Enviar(string titulo, string texto) => mensajes.Add(new Mensaje { titulo = titulo, texto = texto });

        void Avisar(string texto, float segundos = 3f)
        {
            Aviso = texto;
            TiempoAviso = segundos;
        }

        // ------------------------------------------------------------------ Bucle principal

        void Update()
        {
            float dt = Time.deltaTime;
            TiempoFase += dt;
            if (TiempoAviso > 0f) TiempoAviso -= dt;
            FlashImpacto = Mathf.Max(0f, FlashImpacto - dt * 1.5f);
            sacudidaImpacto = Mathf.Max(0f, sacudidaImpacto - dt * 2f);

            if (Fase != FaseNave.Preparacion && Fase != FaseNave.Abortada && Fase != FaseNave.Despliegue)
                EstadoViaje.SegundosViaje += dt;

            float sacudidaFase = 0f;
            switch (Fase)
            {
                case FaseNave.CuentaAtras:
                    sacudidaFase = CuentaAtrasRestante < 2f ? 0.5f : 0f;
                    if (TiempoFase >= T.cuentaAtrasS)
                    {
                        CambiarFase(FaseNave.Ascenso);
                        Avisar("¡Despegue!", 2f);
                    }
                    break;

                case FaseNave.Ascenso:
                    float t = T.ascensoS > 0f ? TiempoFase / T.ascensoS : 1f;
                    exterior.Ascenso(t);
                    sacudidaFase = Mathf.Lerp(1.2f, 0.2f, t);
                    if (t >= 1f)
                    {
                        jugador.AsientoBloqueado = false;
                        exterior.VelocidadEstrellas = velocidadEstrellas;
                        CambiarFase(FaseNave.Crucero);
                        Avisar("En ruta al destino. Puedes levantarte (Q) y recorrer la cabina.", 4f);
                    }
                    break;

                case FaseNave.Crucero:
                    ActualizarCrucero(dt);
                    break;

                case FaseNave.Llegada:
                    exterior.VelocidadEstrellas = Mathf.MoveTowards(exterior.VelocidadEstrellas, 4f, dt * 30f);
                    break;

                case FaseNave.Despliegue:
                    if (TiempoFase >= T.despliegueS && !terminado)
                    {
                        terminado = true;
                        CerrarViaje(false);
                        Cursor.lockState = CursorLockMode.None;
                        Cursor.visible = true;
                        SceneManager.LoadScene(escenaExploracion);
                    }
                    break;

                case FaseNave.Abortada:
                    exterior.VelocidadEstrellas = Mathf.MoveTowards(exterior.VelocidadEstrellas, 0f, dt * 30f);
                    if (TiempoFase >= 5f && !terminado)
                    {
                        terminado = true;
                        CerrarViaje(true);
                        InformeMision.Ultimo = CrearInformeAborto();
                        Cursor.lockState = CursorLockMode.None;
                        Cursor.visible = true;
                        SceneManager.LoadScene(escenaResultados);
                    }
                    break;
            }

            jugador.Sacudida = Mathf.Max(sacudidaFase, sacudidaImpacto);

            // Puesto en uso
            Keyboard k = Keyboard.current;
            PuestoNave actual = jugador.PuestoActual;
            Vector2 empuje = Vector2.zero;
            if (actual != null && k != null && Fase != FaseNave.Abortada)
            {
                switch (actual.Tipo)
                {
                    case TipoPuesto.Pilotaje: empuje = Pilotaje(k); break;
                    case TipoPuesto.Ingenieria: Ingenieria(k); break;
                    case TipoPuesto.Comunicaciones: Comunicaciones(k); break;
                    case TipoPuesto.Ciencia: Ciencia(k); break;
                }
            }

            if (Fase == FaseNave.Crucero) Maniobrar(empuje, dt);

            // Avería: pierde energía mientras siga activa
            if (Averia == EstadoAveria.Activa && Fase != FaseNave.Abortada)
            {
                EnergiaNave = Mathf.Max(0f, EnergiaNave - catalogoNave.perdidaAveriaWhPorS * dt);
                EstadoViaje.SegundosAveria += dt;
            }

            // Condiciones de aborto
            if (Fase != FaseNave.Abortada && Fase != FaseNave.Despliegue)
            {
                if (Integridad <= 0f)
                    Abortar("el casco quedó demasiado dañado por los impactos de escombros.");
                else if (EnergiaNave <= 0f)
                    Abortar("la nave se quedó sin energía: la avería no se reparó a tiempo.");
            }

            ActualizarIndicadores();
            ActualizarLuces();
            ActualizarPalancas();
        }

        void ActualizarCrucero(float dt)
        {
            Progreso += T.cruceroS > 0f ? dt / T.cruceroS : 1f;

            if (Averia == EstadoAveria.Ninguna && Progreso >= momentoAveria)
            {
                Averia = EstadoAveria.Activa;
                CircuitoAveriado = UnityEngine.Random.Range(0, 3);
                PasoAveria = 0;
                inicioAveria = Time.time;
                Avisar("¡AVERÍA ELÉCTRICA! Ve al puesto de Ingeniería.", 4f);
            }

            switch (Escombros)
            {
                case EstadoEscombros.Pendiente:
                    if (Progreso >= momentoEscombros && Averia != EstadoAveria.Activa)
                    {
                        Escombros = EstadoEscombros.Aviso;
                        TiempoEscombros = 0f;
                        Avisar("¡ALERTA DE ESCOMBROS! Ve al puesto de Pilotaje.", 4f);
                    }
                    break;
                case EstadoEscombros.Aviso:
                    TiempoEscombros += dt;
                    if (TiempoEscombros >= T.avisoEscombrosS)
                    {
                        Escombros = EstadoEscombros.Activo;
                        TiempoEscombros = 0f;
                        siguienteEscombro = 0f;
                    }
                    break;
                case EstadoEscombros.Activo:
                    TiempoEscombros += dt;
                    siguienteEscombro -= dt;
                    if (siguienteEscombro <= 0f)
                    {
                        exterior.LanzarEscombro(UnityEngine.Random.value < catalogoNave.fraccionEscombrosApuntados);
                        siguienteEscombro = catalogoNave.intervaloEscombrosS;
                    }
                    if (TiempoEscombros >= T.duracionEscombrosS) Escombros = EstadoEscombros.Despejando;
                    break;
                case EstadoEscombros.Despejando:
                    if (exterior.EscombrosActivos == 0)
                    {
                        Escombros = EstadoEscombros.Terminado;
                        Avisar($"Zona de escombros superada: {EstadoViaje.Impactos} impactos, {EstadoViaje.EscombrosEsquivados} esquivados.", 4f);
                    }
                    break;
            }

            // No se llega al destino con eventos sin resolver.
            bool pendiente = Averia != EstadoAveria.Resuelta || Escombros != EstadoEscombros.Terminado;
            if (pendiente) Progreso = Mathf.Min(Progreso, 0.99f);

            exterior.Viaje(Progreso);

            if (Progreso >= 1f)
            {
                Progreso = 1f;
                CambiarFase(FaseNave.Llegada);
                Enviar(TituloInsercion,
                    "Estáis llegando al destino. Para quedar en órbita hay que frenar con el motor principal " +
                    "en el momento justo: frenar antes o después gasta más combustible.");
                Avisar("Llegada al destino. Mensaje nuevo en Comunicaciones.", 4f);
            }
        }

        // ------------------------------------------------------------------ Puestos

        Vector2 Pilotaje(Keyboard k)
        {
            switch (Fase)
            {
                case FaseNave.Preparacion:
                    if (k.spaceKey.wasPressedThisFrame)
                    {
                        if (chkComunicaciones && chkIngenieria && chkCiencia)
                        {
                            jugador.AsientoBloqueado = true;
                            CambiarFase(FaseNave.CuentaAtras);
                            Avisar("Cuenta atrás iniciada.", 2f);
                        }
                        else Avisar("Faltan comprobaciones: " + Faltan(), 3f);
                    }
                    break;

                case FaseNave.Crucero:
                    Vector2 e = Vector2.zero;
                    if (k.wKey.isPressed || k.upArrowKey.isPressed) e.y += 1f;
                    if (k.sKey.isPressed || k.downArrowKey.isPressed) e.y -= 1f;
                    if (k.dKey.isPressed || k.rightArrowKey.isPressed) e.x += 1f;
                    if (k.aKey.isPressed || k.leftArrowKey.isPressed) e.x -= 1f;
                    return Vector2.ClampMagnitude(e, 1f);

                case FaseNave.Llegada:
                    if (!InsercionDisponible) break;
                    tiempoInsercion += Time.deltaTime;
                    MarcadorInsercion = 0.5f + 0.5f * Mathf.Sin(tiempoInsercion * Mathf.PI * 2f / 2.2f);
                    if (k.spaceKey.wasPressedThisFrame) Insertar();
                    break;
            }
            return Vector2.zero;
        }

        void Ingenieria(Keyboard k)
        {
            if (Fase == FaseNave.Preparacion && !chkIngenieria && k.spaceKey.wasPressedThisFrame)
            {
                chkIngenieria = true;
                Avisar("Ingeniería: sistemas de la nave comprobados.", 2.5f);
                return;
            }

            if (Averia != EstadoAveria.Activa) return;

            int tecla = -1;                       // 0,1,2 = circuitos · 3 = R · 4 = Espacio
            if (k.digit1Key.wasPressedThisFrame || k.numpad1Key.wasPressedThisFrame) tecla = 0;
            else if (k.digit2Key.wasPressedThisFrame || k.numpad2Key.wasPressedThisFrame) tecla = 1;
            else if (k.digit3Key.wasPressedThisFrame || k.numpad3Key.wasPressedThisFrame) tecla = 2;
            else if (k.rKey.wasPressedThisFrame) tecla = 3;
            else if (k.spaceKey.wasPressedThisFrame) tecla = 4;
            if (tecla < 0) return;

            bool correcto =
                (PasoAveria == 0 && tecla == CircuitoAveriado) ||
                (PasoAveria == 1 && tecla == 3) ||
                (PasoAveria == 2 && tecla == 4);

            if (!correcto)
            {
                EnergiaNave = Mathf.Max(0f, EnergiaNave - catalogoNave.perdidaErrorAveriaWh);
                EstadoViaje.ErroresAveria++;
                Avisar($"Paso equivocado: chispazo, se pierden {catalogoNave.perdidaErrorAveriaWh:0} Wh. Lee el procedimiento.", 3f);
                sacudidaImpacto = 0.4f;
                return;
            }

            PasoAveria++;
            if (PasoAveria >= 3)
            {
                Averia = EstadoAveria.Resuelta;
                Avisar($"Avería reparada en {Time.time - inicioAveria:0} s.", 3.5f);
            }
        }

        void Comunicaciones(Keyboard k)
        {
            Mensaje m = MensajePendiente;
            if (m == null || !k.spaceKey.wasPressedThisFrame) return;

            m.confirmado = true;
            if (m.titulo == TituloPlan) chkComunicaciones = true;
            Avisar("Recepción confirmada: " + m.titulo + ".", 2.5f);
        }

        void Ciencia(Keyboard k)
        {
            if (!k.spaceKey.wasPressedThisFrame) return;

            if (Fase == FaseNave.Preparacion && !chkCiencia)
            {
                chkCiencia = true;
                Avisar("Ciencia: sonda comprobada y asegurada.", 2.5f);
            }
            else if (Fase == FaseNave.Orbita)
            {
                if (MensajePendiente != null)
                    Avisar("Primero confirma la autorización en Comunicaciones.", 2.5f);
                else
                {
                    sondaABordo = false;
                    exterior.LanzarSonda();
                    jugador.AsientoBloqueado = true;
                    CambiarFase(FaseNave.Despliegue);
                    Avisar("Sonda desplegada. Pasas a controlar la sonda…", 4f);
                }
            }
        }

        // ------------------------------------------------------------------ Mecánicas

        void Maniobrar(Vector2 entrada, float dt)
        {
            float acel = AceleracionMS2;
            Vector2 empuje = entrada;

            // Sin mando, el estabilizador frena la deriva lateral (también gasta combustible).
            if (empuje.sqrMagnitude < 0.0001f)
            {
                float v = velocidadLateral.magnitude;
                if (v > 0.01f && acel > 0f)
                    empuje = -velocidadLateral.normalized * Mathf.Min(1f, v / (acel * dt));
            }

            if (Combustible <= 0f) empuje = Vector2.zero;

            float fraccion = empuje.magnitude;
            velocidadLateral += empuje * acel * dt;
            float gasto = Mathf.Min(Combustible, fraccion * catalogoNave.consumoManiobraKgS * dt);
            Combustible -= gasto;
            EstadoViaje.CombustibleManiobrasKg += gasto;

            desplazamiento += velocidadLateral * dt;
            float lim = catalogoNave.limiteDesplazamientoM;
            if (Mathf.Abs(desplazamiento.x) > lim) { desplazamiento.x = Mathf.Sign(desplazamiento.x) * lim; velocidadLateral.x = 0f; }
            if (Mathf.Abs(desplazamiento.y) > lim) { desplazamiento.y = Mathf.Sign(desplazamiento.y) * lim; velocidadLateral.y = 0f; }
            exterior.Desplazamiento = desplazamiento;
        }

        void RegistrarEscombro(bool impacto)
        {
            if (Fase == FaseNave.Abortada) return;
            if (impacto)
            {
                Integridad = Mathf.Max(0f, Integridad - catalogoNave.danoPorImpacto);
                EstadoViaje.Impactos++;
                FlashImpacto = 1f;
                sacudidaImpacto = 1.5f;
                Avisar($"¡IMPACTO! Integridad del casco: {Integridad:0} %", 2.5f);
            }
            else EstadoViaje.EscombrosEsquivados++;
        }

        void Insertar()
        {
            float error = Mathf.Abs(MarcadorInsercion - 0.5f);
            float coste = catalogoNave.CosteInsercion(MasaActualKg, error);
            EstadoViaje.ErrorInsercion = error;

            if (coste > Combustible)
            {
                EstadoViaje.CombustibleInsercionKg = Combustible;
                Combustible = 0f;
                Abortar($"no quedaba combustible para frenar: hacían falta {coste:0} kg y quedaban {EstadoViaje.CombustibleInsercionKg:0} kg.");
                return;
            }

            Combustible -= coste;
            EstadoViaje.CombustibleInsercionKg = coste;
            exterior.Orbita();
            CambiarFase(FaseNave.Orbita);
            Evaluar(error);
            string calidad = error <= catalogoNave.zonaVerdeInsercion ? "frenada precisa" : "frenada imprecisa";
            Avisar($"En órbita ({calidad}): {coste:0} kg de combustible. Evaluación del viaje en Comunicaciones.", 4f);
            Enviar(TituloEvaluacion, TextoEvaluacion());
            Enviar(TituloDespliegue,
                "Órbita estable confirmada. Desplegad la sonda desde el puesto de Ciencia. " +
                "La sonda funcionará con su propia batería.");
        }

        /// <summary>
        /// Evaluación del viaje, una sola vez, al entrar en órbita (antes de desplegar la sonda).
        /// Cada acción se mide con una sola medida. La frenada no da puntos: solo cambia la carga
        /// inicial de la sonda (regla simplificada, como máximo un 10 %).
        /// </summary>
        void Evaluar(float errorInsercion)
        {
            if (EstadoViaje.Evaluado) return;
            float energiaInicial = Mathf.Max(1f, Nave.energiaWh);
            EstadoViaje.PerdidaEnergiaNave = Mathf.Clamp01((Nave.energiaWh - EnergiaNave) / energiaInicial);
            EstadoViaje.PuntosReparacion = catalogoNave.PuntosReparacion(EstadoViaje.PerdidaEnergiaNave);
            EstadoViaje.PuntosEscombros = catalogoNave.PuntosEscombros(EstadoViaje.Impactos);
            EstadoViaje.PuntosEtapa = -1;                 // la separación de etapa llegará en el paso C
            EstadoViaje.ReduccionCargaSonda = catalogoNave.ReduccionCargaSonda(errorInsercion);
            EstadoViaje.Evaluado = true;
        }

        /// <summary>Carga con la que empezará la sonda (Wh), según la evaluación.</summary>
        public float CargaPrevistaSondaWh => Mision != null ? Mision.energiaWh * (1f - EstadoViaje.ReduccionCargaSonda) : 0f;

        string TextoEstadoSonda()
        {
            if (Mision == null) return "";
            float cap = Mision.energiaWh;
            float carga = CargaPrevistaSondaWh;
            if (EstadoViaje.ReduccionCargaSonda <= 0f)
                return $"Carga inicial de la sonda: <b>{carga:0}/{cap:0} Wh</b> (frenada precisa: descenso sin demoras).";
            return $"Carga inicial de la sonda: <b>{carga:0}/{cap:0} Wh</b> (−{cap - carga:0.#} Wh, {EstadoViaje.ReduccionCargaSonda * 100f:0} %).\n" +
                   "<size=15>Regla simplificada: la frenada imprecisa dejó la órbita más lejos del punto de acceso; el descenso " +
                   "se prolonga y la sonda gasta batería en mantenerse caliente y orientada. La capacidad máxima no cambia " +
                   "y la estación recarga con normalidad. No resta puntos.</size>";
        }

        string TextoEvaluacion()
        {
            string etapa = EstadoViaje.PuntosEtapa < 0 ? "aún no implementada (no puntúa)" : $"+{EstadoViaje.PuntosEtapa}";
            return "Evaluación del viaje (DEMOSTRACIÓN):\n" +
                   $"• Separación de etapa: {etapa}\n" +
                   $"• Reparación de la avería: {EstadoViaje.PerdidaEnergiaNave * 100f:0} % de energía perdida → +{EstadoViaje.PuntosReparacion}\n" +
                   $"• Escombros: {EstadoViaje.Impactos} impactos → +{EstadoViaje.PuntosEscombros}\n" +
                   $"<b>Puntos de viaje: {EstadoViaje.PuntosViaje}</b>\n\n" + TextoEstadoSonda();
        }

        void Abortar(string motivo)
        {
            MotivoAborto = motivo;
            jugador.AsientoBloqueado = true;
            CambiarFase(FaseNave.Abortada);
            Avisar("MISIÓN ABORTADA", 5f);
        }

        void CerrarViaje(bool abortado)
        {
            EstadoViaje.Realizado = true;
            EstadoViaje.Abortado = abortado;
            EstadoViaje.MotivoAborto = abortado ? MotivoAborto : "";
            EstadoViaje.CombustibleFinalKg = Combustible;
            EstadoViaje.IntegridadFinal = Integridad;
            EstadoViaje.EnergiaFinalWh = EnergiaNave;
        }

        InformeMision CrearInformeAborto()
        {
            InformeMision inf = new InformeMision
            {
                motivo = MotivoFin.ViajeAbortado,
                eleccion = MisionActual.Eleccion,
                segundosMision = 0f
            };
            inf.CopiarConfiguracion(Mision, catalogoMision);
            inf.CopiarViaje();
            inf.Completar();
            return inf;
        }

        // ------------------------------------------------------------------ Retroalimentación visible

        void ActualizarIndicadores()
        {
            if (puestos == null) return;
            bool preparacion = Fase == FaseNave.Preparacion;
            Mensaje pendiente = MensajePendiente;

            foreach (PuestoNave p in puestos)
            {
                if (p == null) continue;
                EstadoPuesto e = EstadoPuesto.Correcto;
                switch (p.Tipo)
                {
                    case TipoPuesto.Pilotaje:
                        if (Escombros == EstadoEscombros.Aviso || Escombros == EstadoEscombros.Activo) e = EstadoPuesto.Alarma;
                        else if (preparacion) e = Faltan().Length == 0 ? EstadoPuesto.Pendiente : EstadoPuesto.Inactivo;
                        else if (InsercionDisponible) e = EstadoPuesto.Pendiente;
                        break;
                    case TipoPuesto.Ingenieria:
                        if (Averia == EstadoAveria.Activa) e = EstadoPuesto.Alarma;
                        else if (preparacion && !chkIngenieria) e = EstadoPuesto.Pendiente;
                        break;
                    case TipoPuesto.Comunicaciones:
                        if (pendiente != null) e = EstadoPuesto.Pendiente;
                        break;
                    case TipoPuesto.Ciencia:
                        if (preparacion && !chkCiencia) e = EstadoPuesto.Pendiente;
                        else if (Fase == FaseNave.Orbita && pendiente == null) e = EstadoPuesto.Pendiente;
                        break;
                }
                if (Fase == FaseNave.Abortada) e = EstadoPuesto.Alarma;
                p.Estado = e;
            }
        }

        void ActualizarLuces()
        {
            if (lucesCabina == null || coloresLuces == null) return;
            bool alarma = Averia == EstadoAveria.Activa || Fase == FaseNave.Abortada;
            bool alerta = Escombros == EstadoEscombros.Aviso || Escombros == EstadoEscombros.Activo;
            float pulso = 0.5f + 0.5f * Mathf.Sin(Time.time * 6f);

            for (int i = 0; i < lucesCabina.Length; i++)
            {
                Light l = lucesCabina[i];
                if (l == null) continue;
                if (alarma)
                {
                    l.color = new Color(1f, 0.12f, 0.1f);
                    l.intensity = 0.6f + 1.6f * (UnityEngine.Random.value < 0.08f ? 0f : pulso);
                }
                else if (alerta)
                {
                    l.color = Color.Lerp(coloresLuces[i], new Color(1f, 0.6f, 0.1f), pulso);
                    l.intensity = 2.2f;
                }
                else
                {
                    l.color = coloresLuces[i];
                    l.intensity = 2.5f;
                }
            }
        }

        void ActualizarPalancas()
        {
            if (materialesPalancas == null) return;
            bool parpadeo = Mathf.Repeat(Time.time * 3f, 1f) < 0.5f;
            for (int i = 0; i < materialesPalancas.Length; i++)
            {
                Material m = materialesPalancas[i];
                if (m == null) continue;
                Color c = new Color(0.2f, 0.9f, 0.35f);                         // normal
                if (Averia == EstadoAveria.Activa && i == CircuitoAveriado)
                {
                    if (PasoAveria == 0) c = parpadeo ? new Color(1f, 0.1f, 0.1f) : new Color(0.3f, 0.02f, 0.02f);  // sobrecarga
                    else if (PasoAveria == 1) c = new Color(1f, 0.65f, 0.1f);    // aislado
                    else c = new Color(0.2f, 0.55f, 1f);                         // con línea de reserva
                }
                m.SetColor("_BaseColor", c);
            }
        }

        // ------------------------------------------------------------------ Textos para el HUD

        public string Faltan()
        {
            string t = "";
            if (!chkComunicaciones) t += "Comunicaciones";
            if (!chkIngenieria) t += (t.Length > 0 ? ", " : "") + "Ingeniería";
            if (!chkCiencia) t += (t.Length > 0 ? ", " : "") + "Ciencia";
            return t;
        }

        public string NombreFase()
        {
            switch (Fase)
            {
                case FaseNave.Preparacion: return "Preparación";
                case FaseNave.CuentaAtras: return "Cuenta atrás";
                case FaseNave.Ascenso: return "Despegue";
                case FaseNave.Crucero: return "Viaje";
                case FaseNave.Llegada: return "Llegada";
                case FaseNave.Orbita: return "En órbita";
                case FaseNave.Despliegue: return "Despliegue de la sonda";
                default: return "Abortada";
            }
        }

        /// <summary>Qué debe hacer el jugador ahora.</summary>
        public string Instruccion()
        {
            Mensaje pendiente = MensajePendiente;
            switch (Fase)
            {
                case FaseNave.Preparacion:
                    string f = Faltan();
                    return f.Length > 0
                        ? "Comprueba los puestos con luz ámbar: " + f + ". Después, despega desde Pilotaje."
                        : "Todo comprobado: ve a Pilotaje e inicia la cuenta atrás.";
                case FaseNave.CuentaAtras:
                case FaseNave.Ascenso:
                    return "Despegue en curso. Mira por la ventana.";
                case FaseNave.Crucero:
                    if (Averia == EstadoAveria.Activa) return "AVERÍA: ve al puesto de Ingeniería y sigue el procedimiento.";
                    if (Escombros == EstadoEscombros.Aviso || Escombros == EstadoEscombros.Activo)
                        return "ESCOMBROS: ve a Pilotaje y esquívalos con WASD.";
                    return "Viaje en curso. Puedes recorrer la cabina y mirar por la ventana.";
                case FaseNave.Llegada:
                    return pendiente != null ? "Comunicaciones: confirma la autorización de inserción."
                                             : "Pilotaje: frena en el momento justo para entrar en órbita.";
                case FaseNave.Orbita:
                    return pendiente != null ? "Comunicaciones: lee y confirma: " + pendiente.titulo + "."
                                             : "Ciencia: despliega la sonda.";
                case FaseNave.Despliegue:
                    return "Sonda desplegada. Pasando al control de la sonda…";
                default:
                    return "MISIÓN ABORTADA: " + MotivoAborto;
            }
        }

        /// <summary>Texto del panel del puesto en uso.</summary>
        public string TextoPuesto(TipoPuesto tipo)
        {
            switch (tipo)
            {
                case TipoPuesto.Pilotaje: return TextoPilotaje();
                case TipoPuesto.Ingenieria: return TextoIngenieria();
                case TipoPuesto.Comunicaciones: return TextoComunicaciones();
                default: return TextoCiencia();
            }
        }

        string TextoPilotaje()
        {
            switch (Fase)
            {
                case FaseNave.Preparacion:
                    string f = Faltan();
                    return f.Length > 0
                        ? $"Antes de despegar faltan comprobaciones en: <b>{f}</b>.\nCada puesto con luz ámbar tiene una tarea."
                        : "Todo comprobado.\n\n<b>Espacio: iniciar la cuenta atrás.</b>\nDurante el despegue permanecerás en el asiento.";
                case FaseNave.CuentaAtras:
                case FaseNave.Ascenso:
                    return $"Despegue en curso.\nMasa de la nave al despegar: {Nave.masaInicialKg:0} kg.";
                case FaseNave.Crucero:
                    string esc = Escombros == EstadoEscombros.Aviso
                        ? $"<color=#FFB040><b>Escombros en {Mathf.Max(0f, T.avisoEscombrosS - TiempoEscombros):0} s</b></color>\n"
                        : Escombros == EstadoEscombros.Activo || Escombros == EstadoEscombros.Despejando
                            ? "<color=#FF6B5B><b>¡ESCOMBROS! Mantén el centro de la mira libre de rocas.</b></color>\n"
                            : "";
                    return esc +
                           "<b>WASD / flechas:</b> propulsores laterales (gastan combustible).\n" +
                           "Al soltar, el estabilizador frena la nave, también con combustible: en el espacio no hay rozamiento que la detenga.\n\n" +
                           $"Aceleración = empuje / masa = {catalogoNave.empujeManiobraN:0} N / {MasaActualKg:0} kg = <b>{AceleracionMS2:0.00} m/s²</b>\n" +
                           $"Desplazamiento: {desplazamiento.x:+0.0;-0.0} / {desplazamiento.y:+0.0;-0.0} m · velocidad {velocidadLateral.magnitude:0.0} m/s\n" +
                           $"Gastado en maniobras: {EstadoViaje.CombustibleManiobrasKg:0} kg\n" +
                           $"Impactos: {EstadoViaje.Impactos} · esquivados: {EstadoViaje.EscombrosEsquivados}";
                case FaseNave.Llegada:
                    if (!InsercionDisponible) return "Esperando la autorización de inserción (puesto de Comunicaciones).";
                    float perfecto = catalogoNave.CosteInsercion(MasaActualKg, 0f);
                    float peor = catalogoNave.CosteInsercion(MasaActualKg, 0.5f);
                    string riesgo = Combustible < peor
                        ? (Combustible < perfecto
                            ? "\n<color=#FF6B5B><b>No hay combustible ni para una frenada perfecta.</b></color>"
                            : "\n<color=#FFB040>Combustible justo: una frenada imprecisa podría dejarte sin él.</color>")
                        : "";
                    return "<b>ENTRADA EN ÓRBITA</b>\nPara quedarte en órbita, la nave frena con el motor principal.\n" +
                           "<b>Espacio</b> cuando el marcador esté en la zona verde. Cuanto más lejos del centro, más combustible.\n\n" +
                           $"Coste: {perfecto:0} kg (perfecta) a {peor:0} kg (peor) · Combustible: {Combustible:0} kg" + riesgo;
                default:
                    return EstadoViaje.ErrorInsercion >= 0f
                        ? $"En órbita. Combustible usado al frenar: {EstadoViaje.CombustibleInsercionKg:0} kg."
                        : "Sin maniobras pendientes.";
            }
        }

        string TextoIngenieria()
        {
            if (Averia == EstadoAveria.Activa)
            {
                string[] nombres = { "Soporte vital", "Propulsión", "Navegación" };
                string circuitos = "";
                for (int i = 0; i < 3; i++)
                {
                    bool mal = i == CircuitoAveriado;
                    string estado = !mal ? "<color=#7CFC9A>12 A · normal</color>"
                                  : PasoAveria == 0 ? "<color=#FF6B5B><b>38 A · SOBRECARGA</b></color>"
                                  : PasoAveria == 1 ? "<color=#FFB040>aislado</color>"
                                  : "<color=#66A8FF>en línea de reserva</color>";
                    circuitos += $"  {i + 1}. {nombres[i]}: {estado}\n";
                }
                string[] pasos =
                {
                    "Aísla el circuito con sobrecarga: pulsa su número (1, 2 o 3).\n<size=15>Aislar evita que la sobrecarga dañe el resto de sistemas.</size>",
                    "Conecta la línea de reserva: pulsa <b>R</b>.\n<size=15>La reserva alimenta el sistema mientras el circuito está aislado.</size>",
                    "Restablece el circuito: pulsa <b>Espacio</b>."
                };
                return "<color=#FF6B5B><b>AVERÍA ELÉCTRICA</b></color> · la nave pierde " +
                       $"{catalogoNave.perdidaAveriaWhPorS:0} Wh por segundo\n\n" + circuitos +
                       $"\n<b>Paso {PasoAveria + 1} de 3:</b> " + pasos[Mathf.Clamp(PasoAveria, 0, 2)] +
                       $"\n\nUn paso equivocado cuesta {catalogoNave.perdidaErrorAveriaWh:0} Wh. Energía: {EnergiaNave:0} Wh";
            }

            string datos =
                "<b>DATOS DE LA NAVE</b> (no de la sonda) · DEMOSTRACIÓN\n" +
                $"Masa seca de la nave: {Nave.masaSecaKg:0} kg\n" +
                $"Carga científica a bordo (sonda + relevo): {Nave.cargaCientificaKg:0} kg\n" +
                $"Combustible: {Nave.combustibleBaseKg:0} kg base + {Nave.combustibleExtraKg:0} kg extra = {Nave.combustibleInicialKg:0} kg\n" +
                $"<size=15>Regla de demostración: la capacidad que sobra en el lanzador ({Nave.margenLanzadorKg:0} kg) se llena con combustible extra.</size>\n" +
                $"Masa total al partir: {Nave.masaInicialKg:0} kg → aceleración de maniobra {Nave.aceleracionInicialMS2:0.00} m/s²\n" +
                $"Energía de la nave: {Nave.energiaWh:0} Wh <size=15>(la batería de la sonda es aparte)</size>\n";

            if (Fase == FaseNave.Preparacion)
                return datos + (chkIngenieria ? "\n<color=#7CFC9A>[OK] Sistemas comprobados.</color>" : "\n<b>Espacio: confirmar sistemas.</b>");

            string averia = Averia == EstadoAveria.Resuelta
                ? $"\nAvería reparada · duró {EstadoViaje.SegundosAveria:0} s · errores: {EstadoViaje.ErroresAveria}"
                : "";
            return $"Sistemas nominales. Energía actual: {EnergiaNave:0} / {Nave.energiaWh:0} Wh{averia}\n\n" + datos;
        }

        string TextoComunicaciones()
        {
            Mensaje m = MensajePendiente;
            if (m != null)
                return "<b>MENSAJE DEL CENTRO DE OPERACIONES</b>\n\n" +
                       $"<b>{m.titulo}</b>\n{m.texto}\n\n<b>Espacio: confirmar recepción.</b>";

            string historial = "";
            foreach (Mensaje x in mensajes) historial += $"<color=#7CFC9A>[OK]</color> {x.titulo}\n";
            return "Sin mensajes pendientes.\n\n" + (historial.Length > 0 ? "Confirmados:\n" + historial : "");
        }

        string TextoCiencia()
        {
            string sonda =
                "<b>DATOS DE LA SONDA</b> (separados de la nave)\n" +
                $"Objetivo: {Mision.objetivo.nombre}\n" +
                $"Instrumento: {Mision.instrumento.nombre}\n" +
                $"Batería de la sonda: {Mision.energiaWh:0} Wh\n" +
                $"Masa de la sonda: {Mision.masaSondaKg:0} kg · relevo: {Mision.orbita.nombre}\n";

            switch (Fase)
            {
                case FaseNave.Preparacion:
                    return sonda + (chkCiencia ? "\n<color=#7CFC9A>[OK] Sonda comprobada.</color>" : "\n<b>Espacio: confirmar que la sonda está lista.</b>");
                case FaseNave.Orbita:
                    return MensajePendiente != null
                        ? sonda + "\n" + TextoEstadoSonda() + "\n\nEsperando la autorización de despliegue (puesto de Comunicaciones)."
                        : sonda + "\n" + TextoEstadoSonda() + "\n\n<b>Espacio: desplegar la sonda.</b>\nDescenderá y explorará con su propia batería.";
                case FaseNave.Despliegue:
                    return "Sonda desplegada.";
                default:
                    return sonda + "\nSonda asegurada en la bahía.";
            }
        }
    }
}
