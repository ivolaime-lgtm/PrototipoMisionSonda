# Pruebas de aceptación del recorrido completo

Recorrido: **CentroOperaciones → Configuracion → Exploracion → Resultados → Repetir**.

Preparación: vista Game con resolución fija 16:9 (por ejemplo 1920×1080) y *Scale* en 1x.
Abre `Scenes/CentroOperaciones` y pulsa Play. Ten abierta la Console.

Configuración de referencia: **Cartografiar · Cámara · Batería ligera · Lanzador pequeño ·
Relevo en órbita baja**. Todos los valores son de DEMOSTRACIÓN.

## A. Recorrido principal

| # | Pasos | Resultado esperado |
|---|---|---|
| A1 | Arranca en CentroOperaciones | Se ven la estación, la luna y el satélite orbitando. Sin errores en la Console |
| A2 | **Configurar misión** | Pantalla de configuración. Con la referencia: coste **72/100 M USD**, carga **190/230 kg**, "[OK]" |
| A3 | Mira "Transmitir todos los datos" | Indica "s reales (media, contando las ventanas sin contacto)" |
| A4 | **Iniciar misión** | Exploracion. Panel derecho: 80 Wh, aceleración ×1,00. Abajo, la lista completa de teclas (E, F, T, M, F9…) |
| A5 | Dentro de la estación | Panel de energía: "Autonomía: recargando en la estación". Abajo: "T: terminar la misión…" |
| A6 | Sal, escanea 1 punto (E) y vuelve | En la estación, mientras quedan datos: "…aún hay N MB sin transmitir, se perderían" |
| A7 | Escanea y transmite los 3 puntos | Banner verde y, 4 s después, Resultados **MISIÓN CUMPLIDA** |
| A8 | Lee el informe | Duración "m:ss reales (≈ N min de misión)". Puntuación 12 + 10 + 14 = **36** |
| A9 | **Repetir con la misma configuración** | Exploracion de nuevo: batería llena, 0 escaneos, puntos sin escanear, misma configuración |
| A10 | Pulsa **M** | Configuracion con la misma elección marcada |

## B. Finales alternativos

| # | Pasos | Resultado esperado |
|---|---|---|
| B1 | Transmite 1 escaneo y pulsa T en la estación | **PARCIALMENTE CUMPLIDA**. Sin bonos; explica que el sobrante no suma |
| B2 | Pulsa T fuera de la estación | "Solo puedes terminar la misión dentro de la estación". No termina |
| B3 | Catálogo: *Capacidad Wh* de la batería ligera = 15. Sal de la estación y aléjate sin volver (si llegas a un punto, escanéalo) | "ENERGÍA AGOTADA · Generando el informe…" → **MISIÓN FALLIDA** con la distancia a la estación, los MB perdidos si escaneaste y la sugerencia de batería mayor |
| B4 | Desde Resultados, **Volver a configurar** | Configuracion con la última elección |

## C. Reglas de la configuración

| # | Elección, o cambio en el catálogo (fuera de Play) | Resultado esperado |
|---|---|---|
| C1 | Cámara · **Batería alta** · Pequeño · **Órbita alta** | Carga 238/230 EXCEDIDO. Botón bloqueado |
| C2 | Espectrómetro · Ligera · **Mediano** · Baja | Coste 106/100 EXCEDIDO. Botón bloqueado |
| C3 | *Memoria MB* = 100 | Con la Cámara (120 MB por escaneo): bloqueado por memoria. Con el Espectrómetro (60 MB): permitido |
| C4 | *Fracción Contacto* de la órbita baja = 0 | Con esa órbita: bloqueado por "no tiene enlace" |
| C5 | *Escaneos Requeridos* del objetivo = 4 | Permite iniciar. En Exploracion, aviso rojo en el panel de datos y en la Console: solo hay 3 puntos |
| C6 | *Minutos Mision Por Segundo* del catálogo = 2 | Al entrar en Exploracion, aviso amarillo en la Console por escalas de tiempo distintas |

Deshaz los cambios del catálogo al terminar (o restaura desde `CopiasSeguridad`).

## D. Ejecutable y rendimiento

| # | Pasos | Resultado esperado |
|---|---|---|
| D1 | File → Build Profiles: orden de escenas | CentroOperaciones, Configuracion, Exploracion, Resultados (SampleScene, si aparece, se puede desmarcar) |
| D2 | Build en una carpeta **fuera** del proyecto y ejecútalo | Luna con textura, satélite visible, estación con materiales (nada rosa) |
| D3 | F9 en cada escena (editor y ejecutable) | Anota FPS y "peor ms". Referencia del editor en CentroOperaciones: 312 FPS (dato medido por el equipo) |
| D4 | Recorrido A completo en el ejecutable | Igual que en el editor |
