using UnityEngine;
using UnityEngine.SceneManagement;

namespace PrototipoMision
{
    /// <summary>
    /// Pantalla del informe final (interfaz provisional IMGUI).
    /// Muestra configuración, objetivos, energía, datos, explicaciones y
    /// puntuación de DEMOSTRACIÓN, con botones para volver a configurar
    /// o repetir con la misma configuración.
    /// </summary>
    public class PantallaResultados : MonoBehaviour
    {
        [SerializeField] string escenaConfiguracion = "Configuracion";
        [SerializeField] string escenaExploracion = "Exploracion";

        [Header("Textos editables")]
        [SerializeField] string tituloExito = "MISIÓN CUMPLIDA";
        [SerializeField] string tituloParcial = "MISIÓN PARCIALMENTE CUMPLIDA";
        [SerializeField] string tituloFracaso = "MISIÓN FALLIDA";
        [SerializeField] string notaDemo = "Informe de DEMOSTRACIÓN: modelo simplificado, sin datos de misiones reales.";

        Vector2 desplazamiento;
        GUIStyle sTitulo, sSeccion, sTexto, sPequeno, sBoton, sOk, sNo;

        void Start()
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }

        void OnGUI()
        {
            PrepararEstilos();

            float escala = Mathf.Min(Screen.width / 1920f, Screen.height / 1080f);
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(escala, escala, 1f));
            Rellenar(new Rect(0, 0, Screen.width / escala, Screen.height / escala), new Color(0.02f, 0.08f, 0.11f));

            InformeMision inf = InformeMision.Ultimo;
            bool volver = false, repetir = false;

            if (inf == null)
            {
                GUILayout.BeginArea(new Rect(40, 40, 1000, 400));
                GUILayout.Label("No hay ningún informe todavía.", sTitulo);
                GUILayout.Label("Juega una misión empezando en la escena Configuracion.", sTexto);
                if (GUILayout.Button("IR A LA CONFIGURACIÓN", sBoton, GUILayout.Height(56), GUILayout.Width(420))) volver = true;
                GUILayout.EndArea();
            }
            else
            {
                DibujarColumnaIzquierda(inf);
                DibujarColumnaDerecha(inf, ref volver, ref repetir);
            }

            GUI.matrix = Matrix4x4.identity;

            // Cambios de escena al final del evento.
            if (volver) SceneManager.LoadScene(escenaConfiguracion);
            if (repetir && inf != null)
            {
                MisionActual.Guardar(inf.eleccion);
                SceneManager.LoadScene(escenaExploracion);
            }
        }

        void DibujarColumnaIzquierda(InformeMision inf)
        {
            GUILayout.BeginArea(new Rect(40, 25, 900, 1035));

            string titulo; Color color;
            switch (inf.resultado)
            {
                case ResultadoMision.Exito: titulo = tituloExito; color = new Color(0.45f, 1f, 0.6f); break;
                case ResultadoMision.ExitoParcial: titulo = tituloParcial; color = new Color(1f, 0.82f, 0.35f); break;
                default: titulo = tituloFracaso; color = new Color(1f, 0.45f, 0.4f); break;
            }
            Color previo = sTitulo.normal.textColor;
            sTitulo.normal.textColor = color;
            GUILayout.Label(titulo, sTitulo);
            sTitulo.normal.textColor = previo;

            GUILayout.Label($"Duración: {inf.DuracionTexto()} · " + Motivo(inf.motivo), sTexto);

            Seccion("OBJETIVOS");
            Check(inf.ObjetivoCumplido, $"Transmitir {inf.escaneosRequeridos} escaneos ({inf.escaneosTransmitidos}/{inf.escaneosRequeridos})");
            Check(inf.SondaOperativa, "Terminar con la sonda operativa (energía > 0)");
            Check(inf.costeMUSD <= inf.presupuestoMUSD, $"Respetar el presupuesto ({inf.costeMUSD:0}/{inf.presupuestoMUSD:0} M USD)");
            Check(inf.instrumentoRecomendado, "Usar el instrumento recomendado para el objetivo");

            Seccion("CONFIGURACIÓN");
            Linea($"Objetivo: {inf.objetivo}");
            Linea($"Instrumento: {inf.instrumento} · Batería: {inf.bateria}");
            Linea($"Lanzador: {inf.lanzador} · Relevo: {inf.orbita}");
            Linea($"Masa de la sonda {inf.masaSondaKg:0} kg · carga en el lanzador {inf.masaLanzamientoKg:0}/{inf.capacidadLanzadorKg:0} kg");

            Seccion("ENERGÍA");
            Barra("Final", inf.energiaFinalWh, inf.capacidadWh, "Wh", new Color(0.3f, 0.9f, 1f));
            Linea($"Consumida: {inf.energiaConsumidaWh:0.0} Wh · Recargada en la estación: {inf.energiaRecargadaWh:0.0} Wh");
            Linea($"  Sistemas y movimiento {inf.energiaSistemasYMovimientoWh:0.0} Wh · " +
                  $"Escaneo {inf.energiaEscaneoWh:0.0} Wh · Transmisión {inf.energiaTransmisionWh:0.0} Wh");

            Seccion("DATOS");
            Linea($"Recogidos: {inf.datosRecogidosMB:0} MB en {inf.escaneosRealizados} escaneos");
            Linea($"Transmitidos: {inf.datosTransmitidosMB:0} MB · Perdidos en memoria: {inf.datosPerdidosMB:0} MB");
            Linea($"Tiempo sin contacto con el relevo: {inf.segundosSinContacto:0} s · Memoria llena: {inf.vecesMemoriaLlena} veces");

            GUILayout.FlexibleSpace();
            GUILayout.Label(notaDemo, sPequeno);
            GUILayout.EndArea();
        }

        void DibujarColumnaDerecha(InformeMision inf, ref bool volver, ref bool repetir)
        {
            GUILayout.BeginArea(new Rect(980, 25, 900, 1035));

            Seccion("POR QUÉ");
            desplazamiento = GUILayout.BeginScrollView(desplazamiento, GUILayout.Height(560));
            foreach (string e in inf.explicaciones)
            {
                GUILayout.Label("• " + e, sTexto);
                GUILayout.Space(6);
            }
            GUILayout.EndScrollView();

            Seccion("PUNTUACIÓN (DEMOSTRACIÓN)");
            Linea($"Valor científico transmitido: {inf.puntosCiencia} ({inf.escaneosTransmitidos} × {inf.valorPorEscaneo})");
            Linea($"Bono por objetivo cumplido: {inf.bonoObjetivo}");
            Linea($"Bono por presupuesto sobrante: {inf.bonoPresupuesto} " +
                  $"({inf.puntosPorMUSDSobrante:0.##} por M USD, solo si se cumple el objetivo)");
            GUILayout.Label($"TOTAL: {inf.puntuacionTotal} puntos", sSeccion);

            GUILayout.FlexibleSpace();
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("VOLVER A CONFIGURAR", sBoton, GUILayout.Height(64))) volver = true;
            if (GUILayout.Button("REPETIR CON LA MISMA CONFIGURACIÓN", sBoton, GUILayout.Height(64))) repetir = true;
            GUILayout.EndHorizontal();
            GUILayout.Space(10);
            GUILayout.EndArea();
        }

        static string Motivo(MotivoFin m)
        {
            switch (m)
            {
                case MotivoFin.ObjetivoCumplido: return "fin: objetivo cumplido";
                case MotivoFin.BateriaAgotada: return "fin: batería agotada";
                default: return "fin: terminada por el equipo en la estación";
            }
        }

        void Seccion(string t)
        {
            GUILayout.Space(14);
            GUILayout.Label(t, sSeccion);
        }

        void Linea(string t) => GUILayout.Label(t, sTexto);

        void Check(bool ok, string t)
        {
            GUILayout.Label((ok ? "[OK] " : "[X] ") + t, ok ? sOk : sNo);
        }

        void Barra(string etiqueta, float valor, float maximo, string unidad, Color color)
        {
            GUILayout.Label($"{etiqueta}: {valor:0.0} / {maximo:0} {unidad}", sTexto);
            Rect r = GUILayoutUtility.GetRect(600, 18, GUILayout.ExpandWidth(true));
            Rellenar(r, new Color(1f, 1f, 1f, 0.12f));
            float f = maximo > 0f ? Mathf.Clamp01(valor / maximo) : 0f;
            Rellenar(new Rect(r.x, r.y, r.width * f, r.height), color);
            GUILayout.Space(4);
        }

        static void Rellenar(Rect r, Color c)
        {
            Color previo = GUI.color;
            GUI.color = c;
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = previo;
        }

        void PrepararEstilos()
        {
            if (sTitulo != null) return;

            sTitulo = new GUIStyle(GUI.skin.label) { fontSize = 40, fontStyle = FontStyle.Bold };
            sTitulo.normal.textColor = Color.white;

            sSeccion = new GUIStyle(GUI.skin.label) { fontSize = 22, fontStyle = FontStyle.Bold };
            sSeccion.normal.textColor = new Color(0.55f, 0.85f, 0.95f);

            sTexto = new GUIStyle(GUI.skin.label) { fontSize = 19, wordWrap = true, richText = true };
            sTexto.normal.textColor = Color.white;

            sPequeno = new GUIStyle(GUI.skin.label) { fontSize = 16, wordWrap = true };
            sPequeno.normal.textColor = new Color(0.78f, 0.88f, 0.93f);

            sBoton = new GUIStyle(GUI.skin.button) { fontSize = 20, fontStyle = FontStyle.Bold, wordWrap = true };

            sOk = new GUIStyle(sTexto);
            sOk.normal.textColor = new Color(0.45f, 1f, 0.6f);

            sNo = new GUIStyle(sTexto);
            sNo.normal.textColor = new Color(1f, 0.45f, 0.4f);
        }
    }
}
