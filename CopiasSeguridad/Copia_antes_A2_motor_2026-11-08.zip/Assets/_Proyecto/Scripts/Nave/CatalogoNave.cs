using UnityEngine;

namespace PrototipoMision
{
    /// <summary>
    /// Datos de la NAVE TRIPULADA FICTICIA, separados de los de la sonda.
    /// Se editan en el asset Data/CatalogoNave desde el Inspector. Todo es DEMOSTRACIÓN.
    ///
    /// Reglas de demostración que relacionan la nave con la configuración de la misión:
    /// 1. La carga científica (sonda + satélite de relevo) viaja a bordo de la nave.
    /// 2. La capacidad que sobra en el lanzador elegido se llena con combustible extra
    ///    para la nave (kgCombustiblePorKgMargenLanzador kg por cada kg sobrante).
    /// 3. Masa total de la nave = masa seca + combustible + carga científica.
    /// 4. Aceleración de maniobra = empuje / masa total (más masa, menos agilidad).
    /// 5. Combustible para entrar en órbita = base × (masa actual / masa de referencia),
    ///    más un sobrecoste si se frena fuera del momento justo.
    /// La batería de la sonda NO es la energía de la nave: la nave tiene la suya.
    /// </summary>
    [CreateAssetMenu(fileName = "CatalogoNave", menuName = "Prototipo/Catálogo de la nave")]
    public class CatalogoNave : ScriptableObject
    {
        [TextArea(2, 4)]
        public string aviso =
            "DEMOSTRACIÓN: nave tripulada ficticia y viaje comprimido. No representa una misión real " +
            "ni la duración real de un viaje a una luna helada.";

        [Header("Nave (independiente de la sonda) — DEMOSTRACIÓN")]
        [Tooltip("Masa de la nave vacía, sin combustible ni carga científica, en kg.")]
        public float masaSecaKg = 6000f;

        [Tooltip("Combustible que lleva siempre la nave, en kg.")]
        public float combustibleBaseKg = 300f;

        [Tooltip("Regla de demostración: kg de combustible extra por cada kg de capacidad sobrante del lanzador.")]
        public float kgCombustiblePorKgMargenLanzador = 1f;

        [Tooltip("Energía de los sistemas de la nave, en Wh. Es distinta de la batería de la sonda.")]
        public float energiaNaveWh = 1000f;

        [Tooltip("Integridad del casco al despegar, en %. Si llega a 0, la misión se aborta.")]
        public float integridadInicial = 100f;

        [Header("Maniobras laterales (puesto de pilotaje)")]
        [Tooltip("Empuje de los propulsores de maniobra, en newtons (N).")]
        public float empujeManiobraN = 26000f;

        [Tooltip("Combustible que gastan los propulsores a pleno empuje, en kg por segundo real.")]
        public float consumoManiobraKgS = 2.5f;

        [Tooltip("Desplazamiento lateral máximo respecto a la ruta, en metros.")]
        public float limiteDesplazamientoM = 14f;

        [Tooltip("Radio de choque de la nave, en metros (medio ancho de la cabina).")]
        public float radioNaveM = 4f;

        [Header("Entrada en órbita (llegada)")]
        [Tooltip("Combustible para frenar y quedar en órbita con una frenada perfecta y la masa de referencia, en kg.")]
        public float combustibleInsercionKg = 180f;

        [Tooltip("Masa de referencia para el coste de la inserción, en kg.")]
        public float masaReferenciaKg = 6500f;

        [Tooltip("Sobrecoste máximo de la inserción si se frena en el peor momento (0,6 = +60 %).")]
        public float sobrecosteMaximoInsercion = 0.4f;

        [Tooltip("Error de tiempo (0 a 0,5) que se considera zona verde.")]
        public float zonaVerdeInsercion = 0.08f;

        [Tooltip("Regla simplificada: con una frenada imprecisa, la órbita queda más lejos del punto de acceso y el " +
                 "descenso se prolonga; la sonda llega con menos carga. Fracción máxima de reducción (0,1 = 10 %).")]
        [Range(0f, 0.1f)]
        public float reduccionMaximaCargaSonda = 0.1f;

        [Header("Puntos de viaje — DEMOSTRACIÓN")]
        [Tooltip("Reparación: fracción de energía de la nave perdida para obtener los puntos máximos / intermedios.")]
        public float perdidaEnergiaBuena = 0.25f;
        public float perdidaEnergiaRegular = 0.5f;
        public int puntosReparacionBuena = 5;
        public int puntosReparacionRegular = 2;
        public int puntosSinImpactos = 6;
        public int puntosUnImpacto = 3;

        [Header("Escombros (peligro FICTICIO localizado)")]
        [Tooltip("Daño al casco por cada impacto, en %.")]
        public float danoPorImpacto = 25f;

        [Tooltip("Velocidad con la que se acercan los escombros, en m/s.")]
        public float velocidadEscombrosMS = 45f;

        [Tooltip("Segundos reales entre escombros.")]
        public float intervaloEscombrosS = 1.5f;

        [Tooltip("Fracción de escombros que vienen directos hacia la nave.")]
        [Range(0f, 1f)]
        public float fraccionEscombrosApuntados = 0.6f;

        [Header("Avería eléctrica (puesto de ingeniería)")]
        [Tooltip("Energía de la nave que se pierde por segundo real mientras dura la avería, en Wh.")]
        public float perdidaAveriaWhPorS = 12f;

        [Tooltip("Energía que se pierde por cada paso equivocado al reparar, en Wh.")]
        public float perdidaErrorAveriaWh = 40f;

        /// <summary>Calcula los datos de la nave para una configuración de misión.</summary>
        public ResumenNave Calcular(ResumenMision mision)
        {
            ResumenNave n = new ResumenNave();
            if (mision != null)
            {
                n.cargaCientificaKg = mision.masaLanzamientoKg;          // sonda + relevo
                n.capacidadLanzadorKg = mision.capacidadLanzadorKg;
            }
            n.margenLanzadorKg = Mathf.Max(0f, n.capacidadLanzadorKg - n.cargaCientificaKg);
            n.combustibleBaseKg = combustibleBaseKg;
            n.combustibleExtraKg = n.margenLanzadorKg * kgCombustiblePorKgMargenLanzador;
            n.combustibleInicialKg = combustibleBaseKg + n.combustibleExtraKg;
            n.masaSecaKg = masaSecaKg;
            n.masaInicialKg = masaSecaKg + n.combustibleInicialKg + n.cargaCientificaKg;
            n.aceleracionInicialMS2 = n.masaInicialKg > 0f ? empujeManiobraN / n.masaInicialKg : 0f;
            n.energiaWh = energiaNaveWh;
            return n;
        }

        /// <summary>
        /// Fracción de carga que pierde la sonda por una frenada imprecisa (0 en la zona verde,
        /// hasta reduccionMaximaCargaSonda en el peor momento). Nunca supera el 10 %.
        /// </summary>
        public float ReduccionCargaSonda(float error)
        {
            if (error <= zonaVerdeInsercion) return 0f;
            float t = Mathf.Clamp01((error - zonaVerdeInsercion) / Mathf.Max(0.0001f, 0.5f - zonaVerdeInsercion));
            return Mathf.Clamp(t * reduccionMaximaCargaSonda, 0f, 0.1f);
        }

        public int PuntosReparacion(float fraccionEnergiaPerdida)
        {
            if (fraccionEnergiaPerdida <= perdidaEnergiaBuena) return puntosReparacionBuena;
            if (fraccionEnergiaPerdida <= perdidaEnergiaRegular) return puntosReparacionRegular;
            return 0;
        }

        public int PuntosEscombros(int impactos)
        {
            if (impactos <= 0) return puntosSinImpactos;
            if (impactos == 1) return puntosUnImpacto;
            return 0;
        }

        /// <summary>Combustible para entrar en órbita con una masa y un error de tiempo (0 a 0,5).</summary>
        public float CosteInsercion(float masaActualKg, float error)
        {
            float factorMasa = masaReferenciaKg > 0f ? masaActualKg / masaReferenciaKg : 1f;
            float sobrecoste = Mathf.Clamp01(error / 0.5f) * sobrecosteMaximoInsercion;
            return combustibleInsercionKg * factorMasa * (1f + sobrecoste);
        }
    }

    /// <summary>Datos calculados de la nave para la configuración elegida.</summary>
    public class ResumenNave
    {
        public float cargaCientificaKg;
        public float capacidadLanzadorKg;
        public float margenLanzadorKg;
        public float combustibleBaseKg;
        public float combustibleExtraKg;
        public float combustibleInicialKg;
        public float masaSecaKg;
        public float masaInicialKg;
        public float aceleracionInicialMS2;
        public float energiaWh;
    }
}
