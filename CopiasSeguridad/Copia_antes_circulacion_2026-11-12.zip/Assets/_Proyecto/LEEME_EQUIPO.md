# Prototipo de misión — guía rápida del equipo

Nombre del proyecto provisional: `PrototipoMisionSonda`.
Motor: Unity 6.3 LTS (6000.3.28f1) · URP · Windows · Input System (New).

## Qué hay hasta ahora

- **Incremento 1:** sonda en primera persona, estación que recarga, energía, interfaz mínima.
- **Incremento 2:** pantalla de configuración (objetivo, instrumento, batería, lanzador,
  órbita de relevo) con límites de presupuesto y de masa. La batería y la masa elegidas
  se aplican en la exploración.
- **Incremento 3:** escáner (tecla E), 3 puntos científicos con fichas, memoria de datos y
  transmisión desde la estación según la órbita elegida.
- **Centro de operaciones:** escena inicial con la estación orbital propia, una luna de fondo
  y el satélite de relevo. Solo visual: no cambia las mecánicas.
- **Incremento 4:** informe de resultados (éxito, parcial o fracaso) con explicaciones,
  puntuación de demostración y botones para reconfigurar o repetir.

## Menús de creación (Prototipo)

| Menú | Qué hace |
|---|---|
| 1. Crear escena de exploración | Crea `Scenes/Exploracion` (pregunta antes de sustituir) |
| 2. Crear escena de configuración | Crea `Data/CatalogoMision` (si no existe) y `Scenes/Configuracion` |
| 3. Conectar configuración a Exploracion | **Añade** el objeto AplicadorConfiguracion a Exploracion |
| 4. Añadir ciencia a Exploracion | Crea fichas y el prefab PuntoCientifico; **añade** SistemaCiencia y 3 puntos |
| 5. Crear resultados y conectar Exploracion | Crea `Scenes/Resultados`; **añade** ControlMision a Exploracion |
| 6. Crear centro de operaciones | Crea `Scenes/CentroOperaciones` y la pone primera en la compilación |
| 7. Ajustar encuadre del centro de operaciones | Mueve estación, luna, satélite y Sol a la disposición calculada. **No guarda**: Ctrl+S para guardar, Ctrl+Z para deshacer |
| 8. Crear escena Nave | Crea `Data/CatalogoNave` (si no existe) y `Scenes/Nave`, y la pone en la compilación después de Configuracion |

Orden del juego: **CentroOperaciones → Configuracion → Nave → Exploracion → Resultados**.
Si la escena Nave no existe o no está en la compilación, Configuracion va directamente a Exploracion.

Recursos externos: solo los de `Externos/NASA`. Sus créditos y condiciones están en
`CREDITOS.md`. **Antes de añadir otro recurso externo, regístralo ahí.**

Para jugar el recorrido completo: abre `Scenes/Configuracion` y pulsa **Play**.
Si pulsas Play directamente en Exploracion, se usan las primeras opciones del catálogo.

## Tareas sin programar

| Quiero… | Dónde |
|---|---|
| Cambiar presupuesto, costes, masas, baterías, instrumentos… | `Data/CatalogoMision` |
| Añadir una opción (p. ej. un tercer instrumento) | `Data/CatalogoMision` → botón **+** de la lista |
| Cambiar o añadir objetivos científicos | `Data/CatalogoMision` → lista **Objetivos** |
| Cambiar el texto o la imagen de una ficha | `Data/Fichas` → selecciona la ficha |
| Crear una ficha nueva | Clic derecho en `Data/Fichas` → **Create → Prototipo → Ficha científica** |
| Añadir un punto escaneable | Arrastra `Prefabs/PuntoCientifico` a la escena y asígnale una ficha |
| Mover un punto científico | Objeto **PuntosCientificos** de la escena → selecciona el punto y muévelo |
| Cambiar alcance del escáner o ventanas de contacto | Objeto **SistemaCiencia** → **Escaner** y **Sistema Datos** |
| Cambiar bonos de la puntuación | `Data/CatalogoMision` → **Puntuación del informe** |
| Cambiar esperas antes del informe o textos de fin | Objeto **ControlMision** de Exploracion |
| Cambiar títulos del informe | Escena Resultados → **PantallaResultados** |
| Cambiar textos de la pantalla inicial | Escena CentroOperaciones → **CentroOperaciones** |
| Mover la luna, la estación o el satélite | Escena CentroOperaciones; la velocidad está en **Movimiento Visual** |
| Cambiar el aspecto de la estación orbital | Doble clic en `Prefabs/EstacionOrbital` |
| Cambiar los consumos de la sonda o la recarga | `Prefabs/Sonda` → **Sistema Energia** |
| Cambiar velocidad, masa de referencia o ratón | `Prefabs/Sonda` → **Controlador Sonda** |
| Mover la estación | Selecciónala en la escena y muévela (herramienta Move, tecla W) |
| Cambiar el aspecto de la estación | Doble clic en `Prefabs/Estacion` |
| Cambiar textos de la interfaz | **Interfaz → Hud Minimo** y **PantallaConfiguracion** |
| Cambiar colores | Carpeta `Materials` → campo **Base Map** |
| Mover rocas o plantas | Objetos **Rocas** y **PlantasLuminosas** de la escena |

**Atención:** la capacidad de la batería ahora la decide el catálogo. El campo
*Capacidad Wh* de Sistema Energia solo se usa si falta el AplicadorConfiguracion.

Pasa el ratón sobre cada campo del Inspector para ver su explicación y sus unidades.

## Qué decisión afecta a qué

| Decisión | Efecto | Estado |
|---|---|---|
| Batería | Capacidad de energía (Wh) | APLICADO |
| Instrumento + batería | Masa de la sonda → aceleración | APLICADO |
| Todo | Coste total frente al presupuesto | APLICADO (bloquea) |
| Instrumento + batería + órbita | Carga frente a la capacidad del lanzador | APLICADO (bloquea) |
| Instrumento | Consumo, duración y MB de cada escaneo | APLICADO |
| Sonda base | Memoria: si se llena, no se puede escanear | APLICADO |
| Órbita | Velocidad de transmisión y ventanas de contacto | APLICADO |
| Objetivo | Escaneos que hay que transmitir | APLICADO |
| Objetivo + instrumento | Valor científico (×2 con el instrumento recomendado) | APLICADO |
| Todo | Informe final con explicación y puntuación | APLICADO |

El lanzador y la órbita **no** se simulan físicamente: solo cambian coste, masa y
velocidad de transmisión.

### Qué bloquea el botón INICIAR MISIÓN

1. Coste total mayor que el presupuesto.
2. Carga (sonda + satélite de relevo) mayor que la capacidad del lanzador.
3. Memoria menor que los datos de un solo escaneo del instrumento elegido.
4. Órbita sin enlace (velocidad o fracción de contacto en 0).
5. Objetivo con menos de 1 escaneo requerido.

Las reglas 3 a 5 solo pueden aparecer si se editan los valores del catálogo.
Avisos que **no** bloquean: instrumento no recomendado, datos previstos mayores que la
memoria (habrá que volver a transmitir) y escanear más de la mitad de la batería.

### Masa: qué cuenta dónde

- **Carga en el lanzador** = sonda + satélite de relevo. Se compara con la capacidad del lanzador.
- **Masa de la sonda** = estructura + instrumento + batería. Es la que cambia la aceleración
  en la exploración (referencia: 170 kg en *Controlador Sonda*).

### Avisos al editar valores

- La escala de tiempo está en dos sitios: *Minutos Mision Por Segundo* del catálogo (solo para
  estimaciones) y de *Sistema Energia* en el prefab Sonda (la que usa el juego). Deben
  coincidir; si no, la Console lo avisa al empezar la exploración.
- Si el objetivo pide más escaneos que puntos científicos hay en la escena, la Console y el
  panel de datos lo avisan: el objetivo sería imposible.
- El catálogo guardado aún no incluye los campos añadidos después de crearlo (consumo de
  transmisión, multiplicador del instrumento recomendado y bonos de puntuación). Unity usa
  sus valores por defecto (25 W, ×2, +10 y 0,5). Se ven en el Inspector al seleccionar el
  catálogo y se escribirán en el archivo la próxima vez que se modifique y guarde.

## Escena Nave (primera persona)

Nave tripulada **ficticia** y viaje **comprimido**: DEMOSTRACIÓN. Los escombros son un peligro
ficticio localizado, no una descripción del cinturón de asteroides.

Recorrido: **preparación → despegue → viaje con eventos → llegada y entrada en órbita → despliegue de la sonda**.

| Puesto | Qué se hace | Rol del modo equipo (para el futuro) |
|---|---|---|
| Pilotaje (frente, ventana) | Despegar; esquivar escombros con WASD; frenar para entrar en órbita (Espacio en la zona verde) | Lanzamiento |
| Ingeniería (izquierda) | Revisar los datos de la nave; reparar la avería: aislar circuito (1/2/3) → reserva (R) → restablecer (Espacio) | Ingeniería |
| Comunicaciones (derecha) | Recibir y confirmar las instrucciones del centro (Espacio) | Comunicaciones |
| Ciencia (fondo) | Revisar la sonda; desplegarla en órbita | Ciencia |

Controles: **WASD** caminar · **ratón** mirar · **E** usar el puesto que miras · **Q** salir del puesto ·
**Espacio** acción principal del puesto · clic para recuperar el ratón.
La luz de cada puesto indica: ámbar = tarea pendiente, roja = alarma, verde = correcto.

Consecuencias visibles: impactos (destello rojo, vibración, casco −25 %), avería (luces rojas,
pérdida de energía), combustible gastado en maniobras y frenada. La misión **se aborta** si el casco
llega a 0 %, si la energía de la nave llega a 0 o si no queda combustible para frenar.

**Datos de la nave separados de la sonda** (asset `Data/CatalogoNave`). Reglas de demostración:
1. La carga científica (sonda + relevo) viaja a bordo.
2. La capacidad sobrante del lanzador se llena con combustible extra (1 kg por kg).
3. Masa de la nave = masa seca + combustible + carga científica.
4. Aceleración de maniobra = empuje / masa.
5. Combustible para frenar = base (180 kg) × masa actual / masa de referencia, más hasta un 40 % si se frena fuera de tiempo.
La batería de la sonda sigue siendo solo de la sonda; la nave tiene su propia energía.

**Consecuencias del viaje** (evaluación al entrar en órbita, antes de desplegar; DEMOSTRACIÓN):

| Acción | Resultado | Consecuencia |
|---|---|---|
| Reparar la avería | energía de la nave perdida ≤ 25 % / ≤ 50 % / más | +5 / +2 / 0 puntos de viaje |
| Escombros | 0 impactos / 1 / 2 o más | +6 / +3 / 0 puntos de viaje |
| Separar la etapa (Pilotaje, durante el ascenso) | dentro de la ventana verde / antes / sin pulsar | +5 / 0 (temprana) / 0 (el ordenador la separa tarde). Siempre se continúa. Procedimiento simplificado: solo cuenta en la evaluación |
| Frenar para entrar en órbita | zona verde / fuera | **sin puntos**: la sonda empieza con hasta un 10 % menos de carga (regla simplificada: descenso prolongado). La capacidad máxima no cambia y la estación recarga igual |

Los puntos de viaje solo cuentan si la sonda se despliega. El presupuesto no cambia: se valida solo en
Configuracion y su bono se mantiene igual. Resultados muestra por separado ciencia, objetivo,
presupuesto, viaje y total. Umbrales y puntos: asset `CatalogoNave` (sección *Puntos de viaje*).

La sonda empieza en (0, 2, 0), **dentro** de la zona de recarga de la estación (esfera de 6 m):
la carga perdida en el descenso se recupera en unos 2 s si la sonda se queda allí (300 W de recarga).

**Separación de etapa**: el panel de Pilotaje la explica antes de la cuenta atrás. Durante el ascenso
aparece una barra; pulsa Espacio cuando el marcador esté en la zona verde (al menos 2,5 s, también en
modo de prueba). El ascenso espera a que se resuelva. El panel muestra el lanzador elegido, la carga y
el combustible extra. Ajustes en ControlNave: *Inicio Ventana Etapa*, *Ventana Etapa Minima S*, *Puntos Separacion*.

**Transición de llegada**: tras desplegar la sonda, tres tarjetas (llegada, sistema de acceso, descenso
al océano) con un corte esquemático animado. Espacio: siguiente · Intro: omitir. Aclara que el paso por
el hielo está simplificado. Es solo visual (`TransicionDescenso.cs`, la crea ControlNave en tiempo de
ejecución; no hay objetos nuevos en la escena). Se desactiva con *Mostrar Transicion* en ControlNave.

**Modo de prueba**: en el objeto ControlNave (escena Nave), casilla *Modo Prueba*. Usa los
*Tiempos Prueba* (cuenta atrás 3 s, viaje 40 s) en lugar de los *Tiempos Normales* (10 s, 150 s).
Los momentos de la avería y de los escombros también se editan ahí.

## Modo equipo (1 a 4 jugadores en el mismo PC)

Estado: código conservado; su ampliación está en pausa mientras se construye la nave.

En la pantalla de configuración, bloque **EQUIPO**:

- **Jugadores**: 1 a 4. Con 1 jugador todo funciona como antes.
- **Roles**: cada rol tiene un responsable (J1…J4) y se puede reasignar.
  | Rol | Decide | Prioridad (umbral en el catálogo, DEMOSTRACIÓN) |
  |---|---|---|
  | Ciencia | Objetivo e instrumento | Usar el instrumento recomendado |
  | Ingeniería | Batería | Margen tras escanear ≥ *Margen Energia Minimo Wh* (100) |
  | Lanzamiento | Lanzador | Reserva de presupuesto ≥ *Reserva Presupuesto Minima MUSD* (20) |
  | Comunicaciones | Órbita del relevo | Transmitir todo en ≤ *Tiempo Transmision Maximo S* (20 s) |
- Reparto inicial: 2 jugadores → J1 Ciencia + Comunicaciones, J2 Ingeniería + Lanzamiento;
  3 → J2 lleva Ingeniería y Lanzamiento; 4 → un rol cada uno.
- **Turno**: el jugador que tiene el teclado. Solo puede cambiar las secciones de sus roles.
- **Aprobaciones**: para iniciar, todos deben pulsar su botón. Cualquier cambio de opción,
  de jugadores o de reparto anula las aprobaciones.
- Las prioridades **no bloquean** el inicio. Con los valores actuales ninguna configuración
  válida cumple las cuatro a la vez: el equipo tiene que negociar cuál ceder.
- El informe final muestra, por rol, si el plan cumplía su prioridad y qué pasó de verdad.

Por qué en el mismo PC: en clase o en el evento el equipo comparte una pantalla y discute en
voz alta. El juego reparte la responsabilidad y obliga a llegar a un acuerdo; no hay red.

Archivos: `Scripts/Equipo/ModoEquipo.cs` (roles y prioridades), cambios en
`PantallaConfiguracion`, `ControlMision`, `InformeMision`, `PantallaResultados`,
`AplicadorConfiguracion` y tres campos nuevos en `CatalogoMision`.

## Controles

| Tecla | Acción |
|---|---|
| WASD / Espacio / Ctrl o C / Shift | Mover, subir, bajar, turbo |
| Ratón | Mirar |
| E (mantener) | Escanear el punto apuntado |
| F | Cerrar la ficha |
| T (en la estación) | Terminar la misión y ver el informe |
| M | Volver a la configuración |
| F9 | Mostrar u ocultar el medidor de rendimiento (FPS), en cualquier escena y en el ejecutable |
| Esc / clic | Liberar / recuperar el cursor |

**Probar la interfaz:** usa la vista Game con resolución fija 16:9 (por ejemplo 1920×1080) y
*Scale* en 1x. La interfaz se escala según la altura de la ventana: en ventanas muy bajas
(unos 500 px) los textos pequeños dejan de ser legibles.

**Pruebas de aceptación:** ver `PRUEBAS_ACEPTACION.md`.

## Unidades

- **M USD:** millones de dólares.
- **kg:** masa.
- **W (vatio):** cuánta energía se gasta en cada instante.
- **Wh (vatio-hora):** cuánta energía hay guardada. 1 Wh = 1 W durante 1 hora.
- **MB / MB/s:** cantidad de datos y velocidad de transmisión.
- **Datos recogidos:** guardados en la memoria de la sonda. **Datos transmitidos:** enviados al
  satélite de relevo desde la estación. Solo los transmitidos cuentan para el objetivo.
- **Escala de tiempo:** 1 segundo real = 1 minuto de misión (editable).

Todos los valores son de **DEMOSTRACIÓN**. No proceden de ninguna misión real.

## Licencias (pendiente de decidir y verificar)

| Tipo | Elemento | Estado |
|---|---|---|
| Código propio | `Scripts/` y `Editor/` | Licencia OSI por elegir (p. ej. MIT o Apache-2.0) |
| Dependencias del motor | Unity Editor, URP, Input System | Términos de Unity; confirmar cada paquete en el Package Manager |
| Recursos de terceros | Textura de Europa y modelo TDRS (NASA 3D Resources) | Ver `CREDITOS.md` |
| Datos científicos | Ninguno hasta ahora; las fichas son textos ficticios marcados DEMOSTRACIÓN | Si se añaden datos reales, anotar la fuente en cada ficha |
| Valores de demostración | Catálogo de misión, consumos, recarga, escala de tiempo | Marcados como DEMOSTRACIÓN |

Pendiente de verificar con la organización: si depender de un motor no OSI
(Unity) es aceptable según las reglas de entrega de NASA Space Apps 2026.

## Muestra visual: sector delantero de la nave (en evaluación)

Estilo: exploración de ciencia ficción, azul y turquesa con acentos naranja cálido. Formas, texturas y
materiales generados por el propio proyecto (sin recursos de otros juegos). Las formas simples siguen
siendo provisionales fuera de este sector.

- Aplicar: escena **Nave** abierta, fuera de Play → *Prototipo → Muestra visual → 1. Aplicar: sector delantero de la nave*. Después, Ctrl+S.
- Quitar: *… → 1. Quitar: sector delantero de la nave*. Restaura lo ocultado, la luz ambiental y el posprocesado de la cámara. Después, Ctrl+S.
- Todo cuelga de `VISUAL_MUESTRA_NAVE`; ninguna pieza tiene colisionador. Se ocultan (no se borran) la consola y la pantalla de pilotaje (sus colisionadores siguen) y los listones antiguos de la ventana.
- Recursos en `Assets/_Proyecto/Visual/` (texturas, materiales `MV_…`, perfil `PerfilCabina`). Se crean solo si no existen: se pueden retocar en el Inspector sin que el menú los sobrescriba.
- Scripts visuales (`Scripts/Visual/`): `PantallaDatosNave` (las pantallas muestran datos de ControlNave, solo lectura), `LucesReactivasVisual` (las tiras de luz siguen el color de las luces de alerta), `CapaVisual` (registro para quitar la muestra).

## Demostración tripulada (recorrido principal)

Configuracion → Nave (preparación, despegue, viaje, llegada) → **Resultados**. Al entrar en órbita y
confirmar el mensaje "Objetivo alcanzado", la misión termina. La exploración con la sonda queda como
fase posterior opcional (botón en Resultados).

Evaluación de la misión tripulada (DEMOSTRACIÓN, separada de la de exploración): llegada al destino
(+10, *Puntos Llegada* en ControlNave) + presupuesto sobrante (0,5 por M USD, solo si se llega) +
puntos de viaje (separación, reparación, escombros). **No incluye ciencia**: no se dan por hechos los escaneos.

El panel de la nave muestra siempre el destino y la distancia restante. La distancia es simulada
(*Distancia Simulada Mkm*): el progreso del viaje es guionizado.

Para volver al recorrido con exploración: desactiva *Terminar Al Llegar* en ControlNave.

## Selección de misión y piezas de la nave

- La primera vez, Configuracion muestra la **selección de misión** (una misión completa y dos "Próximamente").
  Datos en `CatalogoMision` → *Misión seleccionable*.
- **Motor de la nave** (sección 6): datos en `CatalogoNave` → *Motores* (el primero es el estándar). Coste al
  presupuesto; la masa **de más** sobre el estándar cuenta en el **margen de carga configurable** del lanzador
  (el vehículo tripulado base se considera incluido: simplificación). El empuje y el consumo se usan en las maniobras.
- **Tanque de la nave** (sección 7): datos en `CatalogoNave` → *Tanques*. Coste al presupuesto; la masa en vacío
  de más sobre el estándar cuenta en el margen de carga. Pone el **tope** del combustible.
- Masas de la nave: seca (*Masa Casco Kg* 5450 + motor + tanque vacío) + carga científica (sonda + relevo) +
  combustible = masa total inicial. Combustible = mínimo(capacidad del tanque, 300 base + margen sobrante, 1 kg por kg):
  el tanque no añade combustible por otra vía. La aceleración usa la masa total actual.
- `CatalogoMision` enlaza `CatalogoNave` (campo *Catalogo Nave*). Si falta, no se muestran piezas de la nave.
- Vista exterior: `Scripts/Visual/VistaNaveConfiguracion.cs`, creada en tiempo de ejecución (no hay objetos en la escena).

## Sectores de la cabina (versión reducida para la demostración)

`Scripts/Nave/SectoresNave.cs`, creado por ControlNave al empezar (casilla *Mostrar Sectores*). Rótulos, bordes
luminosos en el suelo, tabiques bajos y una luz por sector. No mueve puestos, vistas ni colisionadores y no añade
colisionadores. Sectores: 1 Pilotaje · 2 Ingeniería · 3 Comunicaciones y navegación · 4 Ciencia / control de misión.
Un jugador controla la nave; hay puestos para cuatro tripulantes (sin multijugador). La nave grande queda pendiente.

## Nave ampliada (menú 9) y restauración (menú 10)

Plano (vista desde arriba, z hacia la ventana; interior de 10,4 × 19 m, 3 m de alto):

```
              z=+5   ┌──────── VENTANA ────────┐
                     │      1  PILOTAJE        │  x ±4
              z=+1,5 └────────┐     ┌──────────┘
 ┌──────────────┐             │     │             ┌──────────────┐
 │ 4  CIENCIA / ├── puerta ───┤  P  ├── puerta ───┤ 3 COMUNIC. Y │  salas 4 × 4 m
 │ CONTROL      │             │  A  │             │ NAVEGACIÓN   │  (z −3,5 … +0,5)
 └──────────────┘             │  S  │             └──────────────┘
                              │  I  │  pasillo 2,4 m
              z=−9   ┌────────┘  L  └──────────┐
                     │      2  INGENIERÍA      │  x ±3,5
                     │  ═══ barandilla ═══     │
                     │  (tanque)     (motor)   │
              z=−14  └─────────────────────────┘
```

- **Aplicar**: escena Nave abierta, fuera de Play → *Prototipo → 9. Ampliar nave (4 sectores y pasillo)* → Ctrl+S.
  Copia la escena en `CopiasSeguridad/` antes de cambiarla. Si ya está ampliada, pregunta y la rehace.
- Desactiva (no borra) las paredes laterales y trasera originales; añade paredes, suelos y techos CON colisionador;
  mueve Ingeniería, Comunicaciones y Ciencia (con su vista); añade 4 luces a las alertas de ControlNave; sube el
  aviso de escombros del modo de prueba de 4 a 8 s. Pilotaje y la ventana no cambian.
- **Volver**: *Prototipo → 10. Volver a la cabina original* → Ctrl+S. Restaura todo lo anterior y borra NAVE_AMPLIADA.
- Escombros: se evalúan una vez en la proa (z = 5,3) y desaparecen; no atraviesan las salas.
- **No uses** el menú 8 (regenera la escena) ni la muestra visual antigua (pensada para la cabina pequeña).

## Acabado de la cabina de pilotaje (menú 11)

Capa visual reversible sobre la nave ampliada: *Prototipo → 11. Acabado: cabina de pilotaje (aplicar / quitar)*,
fuera de Play y con la escena Nave abierta; después Ctrl+S. Todo cuelga de `ACABADO_CABINA_PILOTAJE`, sin
colisionadores. Reutiliza los generadores de texturas y materiales (`Assets/_Proyecto/Visual/`, se crean la primera
vez) y la consola de `MuestraVisual`. Oculta (no borra) la consola y pantalla antiguas de pilotaje, los listones de
la ventana y el rótulo flotante "PILOTAJE". No cambia la luz ambiental; activa un posprocesado moderado.
La muestra antigua (*Muestra visual → 1.*) ya no se aplica sobre la nave ampliada.


## Despegue visto desde fuera

`CinematicaDespegue` (la añade ControlNave al empezar si *Mostrar Despegue Exterior* está activado; no está en la
escena). En los últimos 3 s de la cuenta atrás cambia a una cámara exterior: plataforma, encendido, humo, ascenso con
el cielo oscureciéndose, separación del lanzador (la orden sigue siendo Espacio en Pilotaje, sin cambios de reglas),
alejamiento con el planeta debajo y fundido de vuelta a la cabina. Intro vuelve antes. El decorado se crea lejos de la
cabina (y = −20 000) y se destruye al terminar. La nave usa el motor y el tanque elegidos con las mismas formas que la
vista de Configuracion. Planeta, altitud y velocidad son ficticios e ilustrativos (DEMOSTRACIÓN). Sonido generado por
código (sin archivos ni licencias): rumor del motor y golpe de separación; se puede sustituir más adelante por sonidos
con licencia verificada. Mientras dura la toma, HudNave oculta sus paneles laterales.

## Observación de aproximación (bonus aparte)

Durante el crucero se abre una ventana (por defecto entre el 40 % y el 56 % del viaje). En **Ciencia**, mantener
Espacio captura datos (UD) y gasta energía de la **nave** (21 Wh por UD; 12 UD como máximo ≈ 252 Wh, una cuarta parte
de la energía inicial de la nave, `CatalogoNave → energiaNaveWh` = 1000 Wh; la batería de la sonda no se toca). En
**Comunicaciones**, mantener Espacio envía los datos; solo cuentan los enviados antes de llegar. Da un bonus aparte de
0 a 6 que **no suma** a la puntuación principal (sobre 40) ni cambia sus criterios. La energía gastada en observar no
cuenta como pérdida de la avería.

- Lógica: `Scripts/Nave/ObservacionAproximacion.cs` (sin dibujo). HUD, paneles e informe solo leen su estado
  (`ControlNave.Observacion`), así que las pantallas de los modelos nuevos pueden mostrar lo mismo sin tocar la lógica.
- Ajustes en ControlNave → *Observacion*: activa, inicio y duración de la ventana (fracciones del viaje), máximo de UD,
  captura y envío por segundo, coste en Wh por UD y puntos del bonus. Valores provisionales de prueba.
- Desactivado: sin ventana, avisos, consumos ni interacción; el juego queda como antes.
- Pruebas: sección Q de PRUEBAS_ACEPTACION.

## Corrección de trayectoria antes del frenado (opcional)

Al final del crucero, con la avería reparada y los escombros terminados (desde el 85 % del viaje), se abre una ventana
de duración fija (22 s; 18 s en Modo Prueba). Delante aparece un anillo: el corredor de entrada, a 5–9 m de la
posición de la nave. En Pilotaje, con WASD (los mismos propulsores y el mismo gasto que con los escombros), hay que
centrarlo y permanecer 2 s seguidos dentro de 1,5 m. Si se completa en la primera mitad de la ventana, el marcador de
la inserción orbital va más lento (periodo 3,3 s); en la segunda mitad, 2,75 s; sin corregir, 2,2 s como siempre. No da
puntos ni cambia la puntuación principal ni el bonus de observación. La llegada espera a que termine la ventana.

- Lógica: `Scripts/Nave/CorredorAproximacion.cs` (sin dibujo). Vista: `Scripts/Nave/VistaCorredor.cs` (anillo de
  balizas que se coloca como los escombros: corredor menos desplazamiento lateral). Sustituible por un modelo.
- Ajustes en ControlNave → *Correccion* (todos provisionales). Desactivado: sin anillo, avisos, consumos ni demora.
- El combustible gastado en maniobras durante la ventana se mide y se muestra; no hay consumo nuevo.
- Pruebas: sección R de PRUEBAS_ACEPTACION.

## Navegación longitudinal (opcional, desactivada por defecto)

Con *ControlNave → Navegacion → Activa*, el crucero deja de ser un progreso guionizado: la nave sale del ascenso a
20 m/s hacia el destino, vuela por inercia (sin gravedad ni rozamiento) y el jugador acelera, gira y frena desde
**Pilotaje**. Desactivada, el juego es exactamente el de antes.

- **Mandos (solo en Pilotaje y solo en crucero):** Espacio mantenido = motor principal (empuja hacia donde apunta la
  proa); R = girar 180° (3 s, el motor queda bloqueado y la velocidad no cambia); WASD = maniobras laterales, como
  siempre. Espacio conserva la cuenta atrás, la separación y la inserción: al empezar el crucero hay que soltarlo antes
  de que encienda el motor, y en la llegada también. R sigue siendo la reparación en Ingeniería.
- **Velocidad cero:** si el motor frena la nave hasta 0, la velocidad se queda en 0 y el motor se apaga hasta soltar
  Espacio. La orientación nunca cambia sola: si se vuelve a encender, la nave se mueve hacia donde apunta la proa.
- **Unidades y escala:** metros, segundos, m/s y kg; tiempo real (sin compresión temporal). La ruta es **corta y
  comprimida** (8000 m; 2500 m en Modo Prueba): es una ruta de juego, no la distancia real a una luna, y la distancia
  decorativa de «M km» no se usa. Aceleración = empuje / masa, con el motor y el consumo del catálogo (unos 3,6 m/s² y
  2,5 kg/s con el motor estándar); no se ha cambiado ninguna masa, empuje, capacidad ni consumo.
- **Llegada:** zona de aproximación de ±250 m alrededor del final de la ruta. La inserción se autoriza dentro de la zona
  a ≤ 15 m/s y con la avería, los escombros y la corrección de trayectoria terminados. Si algo está pendiente, la nave
  **no se detiene**: se bloquea la autorización y el panel dice por qué. Si sale de la zona antes de la inserción, la
  inserción deja de estar disponible hasta volver. **Pasarse de largo** = salir de la zona por el lado del destino; la
  luna se dibuja al lado de la ruta, así que nunca se atraviesa.
- **Combustible:** tres categorías en el libro: maniobras laterales, motor principal e inserción. La inserción es el
  frenado de captura desde la zona y no depende de lo que se frenó antes con el motor principal (eso ya está cobrado).
- **Fallo:** la misión se aborta cuando la llegada **ya no puede completarse**: el combustible que queda no basta para
  llevar la nave a la zona a ≤ 15 m/s con el motor principal (si se aleja: frenar y volver a 1 m/s) **más** una
  inserción perfecta. El motivo da las cifras. No se aborta por llegar a 0 kg (siempre ocurre antes).
- **Eventos:** se colocan por la fracción **máxima** de ruta alcanzada; retroceder no repite avería, escombros,
  observación ni corrección.
- **Ruta viable de referencia** (cálculo con la regla del juego, no medido en Unity): acelerar 8 s hasta unos 50 m/s,
  volar por inercia, girar y frenar a 15 m/s antes de la zona → unos 160 s y unos 44 kg de motor principal; con la
  inserción (unos 195 kg) y las maniobras cabe en el tanque estándar de 350 kg.
- **Combustible de prueba:** *Navegacion → Combustible Prueba Activo* + *Combustible Prueba Kg* (240 por defecto).
  Solo para pruebas y solo con la navegación activada; no cambia el catálogo ni los tanques. El HUD y los Resultados lo
  marcan como «COMBUSTIBLE DE PRUEBA».
- **Vista:** esquema de la ruta abajo, marca del destino (en pantalla o en el borde; «DETRÁS» si queda a la espalda) y,
  al girar, todo el exterior (estrellas y luna) gira alrededor de la nave. Los escombros y el anillo de corrección
  siguen fijos a la proa (simplificación).
- Lógica: `Scripts/Nave/NavegacionLongitudinal.cs` (sin dibujo). Pruebas: sección S de PRUEBAS_ACEPTACION.

## Destinos configurables (11 de noviembre de 2026)

Los destinos están en *CatalogoMision → Destinos* (`Scripts/Mision/DestinoMision.cs`, solo datos). Cada uno define:
nombre, diferencia jugable (texto), aspecto provisional (tinte y tamaño del cuerpo de la ventana), longitud de la ruta
(normal y Modo Prueba), zona de aproximación, velocidad de captura y parámetros de la gravedad experimental. Se elige en
la tarjeta de la selección de misión (dos botones; cada partida va a un solo destino).

| | Luna helada (ficticia) | Planetoide denso (ficticio) |
| --- | --- | --- |
| Ruta | 8000 m (prueba 2500) | 11 000 m (prueba 3200) |
| Zona de aproximación | ±250 m | ±150 m |
| Captura | ≤ 15 m/s | ≤ 8 m/s |
| Gravedad experimental | caída 18 m/s, paso a 150 m, seguridad 100 m | caída 28 m/s, paso a 220 m, seguridad 160 m |
| Aspecto | el de siempre | anaranjado, 30 % mayor |

- La Luna conserva exactamente los valores de la navegación probada.
- La diferencia jugable se nota **con la navegación activada**. En el viaje clásico solo cambian el nombre y el aspecto.
- No cambian motores, masas, tanques, puntuación ni el coste de la inserción.
- *Navegacion → Usar Destino Elegido* (activado por defecto): desactivado, la ruta y la llegada salen del inspector,
  como en la versión probada.

## Gravedad experimental (un eje, desactivada por defecto)

*ControlNave → Navegacion → Gravedad Experimental*. Solo actúa con la navegación activada.

- **Qué representa:** la componente **a lo largo de la ruta** de la atracción de un cuerpo cuyo centro está a una
  distancia de paso *b* del final de la ruta (la ruta pasa a su lado): a(x) = −μ·x / (x² + b²)^(3/2), con x la posición
  respecto al punto de paso. μ se deduce de la «velocidad de caída»: la que ganaría la nave cayendo desde muy lejos
  hasta el punto de paso, v² = 2μ/b.
- **Qué no representa:** la componente lateral (se supone compensada), órbitas, asistencias gravitatorias, varios
  cuerpos ni escala real. No es una órbita: si no se inserta, la nave oscila a lo largo de la ruta alrededor del punto
  de paso.
- **Sin singularidad:** como b > 0, la atracción es finita en todas partes (máxima a |x| = b/√2, cero en el punto de paso).
- **Límite de seguridad:** la nave nunca se acerca al centro a menos de *b*, y *b* nunca es menor que el radio de
  seguridad del cuerpo (si se configura menor, se corrige y se avisa en la Consola). No puede llegar a la superficie.
- **Captura con gravedad:** cuenta la velocidad que la nave tendría en el borde de la zona con su energía actual (la
  gravedad la acelera hacia el centro, pero esa referencia no cambia sin motor, así que la autorización no parpadea).
- **Llegada imposible con gravedad:** se usa un mínimo teórico por energía (frenar donde la nave va más rápido). Puede
  avisar tarde, pero nunca aborta antes de tiempo.
- **Por separado:** Pilotaje muestra la aceleración de la gravedad y la del motor; el esquema dibuja la gravedad en
  azul; Resultados da el cambio de velocidad total de cada uno. La gravedad no gasta combustible.
- **Bloqueo para ir más lejos:** órbitas o asistencias gravitatorias necesitan mover la nave en dos o tres dimensiones.
  No se ha migrado; queda como incremento aparte.

## Claridad de la navegación (11 de noviembre de 2026)

Solo textos y dibujo; las reglas no cambian.

- Pilotaje empieza con «AHORA:», la acción recomendada en verde, ámbar o rojo, y después filas fijas: MOVIMIENTO
  (velocidad y si se acerca o se aleja), PROA (hacia dónde apunta y qué hace Espacio ahora: ACELERA o FRENA), MOTOR,
  GRAVEDAD (si está activa), LLEGADA y COMBUSTIBLE (mínimo para llegar y margen).
- Avisos únicos: «MOMENTO DE FRENAR» y margen de combustible por debajo de 30 kg y de 10 kg.
- Llegada bloqueada: dice qué la bloquea y cómo resolverlo, y aconseja detenerse dentro de la zona mientras tanto.
- La marca del destino no se pone debajo del panel del puesto y dice si la nave se acerca o se aleja.
- Resultados: desglose completo del combustible con navegación (al partir − maniobras − motor principal − inserción =
  al final, y si cuadra). Sin navegación, el informe es el de siempre.
- Para salir de la llegada hay un margen de 2 m y 0,5 m/s que evita el parpadeo de la autorización en el borde.

## Vuelo 3D · prueba V1 (escena VueloPrueba, 11 de noviembre de 2026)

Prueba aparte, sin gravedad. No usa ni modifica la escena Nave ni su lógica: el viaje actual sigue igual.

- **Crear la escena (una sola vez):** menú *Prototipo → 12. Crear escena VueloPrueba (vuelo 3D V1)*. Crea
  `Scenes/VueloPrueba.unity` con un único objeto `PruebaVuelo3D`; si ya existe, no la sustituye. No toca otras escenas
  ni la lista de compilación. Después: abrir `VueloPrueba` y pulsar Play.
- **Código** (`Scripts/Vuelo3D/`): `EstadoVuelo3D` y `ObjetivoBalizas` (solo lógica), `PruebaVuelo3D` (mandos y
  coordinación), `VistaVuelo3D` (mundo, nave y cámaras) y `HudVuelo3D` (indicadores). Todo se crea al pulsar Play.
- **Controles:** W/S cabeceo (W baja el morro) · A/D guiñada · Z/C alabeo · T estabilización asistida · I/K, J/L, U/O
  traslación · Espacio motor principal · V cámara (asiento o exterior) · botón derecho del ratón: mirar · H ayuda ·
  F5 reiniciar.
- **Valores del catálogo:** masa seca, combustible, empuje y consumo del motor principal (configuración elegida o, si
  la escena se abre sola, las primeras opciones).
- **Valores provisionales** (inspector de `PruebaVuelo3D`, *Maniobra*): traslación 1500 N y 0,6 kg/s por eje; giro
  8/8/12 °/s² y 0,08 kg/s por eje; límite de comodidad 45 °/s. No copian el motor principal.
- **Física simplificada:** sin gravedad ni rozamiento; empuje y consumo constantes; una aceleración angular fija por
  eje en lugar de par e inercia; posición y velocidad en doble precisión; la nave se dibuja en el origen y el mundo se
  coloca alrededor sin girarlo. Los cuerpos lejanos se dibujan a 9 km con su tamaño aparente real. Sin colisiones con
  las balizas; acercarse a menos de 300 m de la superficie de un cuerpo termina la prueba.
- **Objetivo:** Baliza 1 y después Baliza 2; detenerse a menos de 50 m, a 1 m/s o menos, durante 2 s seguidos.
  La Baliza 3 sirve de referencia detrás de la salida.

### Vuelo 3D V1 · frenado más accesible

- **Dos ayudas distintas:** *estabilización de giro* (T) solo frena la rotación; *frenado asistido* (B) frena el
  desplazamiento. El HUD lo dice en cada fila.
- **Guía:** la marca X («FRENAR: lleva la proa aquí») está en la dirección contraria al movimiento. El panel FRENADO da
  el desvío entre la proa y la X, si Espacio frena o aceleraría, y estimaciones de tiempo, distancia y combustible para
  parar con el motor o solo con traslación (empuje constante; el giro, desde parado).
- **Balizas:** distancia restante, velocidad total respecto a la baliza, acercamiento o alejamiento y velocidad lateral.
  Cuenta como detenida solo con la velocidad total.
- **Asistencia (B), opcional:** no pilota hacia ningún sitio, solo para la nave. Por encima de 2 m/s gira la proa
  progresivamente contra el movimiento (sin enderezar el alabeo) y frena con el motor; por debajo, frena con
  traslación de forma proporcional; a 0,05 m/s corta el empuje, frena el giro que quede y se apaga. Usa los mismos
  mandos que el jugador (respeta fuerzas, límite de giro y consumo) y muestra lo que gasta. B o cualquier mando la
  cancela; también se detiene sin combustible o a los 240 s. Ajustes en *PruebaVuelo3D → Frenado* (provisionales).
- Lógica: `Scripts/Vuelo3D/AsistenteFrenado.cs`. Pruebas: sección V de PRUEBAS_ACEPTACION.

## Hangar de prueba · nave base y bloque interior ampliado (escena HangarPrueba, 11 de noviembre de 2026)

Escena **aparte**: no cambia Nave, VueloPrueba ni Configuración, ni la lista de escenas del build. Vuelo 3D V1 **no**
está integrado aquí. Sin despegue, sin embarque completo, sin flotación, sin bots, sin red y sin gravedad exterior.

**Cómo abrirla:** menú *Prototipo → 13. Crear escena HangarPrueba* (solo la crea si no existe y le asigna
`Data/CatalogoMision.asset`) → abrir `Scenes/HangarPrueba.unity` → Play.

**Qué se ve:** una única base, *Expedición E-4* (cuatro tripulantes), en un hangar con marcas cada 5 m y una pasarela
provisional (el embarque no está implementado). La lista de bases admite más, pero las otras tres **no** están
definidas ni modeladas.

**Cambiar componentes:** botones ◀ ▶ del panel izquierdo (motor y tanque). Usan los catálogos y la validación de
siempre (`CatalogoMision.Calcular` + `CatalogoNave.Calcular`) y guardan la elección en `MisionActual`, la misma que leen
Configuración y Nave. Cada pieza va en su anclaje (`ANC_I2_Motor`, módulo de servicio tras `ANC_I3`), separada del casco;
al cambiar se destruye la anterior antes de construir la nueva (el panel muestra cuántas piezas hay en cada anclaje:
debe ser 1). No hay tercer módulo: la carga va en la bodega, que sigue pendiente.

**Masas:** el panel separa estructura (casco del catálogo), componentes instalados (motor, tanque vacío),
combustible y carga científica. **PROVISIONAL:** el bloque ampliado todavía no tiene balance de masa; se mantiene la masa
del casco del catálogo. No se ha cambiado ninguna masa, coste, capacidad ni empuje.

**Inspeccionar el interior:** **I** alterna exterior / cámara de inspección. La cámara de inspección es
**PROVISIONAL**: no tiene colisiones y **no** es la mecánica final de movimiento interior. WASD, Espacio/Ctrl, Mayús,
botón derecho para mirar; **1–4** sentado en Pilotaje, Ingeniería, Ciencia y Comunicaciones; **0** en la esclusa.
**C** corte (oculta techo y cubierta para ver el interior desde fuera); **L** colores de estado de las medidas
(verde conservada · azul propuesta · ámbar pendiente de prueba · naranja reserva); **H** ayuda.

**Tripulación:** seis figuras de 1,75 m (cuatro con el nombre de su rol junto a su asiento y dos maniquíes de medida en
el pasillo: uno de pie y otro en horizontal). Son **referencias de tamaño**, no bots ni jugadores conectados.

**Medidas del bloque (m; ejes: x a estribor, y arriba, z a proa; origen en la consola de referencia del diseño):**

| Elemento | Medida | Estado |
|---|---|---|
| Envolvente del casco | 20,3 × 11,6 m (z −14,8…5,5; x ±5,8) | Conservada |
| Tramos del casco | proa ±4,6 (z 1,3…5,5) · salas ±5,8 (z −4,5…1,3) · popa ±4,1 (z −14,8…−9) | Conservada |
| Tramo central | ±4,4 (z −9…−4,5), antes ±4,1 | Propuesta |
| Altura libre interior | 3,4 m (antes 3,0); casco y −1,0…3,9 (antes 3,7) | Propuesta |
| Pilotaje | x ±4,0, z 1,5…5,0; consola v0 en (0; 0; 3,30), 2,43 × 1,05 × 0,85; asiento z 2,95 | Conservada |
| Pasillo | 3,0 m de ancho libre (x ±1,5), z −9…1,5 (antes 2,4 m) | Propuesta |
| Comunicaciones / Ciencia | 3,7 × 4,8 m cada una (x ±1,7…±5,4, z −4,1…0,7) | Propuesta |
| Puertas interiores | 2,0 × 2,4 m | Propuesta |
| Esclusa provisional | 2,3 × 2,5 m (x 1,7…4,0, z −7,6…−5,1); escotilla exterior 1,4 × 2,0 a estribor | Pendiente de prueba |
| Reserva de carga interior | 2,3 × 2,5 m (x −4,0…−1,7, z −7,6…−5,1), acceso abierto 2,5 m | Reserva |
| Ingeniería | x ±3,7, z −14,2…−9,2 | Conservada |
| Puestos Ingeniería / Ciencia / Comunicaciones | consola sustituta 0,8 m de fondo; asiento a 0,9 m de ella | Propuesta |
| Mamparo I4 | z −14,8, Ø 4,0 | Conservada |
| Bodega | Ø 4,0 × 2,5 (z −14,8…−17,3) | Reserva (pendiente) |
| Módulo de servicio | Ø 4,0, largo = tanque + 1,0 (4,2 m; 5,4 m con el ampliado) | Conservada |
| Motor | envolvente Ø 3,2 × 2,5 en `ANC_I2_Motor` (z −21,5 / −22,7) | Conservada |
| Unión al lanzador | 3,0 m tras el motor | Reserva (pendiente) |

Planta y perfil: documento de equipo «Nave base E-4 · planta y perfil del bloque provisional». **No** encargar acabado
definitivo hasta validar el espacio en esta escena.

**Archivos:** `Scripts/Hangar/NaveBase.cs` (datos de la base, sin visual), `PruebaHangar.cs` (configuración y teclas),
`VistaHangar.cs` (solo visual, bloques y materiales simples), `HudHangar.cs` (paneles), `Editor/CrearEscenaHangarPrueba.cs`
(menú 13). Pruebas: sección W de `PRUEBAS_ACEPTACION.md`.

## Nave de expedición modular EM-4X · bloque provisional (escena ExpedicionPrueba, 12 de noviembre de 2026)

Escena **aparte** para recorrer y juzgar tamaño, distribución y sensación de espacio. **No** está integrada en la
partida y **no** es una nave con balance de vuelo: no usa los catálogos ni la masa del casco de la E-4 y no cambia
masas, motores, combustible ni límites del lanzador. Sin atraque, ensamblaje, lanzamientos, gravedad, bots ni red.
HangarPrueba, Nave, VueloPrueba, Configuración, la lista de escenas del build y los paquetes no se han tocado.
Copia previa: `CopiasSeguridad/Copia_antes_EM4X_2026-11-12.zip` (junto con `Copia_funcional_V1_frenado_2026-11-11.zip`).

**Cómo abrirla:** menú *Prototipo → 14. Crear escena ExpedicionPrueba (nave modular EM-4X)* (solo la crea si no
existe) → abrir `Scenes/ExpedicionPrueba.unity` → Play. Todo se construye al pulsar Play.

**Controles (cámara de inspección PROVISIONAL, sin colisiones; no valida por sí sola el movimiento real de personajes):**
- Exterior: botón derecho del ratón para girar alrededor, rueda para acercar.
- **I**: exterior / inspección. En inspección: W/S/A/D, Espacio/Ctrl (según la cámara), **Q/E** girar sobre sí misma,
  botón derecho para mirar, Mayús rápido, **R** nivelar.
- **1** Pilotaje · **2** Ingeniería · **3** Ciencia · **4** Comunicaciones · **0** esclusa · **5** zona común · **6** lanzadera.
- **C** corte (horizontal, longitudinal, transversal por el nodo, sin corte) · **T** rótulos · **X** esquema de
  conexiones (naranja con escotilla, gris estructural) y recorridos (rojo) · **H** ocultar paneles.

**Distribución:** nodo central de Ø 10 m (zona común con mesa y pantalla de misión) con Mando/Pilotaje a proa,
Ingeniería a popa, Ciencia a babor, Comunicaciones a estribor, Hábitat (4 camarotes) arriba y Bodega abajo. Detrás de
Ingeniería, un nodo de popa con Sistemas arriba, Esclusa abajo, anclaje de la sonda y puerto de suministro. Etapa de
propulsión solo exterior. La lanzadera L-4 (bloque) atraca bajo el mando. «Arriba» y «abajo» son referencias de la nave.

**Medidas resultantes (PROVISIONALES):** 57,9 × 29,0 × 25,2 m (largo con lanzadera y motor · ancho con antena ·
alto). Módulos habitables: 6,0 m exteriores, 5,4 interiores, paso libre 3,8 × 3,8 (octógonos de bloques; diámetros
entre caras). Escotillas 1,4 × 1,4; atraque 1,0 × 1,0. Unos 2263 m³ presurizados sin la lanzadera. Recorridos entre
puestos de 17,3 a 22,4 m. La escena muestra la revisión de distribución (solapes, conexiones, escotillas, equipos).

**Datos:** todo es provisional de DEMOSTRACIÓN. Pendientes: balance de masa, propulsión y combustible, recursos y
energía, transporte de los módulos a la órbita, atraque. Las figuras de 1,75 m son referencias, no bots ni jugadores.
No encargar acabado definitivo hasta recorrer el bloque y aceptar medidas. Documento de equipo: «EM-4X · bloque
provisional de la nave de expedición» (planta, perfil, sección, esquema y tablas); copia del plano en
`Documentacion/em4x_planos.png`.

**Archivos:** `Scripts/Expedicion/NaveModular.cs` (datos), `RevisionDistribucion.cs` (revisión, volúmenes,
recorridos), `VistaExpedicion.cs` (geometría), `InspeccionExpedicion.cs` (cámara y teclas), `HudExpedicion.cs`
(paneles), `PruebaExpedicion.cs` (entrada), `Editor/CrearEscenaExpedicionPrueba.cs` (menú 14). Pruebas: sección X de
`PRUEBAS_ACEPTACION.md`.

## Dirección del juego y preparación (decisiones registradas el 12 de noviembre de 2026)

**Estado de la EM-4X:** aspecto general, tamaño y distribución aceptados como base de desarrollo. No es una nave
técnicamente terminada. Siguen pendientes: balance de masa (no vale la masa de 5450 kg del casco anterior), propulsión y
combustible, recursos y energía, transporte y ensamblaje de los módulos en órbita (el **nodo central de 10 m no tiene
transporte resuelto**: se conserva para probar la jugabilidad; su construcción o transporte es una decisión pendiente),
atraque y acabado definitivo.

**Flujo de partida (dirección, no implementado todavía):**
1. Preparación de la expedición antes del despegue terrestre.
2. Lanzamiento de la tripulación en la lanzadera.
3. Llegada a la EM-4X, ya ensamblada en órbita.
4. Salida de la expedición y cumplimiento de objetivos.
5. Regreso de la EM-4X a la base orbital.
6. Retorno de la tripulación a superficie cuando corresponda.
Misiones tripuladas de ida y vuelta como regla principal, con uno o varios objetivos intermedios. Una sonda puede quedarse
en el destino mientras la tripulación regresa. El ensamblaje con varios lanzamientos es contexto del mundo, no una campaña.

**Preparación, piezas y presupuesto:**
- La EM-4X se configura antes del lanzamiento terrestre en una **vista de preparación orbital** que la muestra en órbita.
  Desde tierra se encargan los cambios; la nave grande **no** está en el hangar terrestre.
- El **hangar terrestre es de la lanzadera**. Ambas vistas pueden estar en la misma fase, pero siempre se indica qué
  vehículo y qué lugar se muestra. HangarPrueba se conserva como prototipo recuperable; no se convierte en un hangar que
  contiene la EM-4X.
- Las piezas nuevas se transportan e instalan en órbita; al principio, con costes y una transición (sin jugar los vuelos
  de carga).
- El presupuesto distingue: equipamiento ya instalado · compras y sustituciones · combustible y suministros · transporte
  orbital (solo de lo que se envía desde tierra) · instalación y preparación · lanzamiento de la tripulación. No se cobra
  como nueva una pieza ya instalada.
- La configuración elegida es exactamente la que se encuentra al llegar y la que usa la misión. Durante la planificación
  se comparan opciones; al confirmar, queda **cerrada**. Cambiarla después es explícito y recalcula costes y requisitos
  sin duplicar cobros. Durante el viaje no se compran ni cambian motores o tanques desde ese menú (reparaciones y repuestos
  son otra mecánica).
- La validación futura contempla la misión completa, con el regreso.
- La lanzadera tiene configuración fija por ahora, con datos y recursos separados de los de la EM-4X.
- Se reutilizan configuración, catálogos, validación y presupuesto existentes donde sirvan, sin cambiar sus reglas en silencio.

**Integración que necesitará (más adelante, por etapas):** separar en los datos «instalado» de «pedido»; partidas nuevas
del presupuesto (transporte orbital, instalación, lanzamiento de la tripulación); estado «configuración cerrada»; datos
propios de la lanzadera; vista de preparación orbital; validación con regreso; balance de la EM-4X.

**Siguiente y aplazado**
- Ahora: pasadizos, puertas básicas acordadas y movimiento interior de un personaje con colisiones (escena aparte).
- Después, por etapas: preparación y configuración → vuelo → objetivos → regreso.
- Se conservan sin integrar todavía: VueloPrueba (vuelo y frenado), HangarPrueba, ExpedicionPrueba.
- Aplazado: separación o eyección de módulos, presión y oxígeno, atraque funcional, despliegue de la sonda, arte
  definitivo, bots y multijugador.
- Arte en paralelo: el modelador puede avanzar con dirección visual y piezas independientes usando la EM-4X como
  referencia; los accesos y conexiones siguen provisionales hasta comprobar la circulación. Sin encargo de acabado definitivo.
