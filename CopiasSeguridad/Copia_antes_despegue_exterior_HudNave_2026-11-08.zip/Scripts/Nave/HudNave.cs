using UnityEngine;

namespace PrototipoMision
{
    /// <summary>
    /// Interfaz provisional (IMGUI) de la escena Nave: estado de la nave, instrucción actual,
    /// panel del puesto en uso, mira de pilotaje, barra de inserción, cuenta atrás y avisos.
    /// </summary>
    public class HudNave : MonoBehaviour
    {
        [SerializeField] ControlNave control;
        [SerializeField] JugadorNave jugador;
        [SerializeField] string textoDemo = "DEMOSTRACIÓN · nave tripulada ficticia · viaje comprimido";

        GUIStyle sTitulo, sTexto, sPequeno, sAviso, sGrande, sCentro;

        void OnGUI()
        {
            if (control == null || jugador == null || control.Nave == null) return;
            Preparar();

            float escala = Screen.height / 1080f;
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(escala, escala, 1f));
            float ancho = Screen.width / escala;

            // Destello rojo al recibir un impacto
            if (control.FlashImpacto > 0f)
                Rellenar(new Rect(0, 0, ancho, 1080f), new Color(1f, 0.1f, 0.05f, 0.35f * control.FlashImpacto));

            PanelEstado();

            PuestoNave actual = jugador.PuestoActual;
            if (actual != null) PanelPuesto(actual, ancho);
            else if (control.Fase != FaseNave.Abortada)
                GUI.Label(new Rect(ancho / 2f - 4f, 540f - 14f, 8f, 28f), "+", sCentro);   // punto de mira

            if (actual != null && actual.Tipo == TipoPuesto.Pilotaje)
            {
                if (control.Fase == FaseNave.Crucero) Mira(ancho);
                if (control.InsercionDisponible) BarraInsercion(ancho);
                if (control.Fase == FaseNave.Ascenso && control.Etapa == ControlNave.EstadoEtapa.Pendiente) BarraEtapa(ancho);
            }

            // Cuenta atrás
            if (control.Fase == FaseNave.CuentaAtras)
                GUI.Label(new Rect(ancho / 2f - 300f, 220f, 600f, 140f), Mathf.CeilToInt(control.CuentaAtrasRestante).ToString(), sGrande);

            // Aviso temporal
            if (control.TiempoAviso > 0f && !string.IsNullOrEmpty(control.Aviso))
                GUI.Label(new Rect(ancho / 2f - 600f, 120f, 1200f, 80f), control.Aviso, sAviso);

            // Objetivo alcanzado (misión tripulada)
            if (control.ObjetivoAlcanzado)
            {
                Rellenar(new Rect(ancho / 2f - 560f, 400f, 1120f, 200f), new Color(0f, 0.18f, 0.08f, 0.88f));
                GUI.Label(new Rect(ancho / 2f - 540f, 420f, 1080f, 170f),
                          "<color=#7CFC9A><b>OBJETIVO ALCANZADO</b></color>\nÓrbita establecida sobre " + control.Destino +
                          "\nGenerando el informe de la misión…", sAviso);
            }

            // Aborto
            if (control.Fase == FaseNave.Abortada)
            {
                Rellenar(new Rect(ancho / 2f - 560f, 400f, 1120f, 200f), new Color(0.2f, 0f, 0f, 0.85f));
                GUI.Label(new Rect(ancho / 2f - 540f, 420f, 1080f, 170f),
                          "<b>MISIÓN ABORTADA</b>\n" + control.MotivoAborto + "\nGenerando el informe…", sAviso);
            }

            // Indicación inferior
            string abajo = null;
            if (actual != null)
                abajo = jugador.AsientoBloqueado ? $"{actual.Nombre} · permanece en el asiento"
                                                 : $"{actual.Nombre} · Q: salir del puesto";
            else if (jugador.PuestoMirado != null)
                abajo = $"E: usar {jugador.PuestoMirado.Nombre}";
            if (abajo != null)
                GUI.Label(new Rect(ancho / 2f - 450f, 1080f - 90f, 900f, 40f), abajo, sCentro);

            if (Cursor.lockState != CursorLockMode.Locked)
                GUI.Label(new Rect(ancho / 2f - 450f, 1080f - 50f, 900f, 34f), "Haz clic para controlar la cámara", sCentro);

            GUI.matrix = Matrix4x4.identity;
        }

        void PanelEstado()
        {
            Rect r = new Rect(20f, 20f, 560f, 370f);
            Rellenar(r, new Color(0f, 0.05f, 0.08f, 0.65f));
            GUILayout.BeginArea(new Rect(r.x + 16f, r.y + 10f, r.width - 32f, r.height - 20f));
            GUILayout.Label("NAVE · " + control.NombreFase() + (control.ModoPrueba ? "  <color=#FFB040>[MODO DE PRUEBA]</color>" : ""), sTitulo);
            GUILayout.Label(textoDemo, sPequeno);
            GUILayout.Label($"<b>Destino:</b> {control.Destino}", sTexto);
            Barra("Viaje", control.Progreso, 1f,
                  $"{control.Progreso * 100f:0} % · faltan {control.DistanciaRestanteMkm:0} M km (simulado: progreso guionizado)",
                  new Color(0.3f, 0.9f, 1f));
            Barra("Combustible", control.Combustible, control.Nave.combustibleInicialKg, $"{control.Combustible:0} kg", new Color(1f, 0.8f, 0.3f));
            Barra("Integridad del casco", control.Integridad, control.Catalogo.integridadInicial, $"{control.Integridad:0} %", new Color(0.5f, 1f, 0.6f));
            Barra("Energía de la nave", control.EnergiaNave, control.Nave.energiaWh, $"{control.EnergiaNave:0} Wh", new Color(0.4f, 0.7f, 1f));
            GUILayout.Space(4);
            GUILayout.Label("<b>Ahora:</b> " + control.Instruccion(), sTexto);
            GUILayout.EndArea();
        }

        void PanelPuesto(PuestoNave p, float ancho)
        {
            Rect r = new Rect(ancho - 700f, 140f, 680f, 620f);
            Rellenar(r, new Color(0f, 0.05f, 0.08f, 0.78f));
            GUILayout.BeginArea(new Rect(r.x + 18f, r.y + 12f, r.width - 36f, r.height - 24f));
            GUILayout.Label("PUESTO DE " + p.Nombre.ToUpperInvariant(), sTitulo);
            GUILayout.Label(control.TextoPuesto(p.Tipo), sTexto);
            GUILayout.EndArea();
        }

        void Mira(float ancho)
        {
            // Mira fija en el centro: los escombros que pasan por ella golpean la nave.
            Color c = new Color(0.4f, 1f, 0.9f, 0.9f);
            float cx = ancho / 2f, cy = 540f;
            Rellenar(new Rect(cx - 60f, cy - 1f, 40f, 2f), c);
            Rellenar(new Rect(cx + 20f, cy - 1f, 40f, 2f), c);
            Rellenar(new Rect(cx - 1f, cy - 60f, 2f, 40f), c);
            Rellenar(new Rect(cx - 1f, cy + 20f, 2f, 40f), c);

            // Indicador de deriva lateral
            Vector2 v = control.VelocidadLateral;
            Rellenar(new Rect(cx + v.x * 8f - 4f, cy - v.y * 8f - 4f, 8f, 8f), new Color(1f, 0.8f, 0.3f, 0.9f));
        }

        void BarraInsercion(float ancho)
        {
            Rect barra = new Rect(ancho / 2f - 400f, 760f, 800f, 36f);
            Rellenar(barra, new Color(1f, 1f, 1f, 0.15f));
            float verde = control.Catalogo.zonaVerdeInsercion;
            Rellenar(new Rect(barra.x + barra.width * (0.5f - verde), barra.y, barra.width * verde * 2f, barra.height),
                     new Color(0.2f, 0.9f, 0.35f, 0.7f));
            float x = barra.x + barra.width * control.MarcadorInsercion;
            Rellenar(new Rect(x - 3f, barra.y - 10f, 6f, barra.height + 20f), Color.white);
            GUI.Label(new Rect(barra.x, barra.y + 44f, barra.width, 30f), "Espacio: encender el motor y frenar", sCentro);
        }

        /// <summary>Ventana de separación de etapa: el marcador avanza con el tiempo del ascenso.</summary>
        void BarraEtapa(float ancho)
        {
            float total = control.VentanaEtapaFinS + 0.8f;
            Rect barra = new Rect(ancho / 2f - 400f, 760f, 800f, 36f);
            Rellenar(barra, new Color(1f, 1f, 1f, 0.15f));
            float x0 = barra.x + barra.width * Mathf.Clamp01(control.VentanaEtapaInicioS / total);
            float x1 = barra.x + barra.width * Mathf.Clamp01(control.VentanaEtapaFinS / total);
            bool abierta = control.EtapaEnVentana;
            Rellenar(new Rect(x0, barra.y, x1 - x0, barra.height),
                     abierta ? new Color(0.2f, 1f, 0.4f, 0.85f) : new Color(0.2f, 0.9f, 0.35f, 0.45f));
            float x = barra.x + barra.width * Mathf.Clamp01(control.TiempoFase / total);
            Rellenar(new Rect(x - 3f, barra.y - 10f, 6f, barra.height + 20f), Color.white);
            GUI.Label(new Rect(barra.x, barra.y - 44f, barra.width, 34f),
                      abierta ? "<b>¡AHORA! Espacio: separar la etapa</b>" : "Separación de etapa: espera a la zona verde", sCentro);
        }

        void Barra(string etiqueta, float valor, float maximo, string texto, Color color)
        {
            GUILayout.Label($"{etiqueta}: {texto}", sPequeno);
            Rect r = GUILayoutUtility.GetRect(500f, 12f, GUILayout.ExpandWidth(true));
            Rellenar(r, new Color(1f, 1f, 1f, 0.12f));
            float f = maximo > 0f ? Mathf.Clamp01(valor / maximo) : 0f;
            Rellenar(new Rect(r.x, r.y, r.width * f, r.height), f < 0.25f ? new Color(1f, 0.35f, 0.3f) : color);
            GUILayout.Space(2);
        }

        static void Rellenar(Rect r, Color c)
        {
            Color previo = GUI.color;
            GUI.color = c;
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = previo;
        }

        void Preparar()
        {
            if (sTitulo != null) return;
            sTitulo = new GUIStyle(GUI.skin.label) { fontSize = 22, fontStyle = FontStyle.Bold, richText = true };
            sTitulo.normal.textColor = new Color(0.6f, 0.9f, 1f);
            sTexto = new GUIStyle(GUI.skin.label) { fontSize = 18, wordWrap = true, richText = true };
            sTexto.normal.textColor = Color.white;
            sPequeno = new GUIStyle(GUI.skin.label) { fontSize = 15, wordWrap = true, richText = true };
            sPequeno.normal.textColor = new Color(0.8f, 0.9f, 0.95f);
            sAviso = new GUIStyle(GUI.skin.label) { fontSize = 28, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter, wordWrap = true, richText = true };
            sAviso.normal.textColor = new Color(1f, 0.85f, 0.4f);
            sGrande = new GUIStyle(GUI.skin.label) { fontSize = 110, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            sGrande.normal.textColor = Color.white;
            sCentro = new GUIStyle(GUI.skin.label) { fontSize = 20, alignment = TextAnchor.MiddleCenter, richText = true };
            sCentro.normal.textColor = new Color(0.9f, 0.97f, 1f);
        }
    }
}
